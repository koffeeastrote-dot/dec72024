<?php
/**
 * Privacy Notice (public page)
 */
require_once __DIR__ . '/includes/auth.php';
startSecureSession();
$pageTitle = 'Privacy Notice — The Enchanted Archives';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="auth-card" style="max-width:760px;">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Privacy Notice</h1>
    </div>
    <div class="auth-body" style="color:#5a4030;">
        <p><em>Last updated: November 2026. Written with the Philippine Data Privacy Act of 2012 (RA 10173) in mind; adjust the details to your school or organization.</em></p>
        <h5>What we collect</h5>
        <p>Your full name, email address, a hashed (never readable) password, your borrowing history, feedback and problem reports, and security logs (login time, IP address, browser type, success or failure).</p>
        <h5>Why we collect it</h5>
        <p>To create and protect your account (email verification, two-factor codes, password reset), to manage borrowing, and to detect abuse such as repeated failed logins.</p>
        <h5>Who can see it</h5>
        <p>Only the library administrators. We do not sell or share your data with third parties. Emails are sent through an SMTP provider only to deliver your codes and alerts.</p>
        <h5>How long we keep it</h5>
        <p>Account and borrowing records are kept while your account is active. Security logs are kept for a limited time for protection and auditing.</p>
        <h5>Your rights</h5>
        <p>You may ask to see, correct or delete your personal data by contacting the library administrator.</p>
        <h5>How we protect it</h5>
        <p>Passwords are hashed with bcrypt, sessions are protected, forms use CSRF tokens, and database queries are parameterized.</p>
        <div class="text-center mt-3">
            <a href="/the_enchanted_archives/index.php?open=1&amp;tab=signup">← Back to Sign Up</a>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
