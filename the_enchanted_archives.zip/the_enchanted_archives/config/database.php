<?php
/**
 * The Enchanted Archives - Database Configuration
 * 
 * Update these values to match your local XAMPP MySQL setup.
 * Default XAMPP credentials are used below.
 */

define('DB_HOST', '127.0.0.1');
// Default XAMPP MySQL port is 3306. If your MySQL runs on another port
// (e.g. 3307), set it here - the connection will also auto-try the others below.
define('DB_PORT', '3306');
define('DB_FALLBACK_PORTS', '3307,3308');
define('DB_NAME', 'enchanted_archives_db');
define('DB_USER', 'root');
define('DB_PASS', ''); // Default XAMPP has empty password
define('DB_CHARSET', 'utf8mb4');
require_once __DIR__ . '/security.php';
// NOTE: for a real deployment do not use 'root'; create a MySQL user that has
// only SELECT/INSERT/UPDATE/DELETE on enchanted_archives_db (see SECURITY_CHECKLIST.md).
define('DB_COLLATION', 'utf8mb4_general_ci');

/**
 * PDO Database Connection
 */
function getDB(): PDO {
    static $pdo = null;
    
    if ($pdo === null) {
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_PERSISTENT         => false,
            PDO::ATTR_TIMEOUT            => 3,
        ];

        // Try the configured port first, then the fallbacks
        $ports = array_unique(array_merge([DB_PORT], array_filter(explode(',', DB_FALLBACK_PORTS))));
        $firstError = null; // error from the configured port is the one that matters

        foreach ($ports as $port) {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . trim($port) . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            try {
                $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
                // Keep MySQL session timezone in sync with PHP
                $pdo->exec("SET time_zone = '+08:00'"); // Asia/Manila
                break;
            } catch (PDOException $e) {
                $firstError = $firstError ?? $e;
                $pdo = null;
            }
        }

        if ($pdo === null) {
            // Never show host/user/DB details to visitors (information disclosure).
            error_log('DB connection failed: ' . ($firstError ? $firstError->getMessage() : 'unknown'));
            http_response_code(500);
            echo '<h3>The Archives are temporarily unavailable.</h3>';
            if (APP_DEBUG && $firstError) {
                echo '<pre>' . htmlspecialchars($firstError->getMessage()) . '</pre>'
                   . '<p>Make sure MySQL is started in XAMPP and the database <code>' . htmlspecialchars(DB_NAME) . '</code> was imported.</p>';
            } else {
                echo '<p>Please try again later.</p>';
            }
            exit;
        }
    }
    
    return $pdo;
}