<?php
/**
 * The Enchanted Archives - Security settings
 */

// Show detailed errors on screen? Keep FALSE when the teacher / users can see the site.
// (Set TRUE only while you are debugging on your own PC.)
define('APP_DEBUG', false);

// IP addresses of reverse proxies you trust (comma separated). Leave empty on XAMPP.
// Only requests that come from these IPs may use the X-Forwarded-For header.
define('TRUSTED_PROXIES', '');

// Force HTTPS redirect (turn on when the site is hosted with SSL; keep off on http://localhost).
define('FORCE_HTTPS', false);

// Session limits (seconds)
define('SESSION_IDLE_TIMEOUT', 1800);      // 30 min of no activity -> logged out
define('SESSION_ABSOLUTE_TIMEOUT', 28800); // 8 hours max, even if active
