<?php
/**
 * The Enchanted Archives - Gmail SMTP Configuration
 * 
 * IMPORTANT: Never commit real credentials to version control.
 * 
 * Setup Guide:
 * 1. Enable 2-Step Verification on your Google Account.
 * 2. Go to Google Account > Security > 2-Step Verification > App passwords.
 * 3. Generate an App Password for "Mail".
 * 4. Paste the 16-character App Password below as SMTP_PASSWORD.
 * 5. Use your full Gmail address as SMTP_USERNAME and MAIL_FROM_ADDRESS.
 * 
 * If SMTP is not configured, OTP emails will fail gracefully and the
 * application will display a clear message that email verification
 * requires SMTP setup. OTP verification is NEVER silently bypassed.
 */

// Real credentials live in config/smtp.local.php (not shared / not submitted / not committed).
// Copy config/smtp.local.php.example to config/smtp.local.php and fill it in.
if (is_file(__DIR__ . '/smtp.local.php')) {
    require_once __DIR__ . '/smtp.local.php';
}
if (!defined('SMTP_USERNAME')) {
    define('SMTP_USERNAME', 'your.email@gmail.com');
}
if (!defined('SMTP_PASSWORD')) {
    define('SMTP_PASSWORD', '');
}
if (!defined('MAIL_FROM_ADDRESS')) {
    define('MAIL_FROM_ADDRESS', 'your.email@gmail.com');
}

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_ENCRYPTION', 'tls'); // tls or ssl
define('MAIL_FROM_NAME', 'The Enchanted Archives');

/**
 * Public address of this site. Used to build the buttons inside security-alert
 * emails ("Yes, it's me" / "Report"). Change it if you open the site on another
 * port or domain, e.g. 'http://localhost:8080'. Do NOT end it with a slash.
 */
define('APP_BASE_URL', 'http://localhost');

/**
 * Check if SMTP is properly configured
 */
function isSmtpConfigured(): bool {
    return !empty(SMTP_USERNAME) 
        && !empty(SMTP_PASSWORD) 
        && !empty(MAIL_FROM_ADDRESS)
        && filter_var(MAIL_FROM_ADDRESS, FILTER_VALIDATE_EMAIL);
}
