<?php
require_once 'config/database.php';
try {
    $db = getDB();
    echo "SUCCESS: Nakakonekta na sa database!";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage();
}