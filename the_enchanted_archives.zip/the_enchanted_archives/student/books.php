<?php
/**
 * Browse Books
 */
require_once __DIR__ . '/../includes/auth.php';
requireStudent();

$pdo = getDB();
$search = trim($_GET['q'] ?? '');
$cat = (int)($_GET['category'] ?? 0);

$sql = "SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE 1=1";
$params = [];
if ($search !== '') {
    $sql .= " AND (b.title LIKE ? OR b.author LIKE ?)";
    $like = '%' . escapeLike($search) . '%';
    $params = [$like, $like];
}
if ($cat > 0) {
    $sql .= " AND b.category_id = ?";
    $params[] = $cat;
}
$sql .= " ORDER BY b.title ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();
$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();

$pageTitle = 'Browse the Collection';
$extraCss = ['/the_enchanted_archives/assets/css/student.css'];
$bodyClass = 'student-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/student_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Browse Books</h1>
    </div>
    <form method="get" class="row g-2 mb-4">
        <div class="col-md-5">
            <input type="text" name="q" class="form-control" placeholder="Search title or author..." value="<?= e($search) ?>">
        </div>
        <div class="col-md-4">
            <select name="category" class="form-select">
                <option value="0">All Categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= $cat===(int)$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-gold w-100">Search</button>
        </div>
    </form>
    
    <div class="row g-3">
        <?php foreach ($books as $b): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <a href="book_details.php?id=<?= (int)$b['id'] ?>" class="text-decoration-none">
                    <div class="book-card">
                        <div class="cover">
                            <?php if (!empty($b['cover_image']) && is_file(__DIR__.'/../uploads/books/'.$b['cover_image'])): ?>
                                <img src="/the_enchanted_archives/uploads/books/<?= e($b['cover_image']) ?>" alt="">
                            <?php else: ?>
                                <i class="bi bi-book"></i>
                            <?php endif; ?>
                        </div>
                        <div class="body">
                            <div class="title"><?= e($b['title']) ?></div>
                            <div class="author"><?= e($b['author']) ?></div>
                            <div class="meta"><?= e($b['category_name'] ?? 'Uncategorized') ?> · <?= (int)$b['available_copies'] ?> left</div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
        <?php if (empty($books)): ?>
            <div class="col-12 empty-state"><i class="bi bi-bookshelf"></i><p>No books match your search.</p></div>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
