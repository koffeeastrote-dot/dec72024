<?php
/**
 * My Borrowings
 */
require_once __DIR__ . '/../includes/auth.php';
requireStudent();

$pdo = getDB();
$uid = currentUserId();

$stmt = $pdo->prepare("SELECT b.*, bk.title, bk.author 
    FROM borrowings b 
    JOIN books bk ON b.book_id = bk.id 
    WHERE b.user_id = ? 
    ORDER BY b.request_date DESC");
$stmt->execute([$uid]);
$records = $stmt->fetchAll();

$pageTitle = 'My Borrowings';
$extraCss = ['/the_enchanted_archives/assets/css/student.css'];
$bodyClass = 'student-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/student_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>My Borrowings</h1></div>
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead>
                    <tr><th>Book</th><th>Status</th><th>Requested</th><th>Borrowed</th><th>Due</th><th>Returned</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?>
                        <tr><td colspan="6" class="text-center py-4">You have no borrowing records yet.</td></tr>
                    <?php else: foreach ($records as $r): ?>
                        <tr>
                            <td><strong><?= e($r['title']) ?></strong><br><small><?= e($r['author']) ?></small></td>
                            <td><span class="badge badge-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
                            <td><?= formatDate($r['request_date'], 'M d, Y') ?></td>
                            <td><?= formatDate($r['borrow_date'], 'M d, Y') ?></td>
                            <td><?= formatDate($r['due_date'], 'M d, Y') ?></td>
                            <td><?= formatDate($r['return_date'], 'M d, Y') ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
