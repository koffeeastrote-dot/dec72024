<?php
/**
 * Request to Borrow
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireStudent();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/the_enchanted_archives/student/books.php');
}
requireCsrf();

$bookId = (int)($_POST['book_id'] ?? 0);
$uid = currentUserId();
$pdo = getDB();

$stmt = $pdo->prepare('SELECT id, available_copies FROM books WHERE id = ?');
$stmt->execute([$bookId]);
$book = $stmt->fetch();

if (!$book || (int)$book['available_copies'] < 1) {
    setFlash('error', 'This book is not available.');
    redirect('/the_enchanted_archives/student/books.php');
}

// Prevent duplicate active request
$stmt = $pdo->prepare("SELECT id FROM borrowings WHERE user_id = ? AND book_id = ? AND status IN ('pending','approved')");
$stmt->execute([$uid, $bookId]);
if ($stmt->fetch()) {
    setFlash('error', 'You already have an active request for this book.');
    redirect('/the_enchanted_archives/student/book_details.php?id=' . $bookId);
}

$stmt = $pdo->prepare("INSERT INTO borrowings (user_id, book_id, status) VALUES (?, ?, 'pending')");
$stmt->execute([$uid, $bookId]);

setFlash('success', 'Borrowing request submitted. Awaiting approval from the Keeper.');
redirect('/the_enchanted_archives/student/my_borrowings.php');
