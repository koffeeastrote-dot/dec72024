<?php
/**
 * Send Feedback (student)
 * Students submit suggestions and comments about the library system.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/reports.php';
requireStudent();

$pdo = getDB();
$uid = currentUserId();
$error = '';
$category = 'suggestion';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $category = (string)($_POST['category'] ?? '');
    $message  = trim((string)($_POST['message'] ?? ''));
    $len = mb_strlen($message);

    if (!isset(FEEDBACK_CATEGORIES[$category])) {
        $error = 'Please choose a valid feedback type.';
    } elseif ($len < 5 || $len > 2000) {
        $error = 'Feedback must be between 5 and 2000 characters.';
    } elseif (!checkRateLimit('feedback_submit', (string)$uid, 10, 3600, 3600)) {
        $error = 'You have sent several messages recently. Please try again later.';
    } else {
        $pdo->prepare('INSERT INTO feedback (user_id, category, message) VALUES (?, ?, ?)')
            ->execute([$uid, $category, $message]);
        setFlash('success', 'Thank you! Your feedback was sent.');
        redirect('/the_enchanted_archives/student/feedback.php');
    }
}

$stmt = $pdo->prepare('SELECT * FROM feedback WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
$stmt->execute([$uid]);
$mine = $stmt->fetchAll();

$pageTitle = 'Send Feedback';
$extraCss = ['/the_enchanted_archives/assets/css/student.css'];
$bodyClass = 'student-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/student_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>Send Feedback</h1></div>

    <div class="row g-4">
        <div class="col-lg-5">
            <div class="parchment-card p-4">
                <h5 class="cinzel mb-1" style="color:var(--mahogany);">Your Thoughts</h5>
                <p class="small text-muted">Share suggestions and comments about the library system.</p>
                <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
                <form method="post">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="category" class="form-select" required>
                            <?php foreach (FEEDBACK_CATEGORIES as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= $category === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea name="message" class="form-control" rows="6" maxlength="2000" required><?= e($message) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-gold">Send Feedback</button>
                </form>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="parchment-card p-3">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">My Feedback</h5>
                <div class="table-responsive">
                    <table class="table table-enchanted table-sm mb-0">
                        <thead><tr><th>Type</th><th>Message</th><th>Sent</th></tr></thead>
                        <tbody>
                        <?php if (empty($mine)): ?>
                            <tr><td colspan="3" class="text-center py-4">You have not sent any feedback yet.</td></tr>
                        <?php else: foreach ($mine as $f): ?>
                            <tr>
                                <td><?= e(FEEDBACK_CATEGORIES[$f['category']] ?? $f['category']) ?></td>
                                <td><?= nl2br(e($f['message'])) ?></td>
                                <td><?= formatDate($f['created_at'], 'M d, Y') ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
