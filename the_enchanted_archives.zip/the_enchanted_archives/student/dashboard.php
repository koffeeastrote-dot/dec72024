<?php
/**
 * Student Dashboard
 */
require_once __DIR__ . '/../includes/auth.php';
requireStudent();

$pdo = getDB();
$uid = currentUserId();

$available = (int)$pdo->query('SELECT COALESCE(SUM(available_copies),0) FROM books')->fetchColumn();
$active = countRows('borrowings', "user_id = ? AND status = 'approved'", [$uid]);
$pending = countRows('borrowings', "user_id = ? AND status = 'pending'", [$uid]);
$overdue = countRows('borrowings', "user_id = ? AND status = 'approved' AND due_date < NOW()", [$uid]);

$stmt = $pdo->query("SELECT id, title, author, available_copies, cover_image FROM books WHERE available_copies > 0 ORDER BY date_added DESC LIMIT 6");
$featured = $stmt->fetchAll();

$pageTitle = 'Student Dashboard';
$extraCss = ['/the_enchanted_archives/assets/css/student.css'];
$bodyClass = 'student-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/student_sidebar.php';
?>

<div class="main-content">
    <div class="welcome-banner">
        <h2>Welcome, <?= e(currentUserName()) ?></h2>
        <p>The Archives await your curiosity. Browse the collection and request the knowledge you seek.</p>
    </div>
    
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-value"><?= $available ?></div>
                <div class="stat-label">Available Books</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-value"><?= $active ?></div>
                <div class="stat-label">Active Borrowings</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-value"><?= $pending ?></div>
                <div class="stat-label">Pending Requests</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-value"><?= $overdue ?></div>
                <div class="stat-label">Overdue</div>
            </div>
        </div>
    </div>
    
    <h4 class="cinzel text-muted-gold mb-3">Recently Added</h4>
    <div class="row g-3">
<?php foreach ($featured as $b): ?>
    <div class="col-md-4 col-lg-2">
        <a href="book_details.php?id=<?= (int)$b['id'] ?>" class="text-decoration-none">
            <div class="book-card">
                <div class="cover">
                    <?php if (!empty($b['cover_image']) && is_file(__DIR__ . '/../uploads/books/' . $b['cover_image'])): ?>
                        <img src="/the_enchanted_archives/uploads/books/<?= e($b['cover_image']) ?>" alt="">
                    <?php else: ?>
                        <i class="bi bi-book"></i>
                    <?php endif; ?>
                </div>
                <div class="body">
                    <div class="title"><?= e($b['title']) ?></div>
                    <div class="author"><?= e($b['author']) ?></div>
                    <div class="meta"><?= (int)$b['available_copies'] ?> available</div>
                </div>
            </div>
        </a>
    </div>
<?php endforeach; ?>
        <?php if (empty($featured)): ?>
            <div class="col-12 empty-state"><p>No books available yet.</p></div>
        <?php endif; ?>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
