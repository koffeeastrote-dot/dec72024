<?php
/**
 * Book Details
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireStudent();

$pdo = getDB();
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE b.id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch();
if (!$book) {
    setFlash('error', 'Book not found.');
    redirect('/the_enchanted_archives/student/books.php');
}

// Check existing request
$uid = currentUserId();
$stmt = $pdo->prepare("SELECT id, status FROM borrowings WHERE user_id = ? AND book_id = ? AND status IN ('pending','approved') LIMIT 1");
$stmt->execute([$uid, $id]);
$existing = $stmt->fetch();

$pageTitle = e($book['title']);
$extraCss = ['/the_enchanted_archives/assets/css/student.css'];
$bodyClass = 'student-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/student_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1><?= e($book['title']) ?></h1>
        <a href="books.php" class="btn btn-outline-gold btn-sm">← Back</a>
    </div>
    <div class="parchment-card p-4">
        <div class="row">
            <div class="col-md-3 text-center mb-3">
                <div class="cover mx-auto" style="height:220px;background:linear-gradient(135deg,var(--mahogany),var(--dark-brown));display:flex;align-items:center;justify-content:center;color:var(--antique-gold);font-size:4rem;border-radius:4px;">
                    <?php if (!empty($book['cover_image']) && is_file(__DIR__.'/../uploads/books/'.$book['cover_image'])): ?>
                        <img src="/the_enchanted_archives/uploads/books/<?= e($book['cover_image']) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:4px;" alt="">
                    <?php else: ?>
                        <i class="bi bi-book"></i>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-9">
                <p><strong>Author:</strong> <?= e($book['author']) ?></p>
                <p><strong>Category:</strong> <?= e($book['category_name'] ?? 'Uncategorized') ?></p>
                <p><strong>ISBN:</strong> <?= e($book['isbn'] ?? '—') ?></p>
                <p><strong>Year:</strong> <?= e($book['publication_year'] ?? '—') ?></p>
                <p><strong>Available:</strong> <?= (int)$book['available_copies'] ?> of <?= (int)$book['total_quantity'] ?></p>
                <?php if ($book['description']): ?>
                    <p class="mt-3"><?= nl2br(e($book['description'])) ?></p>
                <?php endif; ?>
                
                <div class="mt-4">
                    <?php if ($existing): ?>
                        <span class="badge badge-<?= e($existing['status']) ?>">You already have a <?= e($existing['status']) ?> request for this book.</span>
                    <?php elseif ((int)$book['available_copies'] < 1): ?>
                        <span class="badge badge-rejected">Currently unavailable</span>
                    <?php else: ?>
                        <form method="post" action="borrow_book.php">
                            <?= csrfField() ?>
                            <input type="hidden" name="book_id" value="<?= (int)$book['id'] ?>">
                            <button type="submit" class="btn btn-gold">Request to Borrow</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
