<?php
/**
 * Report a Problem (student)
 * Students report suspicious activity, unauthorized access, errors or technical issues.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/reports.php';
requireStudent();

$pdo = getDB();
$uid = currentUserId();
$error = '';
$category = 'technical_issue';
$subject = '';
$description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $category    = (string)($_POST['category'] ?? '');
    $subject     = trim((string)($_POST['subject'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));

    $error = validateReportInput($category, $subject, $description);
    if ($error === '' && !checkRateLimit('report_submit', (string)$uid, 5, 3600, 3600)) {
        $error = 'You have sent several reports recently. Please wait a while before sending another.';
    }
    if ($error === '') {
        createReport($uid, (string)currentUserEmail(), $category, $subject, $description, 'app');
        setFlash('success', 'Your report was sent to the administrators. Thank you!');
        redirect('/the_enchanted_archives/student/report.php');
    }
}

$stmt = $pdo->prepare('SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
$stmt->execute([$uid]);
$myReports = $stmt->fetchAll();

$pageTitle = 'Report a Problem';
$extraCss = ['/the_enchanted_archives/assets/css/student.css'];
$bodyClass = 'student-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/student_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>Report a Problem</h1></div>

    <div class="row g-4">
        <div class="col-lg-5">
            <div class="parchment-card p-4">
                <h5 class="cinzel mb-1" style="color:var(--mahogany);">New Report</h5>
                <p class="small text-muted">Report suspicious activity, unauthorized access, errors, or technical issues. The administrators are notified by email.</p>
                <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
                <form method="post">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label class="form-label">Type of report</label>
                        <select name="category" class="form-select" required>
                            <?php foreach (REPORT_CATEGORIES as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= $category === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <input type="text" name="subject" class="form-control" maxlength="150" required value="<?= e($subject) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Details</label>
                        <textarea name="description" class="form-control" rows="6" maxlength="2000" required placeholder="What happened? When did it happen?"><?= e($description) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-gold">Send Report</button>
                </form>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="parchment-card p-3">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">My Reports</h5>
                <div class="table-responsive">
                    <table class="table table-enchanted table-sm mb-0">
                        <thead><tr><th>Report</th><th>Status</th><th>Sent</th></tr></thead>
                        <tbody>
                        <?php if (empty($myReports)): ?>
                            <tr><td colspan="3" class="text-center py-4">You have not sent any reports.</td></tr>
                        <?php else: foreach ($myReports as $r): ?>
                            <tr>
                                <td>
                                    <strong><?= e($r['subject']) ?></strong><br>
                                    <small><?= e(REPORT_CATEGORIES[$r['category']] ?? $r['category']) ?></small>
                                    <?php if (!empty($r['admin_response'])): ?>
                                        <div class="mt-2 p-2" style="background:rgba(183,139,75,.15);border-left:3px solid #b78b4b;">
                                            <small><strong>Admin response:</strong><br><?= nl2br(e($r['admin_response'])) ?></small>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge badge-<?= e($r['status']) ?>"><?= e(REPORT_STATUSES[$r['status']] ?? $r['status']) ?></span></td>
                                <td><?= formatDate($r['created_at'], 'M d, Y') ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
