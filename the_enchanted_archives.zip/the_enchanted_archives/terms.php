<?php
/**
 * Terms of Use (public page)
 */
require_once __DIR__ . '/includes/auth.php';
startSecureSession();
$pageTitle = 'Terms of Use — The Enchanted Archives';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/includes/header.php';
?>
<div class="auth-card" style="max-width:760px;">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Terms of Use</h1>
    </div>
    <div class="auth-body" style="color:#5a4030;">
        <p><em>Last updated: November 2026. This is a school project; adjust the details to your school or organization.</em></p>
        <h5>1. Using the Archives</h5>
        <p>The Enchanted Archives is a library system for registered students. You agree to give correct information when you register and to use your own account only.</p>
        <h5>2. Your account and password</h5>
        <p>Keep your password and verification codes private. Never share them, even with staff. You are responsible for activity under your account. We may lock or deactivate accounts that show suspicious or abusive activity.</p>
        <h5>3. Borrowing</h5>
        <p>Borrow requests are approved by the librarian. Return borrowed books on time and in good condition.</p>
        <h5>4. Acceptable use</h5>
        <p>Do not try to break, probe or overload the system, access other users' data, or upload harmful files. Security problems can be reported through the "Report a Problem" form.</p>
        <h5>5. Changes</h5>
        <p>These terms may be updated. Continued use of the system means you accept the updated terms.</p>
        <div class="text-center mt-3">
            <a href="/the_enchanted_archives/index.php?open=1&amp;tab=signup">← Back to Sign Up</a>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
