<?php
/**
 * Admin Report Management - view, respond and update status
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/reports.php';
requireAdmin();

$pdo = getDB();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare('SELECT r.*, u.full_name, rb.full_name AS responder_name
                       FROM reports r
                       LEFT JOIN users u ON u.id = r.user_id
                       LEFT JOIN users rb ON rb.id = r.responded_by
                       WHERE r.id = ?');
$stmt->execute([$id]);
$report = $stmt->fetch();

if (!$report) {
    setFlash('error', 'Report not found.');
    redirect('/the_enchanted_archives/admin/reports.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $status   = (string)($_POST['status'] ?? '');
    $response = trim((string)($_POST['admin_response'] ?? ''));

    if (!isset(REPORT_STATUSES[$status])) {
        $error = 'Please choose a valid status.';
    } elseif (mb_strlen($response) > 2000) {
        $error = 'Response is too long (maximum 2000 characters).';
    } else {
        $pdo->prepare('UPDATE reports
                       SET status = ?,
                           admin_response = ?,
                           responded_by = ?,
                           responded_at = NOW()
                       WHERE id = ?')
            ->execute([$status, $response !== '' ? $response : null, currentUserId(), $id]);
        setFlash('success', 'Report #' . $id . ' updated.');
        redirect('/the_enchanted_archives/admin/report_view.php?id=' . $id);
    }
    // keep what the admin typed
    $report['status'] = isset(REPORT_STATUSES[$status]) ? $status : $report['status'];
    $report['admin_response'] = $response;
}

$pageTitle = 'Report #' . $id;
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Report #<?= (int)$report['id'] ?></h1>
        <a href="reports.php" class="btn btn-sm btn-outline-gold">&larr; All reports</a>
    </div>

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="parchment-card p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="cinzel mb-0" style="color:var(--mahogany);"><?= e($report['subject']) ?></h5>
                    <span class="badge badge-<?= e($report['status']) ?>"><?= e(REPORT_STATUSES[$report['status']] ?? $report['status']) ?></span>
                </div>
                <dl class="row small mb-3">
                    <dt class="col-sm-3">From</dt>
                    <dd class="col-sm-9"><?= e($report['full_name'] ?? 'Unknown') ?> (<?= e($report['reporter_email']) ?>)</dd>
                    <dt class="col-sm-3">Type</dt>
                    <dd class="col-sm-9"><?= e(REPORT_CATEGORIES[$report['category']] ?? $report['category']) ?></dd>
                    <dt class="col-sm-3">Submitted via</dt>
                    <dd class="col-sm-9"><?= $report['source'] === 'email_alert' ? 'Security alert email' : 'Report a Problem form' ?></dd>
                    <dt class="col-sm-3">IP address</dt>
                    <dd class="col-sm-9"><?= e($report['ip_address'] ?? '—') ?></dd>
                    <dt class="col-sm-3">Sent</dt>
                    <dd class="col-sm-9"><?= formatDate($report['created_at']) ?></dd>
                </dl>
                <div class="p-3" style="background:rgba(255,255,255,.35);border:1px solid #b78b4b;border-radius:6px;">
                    <?= nl2br(e($report['description'])) ?>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="parchment-card p-4">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">Respond &amp; Update Status</h5>
                <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
                <form method="post">
                    <?= csrfField() ?>
                    <input type="hidden" name="id" value="<?= (int)$report['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" required>
                            <?php foreach (REPORT_STATUSES as $k => $label): ?>
                                <option value="<?= e($k) ?>" <?= $report['status'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Response to the student</label>
                        <textarea name="admin_response" class="form-control" rows="6" maxlength="2000"><?= e($report['admin_response'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-gold">Save</button>
                </form>
                <?php if (!empty($report['responded_at'])): ?>
                    <p class="small text-muted mt-3 mb-0">
                        Last updated by <?= e($report['responder_name'] ?? 'an administrator') ?>
                        on <?= formatDate($report['responded_at']) ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
