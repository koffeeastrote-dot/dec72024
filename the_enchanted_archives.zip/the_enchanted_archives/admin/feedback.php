<?php
/**
 * Admin - view student feedback
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/reports.php';
requireAdmin();

$pdo = getDB();
$items = $pdo->query('SELECT f.*, u.full_name, u.email
                      FROM feedback f
                      JOIN users u ON u.id = f.user_id
                      ORDER BY f.created_at DESC
                      LIMIT 200')->fetchAll();

$pageTitle = 'Feedback';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>Student Feedback</h1></div>
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead><tr><th>Student</th><th>Type</th><th>Message</th><th>Sent</th></tr></thead>
                <tbody>
                <?php if (empty($items)): ?>
                    <tr><td colspan="4" class="text-center py-4">No feedback yet.</td></tr>
                <?php else: foreach ($items as $f): ?>
                    <tr>
                        <td><?= e($f['full_name']) ?><br><small><?= e($f['email']) ?></small></td>
                        <td><?= e(FEEDBACK_CATEGORIES[$f['category']] ?? $f['category']) ?></td>
                        <td><?= nl2br(e($f['message'])) ?></td>
                        <td><?= formatDate($f['created_at']) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
