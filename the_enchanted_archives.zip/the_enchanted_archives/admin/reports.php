<?php
/**
 * Admin Report Management - list
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/reports.php';
requireAdmin();

$pdo = getDB();
$filter = (string)($_GET['status'] ?? '');
if (!isset(REPORT_STATUSES[$filter])) {
    $filter = '';
}

$counts = array_fill_keys(array_keys(REPORT_STATUSES), 0);
foreach ($pdo->query('SELECT status, COUNT(*) AS c FROM reports GROUP BY status')->fetchAll() as $c) {
    $counts[$c['status']] = (int)$c['c'];
}

$sql = 'SELECT r.*, u.full_name FROM reports r LEFT JOIN users u ON u.id = r.user_id';
$params = [];
if ($filter !== '') {
    $sql .= ' WHERE r.status = ?';
    $params[] = $filter;
}
$sql .= ' ORDER BY FIELD(r.status, "pending", "under_review", "resolved", "rejected"), r.created_at DESC LIMIT 200';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

$pageTitle = 'Reports';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>Reports</h1></div>

    <div class="mb-3">
        <a href="?" class="btn btn-sm <?= $filter === '' ? 'btn-gold' : 'btn-outline-gold' ?>">All (<?= array_sum($counts) ?>)</a>
        <?php foreach (REPORT_STATUSES as $k => $label): ?>
            <a href="?status=<?= e($k) ?>" class="btn btn-sm <?= $filter === $k ? 'btn-gold' : 'btn-outline-gold' ?>"><?= e($label) ?> (<?= $counts[$k] ?>)</a>
        <?php endforeach; ?>
    </div>

    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead>
                    <tr><th>#</th><th>From</th><th>Type</th><th>Subject</th><th>Status</th><th>Sent</th><th></th></tr>
                </thead>
                <tbody>
                <?php if (empty($reports)): ?>
                    <tr><td colspan="7" class="text-center py-4">No reports.</td></tr>
                <?php else: foreach ($reports as $r): ?>
                    <tr>
                        <td><?= (int)$r['id'] ?></td>
                        <td><?= e($r['full_name'] ?? 'Unknown') ?><br><small><?= e($r['reporter_email']) ?></small></td>
                        <td>
                            <?= e(REPORT_CATEGORIES[$r['category']] ?? $r['category']) ?>
                            <?php if ($r['source'] === 'email_alert'): ?><br><small><i class="bi bi-envelope-exclamation"></i> via alert email</small><?php endif; ?>
                        </td>
                        <td style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($r['subject']) ?></td>
                        <td><span class="badge badge-<?= e($r['status']) ?>"><?= e(REPORT_STATUSES[$r['status']] ?? $r['status']) ?></span></td>
                        <td><?= formatDate($r['created_at']) ?></td>
                        <td><a href="report_view.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-gold">View</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
