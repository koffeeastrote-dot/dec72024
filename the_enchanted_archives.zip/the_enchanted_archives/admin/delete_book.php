<?php
/**
 * Delete Book
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireAdmin();
require_once __DIR__ . '/../includes/csrf.php';
requirePostWithCsrf('/the_enchanted_archives/admin/books.php');

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    redirect('/the_enchanted_archives/admin/books.php');
}

$pdo = getDB();
$stmt = $pdo->prepare('SELECT id, cover_image FROM books WHERE id = ?');
$stmt->execute([$id]);
$book = $stmt->fetch();

if ($book) {
    $pdo->prepare('DELETE FROM books WHERE id = ?')->execute([$id]);
    if (!empty($book['cover_image'])) {
        $path = __DIR__ . '/../uploads/books/' . $book['cover_image'];
        if (is_file($path)) {
            @unlink($path);
        }
    }
    auditLog('book_deleted', 'Book ID ' . $id);
    setFlash('success', 'Book removed from the Archives.');
}

redirect('/the_enchanted_archives/admin/books.php');
