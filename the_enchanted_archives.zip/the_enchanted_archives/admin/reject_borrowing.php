<?php
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/csrf.php';
requirePostWithCsrf('/the_enchanted_archives/admin/borrowings.php');

$id = (int)($_POST['id'] ?? 0);
$pdo = getDB();
$stmt = $pdo->prepare("UPDATE borrowings SET status = 'rejected' WHERE id = ? AND status = 'pending'");
$stmt->execute([$id]);
auditLog('borrowing_rejected', 'Borrowing ID ' . $id);
setFlash('success', 'Request rejected.');
redirect('/the_enchanted_archives/admin/borrowings.php');
