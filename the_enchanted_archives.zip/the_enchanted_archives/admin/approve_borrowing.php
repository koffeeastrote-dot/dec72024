<?php
/**
 * Approve Borrowing Request
 */
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/csrf.php';
requirePostWithCsrf('/the_enchanted_archives/admin/borrowings.php');

$id = (int)($_POST['id'] ?? 0);
$pdo = getDB();

try {
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("SELECT b.*, bk.available_copies FROM borrowings b JOIN books bk ON b.book_id = bk.id WHERE b.id = ? AND b.status = 'pending' FOR UPDATE");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    
    if (!$row) {
        throw new Exception('Request not found or already processed.');
    }
    if ((int)$row['available_copies'] < 1) {
        throw new Exception('No available copies for this book.');
    }
    
    $due = date('Y-m-d H:i:s', time() + 14 * 86400); // 14 days
    
    $stmt = $pdo->prepare("UPDATE borrowings SET status = 'approved', borrow_date = NOW(), due_date = ? WHERE id = ?");
    $stmt->execute([$due, $id]);
    
    $stmt = $pdo->prepare("UPDATE books SET available_copies = available_copies - 1 WHERE id = ? AND available_copies > 0");
    $stmt->execute([$row['book_id']]);
    
    $pdo->commit();
    auditLog('borrowing_approved', 'Borrowing ID ' . $id);
    setFlash('success', 'Borrowing approved. Due in 14 days.');
} catch (Exception $e) {
    $pdo->rollBack();
    setFlash('error', $e->getMessage());
}

redirect('/the_enchanted_archives/admin/borrowings.php');
