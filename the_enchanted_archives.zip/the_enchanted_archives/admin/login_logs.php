<?php
/**
 * Login Activity Logs
 */
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pdo = getDB();
$filter = $_GET['status'] ?? '';

// One row per account: only the latest activity of each email (the time updates on every new login).
// The filter is applied first, so "Failed" shows each account's latest failed attempt.
$where = "";
$params = [];
if (in_array($filter, ['success','failed','locked'], true)) {
    $where = " WHERE status = ?";
    $params[] = $filter;
}

$sql = "SELECT l.*
        FROM login_logs l
        JOIN (SELECT MAX(id) AS max_id FROM login_logs" . $where . " GROUP BY email) latest
          ON l.id = latest.max_id
        ORDER BY l.id DESC
        LIMIT 200";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll();

$pageTitle = 'Login Activity';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Login Activity</h1>
    </div>
    <div class="mb-3">
        <a href="?" class="btn btn-sm <?= $filter===''?'btn-gold':'btn-outline-gold' ?>">All</a>
        <a href="?status=success" class="btn btn-sm <?= $filter==='success'?'btn-gold':'btn-outline-gold' ?>">Success</a>
        <a href="?status=failed" class="btn btn-sm <?= $filter==='failed'?'btn-gold':'btn-outline-gold' ?>">Failed</a>
        <a href="?status=locked" class="btn btn-sm <?= $filter==='locked'?'btn-gold':'btn-outline-gold' ?>">Locked</a>
    </div>
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead>
                    <tr><th>Email</th><th>Status</th><th>IP Address</th><th>User Agent</th><th>Time</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="5" class="text-center">No logs.</td></tr>
                    <?php else: foreach ($logs as $l): ?>
                        <tr>
                            <td><?= e($l['email']) ?></td>
                            <td><span class="badge badge-<?= $l['status']==='success'?'approved':'rejected' ?>"><?= e($l['status']) ?></span></td>
                            <td><?= e($l['ip_address'] ?? '—') ?></td>
                            <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($l['user_agent'] ?? '') ?></td>
                            <td><?= formatDate($l['logged_at']) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
