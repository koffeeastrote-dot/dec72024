<?php
/**
 * Mark book as returned
 */
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();
require_once __DIR__ . '/../includes/csrf.php';
requirePostWithCsrf('/the_enchanted_archives/admin/borrowings.php');

$id = (int)($_POST['id'] ?? 0);
$pdo = getDB();

try {
    $pdo->beginTransaction();
    
    $stmt = $pdo->prepare("SELECT * FROM borrowings WHERE id = ? AND status = 'approved' FOR UPDATE");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    
    if (!$row) {
        throw new Exception('Borrowing record not found or already returned.');
    }
    
    $stmt = $pdo->prepare("UPDATE borrowings SET status = 'returned', return_date = NOW() WHERE id = ?");
    $stmt->execute([$id]);
    
    $stmt = $pdo->prepare("UPDATE books SET available_copies = available_copies + 1 WHERE id = ?");
    $stmt->execute([$row['book_id']]);
    
    $pdo->commit();
    auditLog('borrowing_returned', 'Borrowing ID ' . $id);
    setFlash('success', 'Book marked as returned. Availability updated.');
} catch (Exception $e) {
    $pdo->rollBack();
    setFlash('error', $e->getMessage());
}

redirect('/the_enchanted_archives/admin/borrowings.php');
