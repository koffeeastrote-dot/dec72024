<?php
/**
 * Admin Dashboard
 */
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pdo = getDB();

$totalBooks = countRows('books');
$availableBooks = (int)$pdo->query('SELECT COALESCE(SUM(available_copies),0) FROM books')->fetchColumn();
$borrowedBooks = (int)$pdo->query("SELECT COUNT(*) FROM borrowings WHERE status = 'approved'")->fetchColumn();
$students = countRows('users', "role = 'student'");
$pending = countRows('borrowings', "status = 'pending'");
$returned = countRows('borrowings', "status = 'returned'");

// Recent borrowings
$stmt = $pdo->query("SELECT b.id, b.status, b.request_date, u.full_name, bk.title 
    FROM borrowings b 
    JOIN users u ON b.user_id = u.id 
    JOIN books bk ON b.book_id = bk.id 
    ORDER BY b.request_date DESC LIMIT 8");
$recentBorrowings = $stmt->fetchAll();

// Recent books
$stmt = $pdo->query("SELECT id, title, author, date_added FROM books ORDER BY date_added DESC LIMIT 5");
$recentBooks = $stmt->fetchAll();

// Recent logins
// One row per account: show only the latest activity of each email (time updates on every new login).
// The full history is still kept in login_logs and shown in admin/login_logs.php.
$stmt = $pdo->query("SELECT l.email, l.status, l.logged_at, l.ip_address
    FROM login_logs l
    JOIN (SELECT MAX(id) AS max_id FROM login_logs GROUP BY email) latest ON l.id = latest.max_id
    ORDER BY l.id DESC LIMIT 8");
$recentLogins = $stmt->fetchAll();

$pageTitle = 'Keeper\'s Dashboard — The Enchanted Archives';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Keeper's Dashboard</h1>
        <div class="user-chip"><i class="bi bi-person-badge"></i> <?= e(currentUserName()) ?></div>
    </div>
    
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card">
                <div class="stat-value"><?= $totalBooks ?></div>
                <div class="stat-label">Total Books</div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card">
                <div class="stat-value"><?= $availableBooks ?></div>
                <div class="stat-label">Available</div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card">
                <div class="stat-value"><?= $borrowedBooks ?></div>
                <div class="stat-label">Borrowed</div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card">
                <div class="stat-value"><?= $students ?></div>
                <div class="stat-label">Students</div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card">
                <div class="stat-value"><?= $pending ?></div>
                <div class="stat-label">Pending</div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card">
                <div class="stat-value"><?= $returned ?></div>
                <div class="stat-label">Returned</div>
            </div>
        </div>
    </div>
    
    <div class="row g-4">
        <div class="col-lg-6">
            <div class="parchment-card p-3">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">Recent Borrowing Requests</h5>
                <?php if (empty($recentBorrowings)): ?>
                    <p class="text-muted mb-0">No requests yet.</p>
                <?php else: ?>
                    <ul class="recent-list">
                        <?php foreach ($recentBorrowings as $r): ?>
                            <li>
                                <span><strong><?= e($r['full_name']) ?></strong> — <?= e($r['title']) ?></span>
                                <span class="badge badge-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <a href="borrowings.php" class="btn btn-outline-gold btn-sm mt-2">View All</a>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="parchment-card p-3">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">Recently Added Books</h5>
                <?php if (empty($recentBooks)): ?>
                    <p class="text-muted mb-0">No books yet.</p>
                <?php else: ?>
                    <ul class="recent-list">
                        <?php foreach ($recentBooks as $b): ?>
                            <li>
                                <span><strong><?= e($b['title']) ?></strong> by <?= e($b['author']) ?></span>
                                <small><?= formatDate($b['date_added'], 'M d') ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                <a href="books.php" class="btn btn-outline-gold btn-sm mt-2">Manage Books</a>
            </div>
        </div>
        <div class="col-12">
            <div class="parchment-card p-3">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">Recent Login Activity</h5>
                <div class="table-responsive">
                    <table class="table table-enchanted table-sm mb-0">
                        <thead>
                            <tr><th>Email</th><th>Status</th><th>IP</th><th>Time</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentLogins as $l): ?>
                                <tr>
                                    <td><?= e($l['email']) ?></td>
                                    <td><span class="badge badge-<?= $l['status'] === 'success' ? 'approved' : 'rejected' ?>"><?= e($l['status']) ?></span></td>
                                    <td><?= e($l['ip_address'] ?? '—') ?></td>
                                    <td><?= formatDate($l['logged_at']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($recentLogins)): ?>
                                <tr><td colspan="4" class="text-center">No activity yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <a href="login_logs.php" class="btn btn-outline-gold btn-sm mt-2">Full Logs</a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>