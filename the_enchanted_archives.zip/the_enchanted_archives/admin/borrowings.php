<?php
/**
 * Borrowing Management
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireAdmin();

$pdo = getDB();
$statusFilter = $_GET['status'] ?? '';

$allowed = ['pending','approved','rejected','returned','overdue'];
$sql = "SELECT b.*, u.full_name, u.email, bk.title, bk.available_copies 
        FROM borrowings b 
        JOIN users u ON b.user_id = u.id 
        JOIN books bk ON b.book_id = bk.id 
        WHERE 1=1";
$params = [];
if (in_array($statusFilter, $allowed, true)) {
    $sql .= " AND b.status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY b.request_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$records = $stmt->fetchAll();

$pageTitle = 'Borrowing Management';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Borrowing Management</h1>
    </div>
    <div class="mb-3">
        <a href="?status=" class="btn btn-sm <?= $statusFilter===''?'btn-gold':'btn-outline-gold' ?>">All</a>
        <?php foreach ($allowed as $s): ?>
            <a href="?status=<?= $s ?>" class="btn btn-sm <?= $statusFilter===$s?'btn-gold':'btn-outline-gold' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead>
                    <tr><th>Student</th><th>Book</th><th>Status</th><th>Requested</th><th>Due</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($records)): ?>
                        <tr><td colspan="6" class="text-center py-3">No records.</td></tr>
                    <?php else: foreach ($records as $r): ?>
                        <tr>
                            <td><?= e($r['full_name']) ?><br><small><?= e($r['email']) ?></small></td>
                            <td><?= e($r['title']) ?></td>
                            <td><span class="badge badge-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span></td>
                            <td><?= formatDate($r['request_date'], 'M d, Y') ?></td>
                            <td><?= formatDate($r['due_date'], 'M d, Y') ?></td>
                            <td>
                                <?php if ($r['status'] === 'pending'): ?>
                                    <form method="post" action="approve_borrowing.php" class="d-inline"><?= csrfField() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button type="submit" class="btn btn-sm btn-success" data-confirm="Approve this request?">Approve</button></form>
                                    <form method="post" action="reject_borrowing.php" class="d-inline"><?= csrfField() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-danger" data-confirm="Reject this request?">Reject</button></form>
                                <?php elseif ($r['status'] === 'approved'): ?>
                                    <form method="post" action="return_book.php" class="d-inline"><?= csrfField() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-gold" data-confirm="Mark as returned?">Return</button></form>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
