<?php
/**
 * Admin - Book Management
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireAdmin();

$pdo = getDB();
$search = trim($_GET['q'] ?? '');
$cat = (int)($_GET['category'] ?? 0);

$sql = "SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE 1=1";
$params = [];
if ($search !== '') {
    $sql .= " AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)";
    $like = '%' . escapeLike($search) . '%';
    $params = array_merge($params, [$like, $like, $like]);
}
if ($cat > 0) {
    $sql .= " AND b.category_id = ?";
    $params[] = $cat;
}
$sql .= " ORDER BY b.date_added DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();

$pageTitle = 'Book Management';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Book Management</h1>
        <a href="add_book.php" class="btn btn-gold btn-sm"><i class="bi bi-plus-lg"></i> Add Book</a>
    </div>
    
    <form method="get" class="row g-2 mb-3">
        <div class="col-md-5">
            <input type="text" name="q" class="form-control" placeholder="Search title, author, ISBN..." value="<?= e($search) ?>">
        </div>
        <div class="col-md-4">
            <select name="category" class="form-select">
                <option value="0">All Categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= $cat === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-outline-gold w-100">Filter</button>
        </div>
    </form>
    
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Qty</th>
                        <th>Available</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($books)): ?>
                        <tr><td colspan="7" class="text-center py-4">No books found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($books as $b): ?>
                            <tr>
                                <td><?= (int)$b['id'] ?></td>
                                <td><strong><?= e($b['title']) ?></strong></td>
                                <td><?= e($b['author']) ?></td>
                                <td><?= e($b['category_name'] ?? '—') ?></td>
                                <td><?= (int)$b['total_quantity'] ?></td>
                                <td><?= (int)$b['available_copies'] ?></td>
                                <td>
                                    <a href="edit_book.php?id=<?= (int)$b['id'] ?>" class="btn btn-sm btn-outline-gold">Edit</a>
                                    <form method="post" action="delete_book.php" class="d-inline"><?= csrfField() ?><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><button type="submit" class="btn btn-sm btn-outline-danger" data-confirm="Delete this book permanently?">Delete</button></form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
