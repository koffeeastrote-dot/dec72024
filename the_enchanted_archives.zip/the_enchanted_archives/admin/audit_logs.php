<?php
/**
 * Audit Log - sensitive actions (password changes, deletes, deactivations, backups...)
 */
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$pdo = getDB();
$logs = [];
$missing = false;
try {
    $logs = $pdo->query('SELECT a.*, u.email FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 300')->fetchAll();
} catch (Throwable $e) {
    $missing = true; // run database_migration_hardening.sql
}

$pageTitle = 'Audit Log';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>Audit Log</h1></div>
    <?php if ($missing): ?>
        <div class="alert alert-warning">The audit table does not exist yet. Run <code>database_migration_hardening.sql</code> in phpMyAdmin.</div>
    <?php endif; ?>
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead>
                    <tr><th>Time</th><th>User</th><th>Action</th><th>Detail</th><th>IP Address</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="5" class="text-center">No entries yet.</td></tr>
                    <?php else: foreach ($logs as $l): ?>
                        <tr>
                            <td><?= formatDate($l['created_at']) ?></td>
                            <td><?= e($l['email'] ?? '—') ?></td>
                            <td><?= e($l['action']) ?></td>
                            <td><?= e($l['detail'] ?? '') ?></td>
                            <td><?= e($l['ip_address'] ?? '—') ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
