<?php
/**
 * Edit Book
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireAdmin();

$pdo = getDB();
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM books WHERE id = ?');
$stmt->execute([$id]);
$book = $stmt->fetch();
if (!$book) {
    setFlash('error', 'Book not found.');
    redirect('/the_enchanted_archives/admin/books.php');
}

$categories = $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    $description = trim($_POST['description'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $year = (int)($_POST['publication_year'] ?? 0) ?: null;
    $qty = max(1, (int)($_POST['total_quantity'] ?? 1));
    
    // Adjust available based on difference
    $diff = $qty - (int)$book['total_quantity'];
    $newAvailable = max(0, (int)$book['available_copies'] + $diff);
    
    if ($title === '' || $author === '') {
        $error = 'Title and author are required.';
    } else {
        $cover = $book['cover_image'];
        if (!empty($_FILES['cover']['name']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
            $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $_FILES['cover']['tmp_name']);
            finfo_close($finfo);
            if (in_array($mime, $allowed, true) && $_FILES['cover']['size'] <= 2 * 1024 * 1024) {
                $ext = match($mime) { 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', default => 'gif' };
                $filename = bin2hex(random_bytes(16)) . '.' . $ext;
                if (move_uploaded_file($_FILES['cover']['tmp_name'], __DIR__ . '/../uploads/books/' . $filename)) {
                    $cover = $filename;
                }
            }
        }
        
        if ($error === '') {
            $stmt = $pdo->prepare("UPDATE books SET title=?, author=?, category_id=?, description=?, isbn=?, publication_year=?, cover_image=?, total_quantity=?, available_copies=? WHERE id=?");
            $stmt->execute([$title, $author, $category_id, $description, $isbn ?: null, $year, $cover, $qty, $newAvailable, $id]);
            auditLog('book_updated', 'Book ID ' . $id);
            setFlash('success', 'Book updated.');
            redirect('/the_enchanted_archives/admin/books.php');
        }
    }
}

$pageTitle = 'Edit Book';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Edit Book</h1>
        <a href="books.php" class="btn btn-outline-gold btn-sm">← Back</a>
    </div>
    <div class="parchment-card p-4" style="max-width:700px;">
        <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
        <form method="post" enctype="multipart/form-data">
            <?= csrfField() ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Title *</label>
                    <input type="text" name="title" class="form-control" required value="<?= e($book['title']) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">ISBN</label>
                    <input type="text" name="isbn" class="form-control" value="<?= e($book['isbn'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Author *</label>
                    <input type="text" name="author" class="form-control" required value="<?= e($book['author']) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Category</label>
                    <select name="category_id" class="form-select">
                        <option value="">— Select —</option>
                        <?php foreach ($categories as $c): ?>
                            <option value="<?= (int)$c['id'] ?>" <?= (int)$book['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Year</label>
                    <input type="number" name="publication_year" class="form-control" value="<?= e($book['publication_year'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Total Quantity</label>
                    <input type="number" name="total_quantity" class="form-control" min="1" value="<?= (int)$book['total_quantity'] ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">New Cover (optional)</label>
                    <input type="file" name="cover" class="form-control" accept="image/*">
                </div>
                <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4"><?= e($book['description'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-gold">Save Changes</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
