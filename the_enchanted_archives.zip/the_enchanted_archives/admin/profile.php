<?php
/**
 * Admin Profile
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/two_factor.php';
requireAdmin();

$pdo = getDB();
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([currentUserId()]);
$user = $stmt->fetch();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    
    if (isset($_POST['update_profile'])) {
        $name = trim($_POST['full_name'] ?? '');
        // The email is the login identity and the target of OTP/reset mails: it is NOT
        // changeable from the profile page (an attacker with a hijacked session could
        // otherwise take over the account). Only the name can be edited here.
        $email = (string)$user['email'];
        if ($name === '') {
            $error = 'Name is required.';
        } else {
            try {
                $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ? WHERE id = ?');
                $stmt->execute([$name, $email, currentUserId()]);
                $_SESSION['full_name'] = $name;
                $success = 'Profile updated.';
                $user['full_name'] = $name;
                $user['email'] = $email;
            } catch (PDOException $e) {
                $error = 'Email may already be in use.';
            }
        }
    }
    
    if (isset($_POST['change_password'])) {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        
        if (!password_verify($current, $user['password'])) {
            $error = 'Current password is incorrect.';
        } elseif (!isStrongPassword($new)) {
            $error = 'New password must be at least 8 characters, include uppercase, lowercase, a number, and must not be a common/breached password.';
        } elseif ($new !== $confirm) {
            $error = 'New passwords do not match.';
        } else {
            $hash = password_hash($new, PASSWORD_BCRYPT);
            $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([$hash, currentUserId()]);
            auditLog('password_changed', 'Changed from profile page');
            $success = 'Password changed successfully.';
        }
    }

    handleTwoFactorPost($pdo, $user, $error, $success);
}

$pageTitle = 'Keeper Profile';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
<style>
    /* Show/hide password eye (same look as login/signup) */
    .input-group-password { position: relative; }
    .input-group-password .form-control { padding-right: 2.75rem; }
    .input-group-password .password-toggle {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #6b5344;
        cursor: pointer;
        padding: 0;
        line-height: 1;
        width: auto;
    }
    .input-group-password .password-toggle:hover,
    .input-group-password .password-toggle:focus-visible { color: var(--mahogany, #492719); outline: none; }
</style>

    <div class="top-bar"><h1>Profile & Settings</h1></div>
    <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>
    
    <div class="row g-4">
        <div class="col-md-6">
            <div class="parchment-card p-4">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">Profile Information</h5>
                <form method="post">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="full_name" class="form-control" value="<?= e($user['full_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" value="<?= e($user['email']) ?>" readonly disabled>
                    </div>
                    <button type="submit" name="update_profile" value="1" class="btn btn-gold">Save Profile</button>
                </form>
            </div>
        </div>
        <div class="col-md-6">
            <div class="parchment-card p-4">
                <h5 class="cinzel mb-3" style="color:var(--mahogany);">Change Password</h5>
                <form method="post">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label class="form-label">Current Password</label>
                        <div class="input-group-password">
                            <input type="password" name="current_password" id="currentPass" class="form-control" required>
                            <button type="button" class="password-toggle" data-toggle-password="#currentPass" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <div class="input-group-password">
                            <input type="password" name="new_password" id="newPass" class="form-control" required minlength="8" data-strength-meter>
                            <button type="button" class="password-toggle" data-toggle-password="#newPass" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm New Password</label>
                        <div class="input-group-password">
                            <input type="password" name="confirm_password" id="confirmPass" class="form-control" required>
                            <button type="button" class="password-toggle" data-toggle-password="#confirmPass" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                    <button type="submit" name="change_password" value="1" class="btn btn-gold">Update Password</button>
                </form>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-1">
        <div class="col-md-6">
            <?php renderTwoFactorCard($user); ?>
        </div>
    </div>
</div>
<script src="<?= e(asset('/the_enchanted_archives/assets/js/password-meter.js')) ?>"></script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>