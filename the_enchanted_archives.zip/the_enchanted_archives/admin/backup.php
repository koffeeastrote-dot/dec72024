<?php
/**
 * Admin — Database Backup (download SQL dump)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireAdmin();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_backup'])) {
    requireCsrf();

    try {
        $pdo = getDB();
        $tables = [];
        $stmt = $pdo->query('SHOW TABLES');
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }

        $dump = "-- The Enchanted Archives — Database Backup\n";
        $dump .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
        $dump .= "-- Host: " . ($_SERVER['HTTP_HOST'] ?? 'localhost') . "\n\n";
        $dump .= "SET FOREIGN_KEY_CHECKS=0;\n";
        $dump .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
        $dump .= "SET time_zone = \"+00:00\";\n\n";

        foreach ($tables as $table) {
            // Structure
            $create = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch(PDO::FETCH_NUM);
            $dump .= "DROP TABLE IF EXISTS `{$table}`;\n";
            $dump .= $create[1] . ";\n\n";

            // Data
            $rows = $pdo->query("SELECT * FROM `{$table}`");
            $colCount = $rows->columnCount();
            while ($r = $rows->fetch(PDO::FETCH_NUM)) {
                $vals = [];
                for ($i = 0; $i < $colCount; $i++) {
                    if ($r[$i] === null) {
                        $vals[] = 'NULL';
                    } else {
                        $vals[] = $pdo->quote((string)$r[$i]);
                    }
                }
                $dump .= "INSERT INTO `{$table}` VALUES (" . implode(',', $vals) . ");\n";
            }
            $dump .= "\n";
        }

        $dump .= "SET FOREIGN_KEY_CHECKS=1;\n";

        auditLog('database_backup_downloaded');
        $filename = 'enchanted_archives_backup_' . date('Ymd_His') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($dump));
        header('Cache-Control: no-store, no-cache, must-revalidate');
        echo $dump;
        exit;
    } catch (Throwable $e) {
        $error = 'Backup failed: ' . $e->getMessage();
    }
}

$pageTitle = 'Database Backup';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar"><h1>Database Backup</h1></div>

    <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?>

    <div class="parchment-card p-4" style="max-width:640px;">
        <h5 class="cinzel mb-3" style="color:var(--mahogany);">Download SQL Dump</h5>
        <p>Creates a full logical backup of the current database (structure + data). Store the file securely offline.</p>
        <ul class="small text-muted">
            <li>Includes all tables (users, books, borrowings, logs, OTPs, etc.)</li>
            <li>Does not include uploaded cover images (those live under <code>uploads/</code>)</li>
            <li>Recommended: run regularly and after major changes</li>
        </ul>
        <form method="post">
            <?= csrfField() ?>
            <button type="submit" name="download_backup" value="1" class="btn btn-gold">
                <i class="bi bi-download"></i> Download Backup Now
            </button>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
