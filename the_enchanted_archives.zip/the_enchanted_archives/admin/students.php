<?php
/**
 * Student Management
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
requireAdmin();

$pdo = getDB();
$search = trim($_GET['q'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_id'])) {
    requireCsrf();
    $tid = (int)$_POST['toggle_id'];
    $stmt = $pdo->prepare("UPDATE users SET is_active = IF(is_active=1,0,1) WHERE id = ? AND role = 'student'");
    $stmt->execute([$tid]);
    auditLog('student_status_toggled', 'Student ID ' . $tid);
    setFlash('success', 'Student status updated.');
    redirect('/the_enchanted_archives/admin/students.php');
}

$sql = "SELECT id, full_name, email, is_active, email_verified, created_at FROM users WHERE role = 'student'";
$params = [];
if ($search !== '') {
    $sql .= " AND (full_name LIKE ? OR email LIKE ?)";
    $like = '%' . escapeLike($search) . '%';
    $params = [$like, $like];
}
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll();

$pageTitle = 'Student Management';
$extraCss = ['/the_enchanted_archives/assets/css/admin.css'];
$bodyClass = 'admin-body';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/admin_sidebar.php';
?>

<div class="main-content">
    <div class="top-bar">
        <h1>Student Management</h1>
    </div>
    <form method="get" class="mb-3">
        <div class="input-group" style="max-width:400px;">
            <input type="text" name="q" class="form-control" placeholder="Search name or email..." value="<?= e($search) ?>">
            <button class="btn btn-outline-gold" type="submit">Search</button>
        </div>
    </form>
    <div class="parchment-card p-3">
        <div class="table-responsive">
            <table class="table table-enchanted table-sm mb-0">
                <thead>
                    <tr><th>Name</th><th>Email</th><th>Verified</th><th>Status</th><th>Joined</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($students)): ?>
                        <tr><td colspan="6" class="text-center py-3">No students found.</td></tr>
                    <?php else: foreach ($students as $s): ?>
                        <tr>
                            <td><?= e($s['full_name']) ?></td>
                            <td><?= e($s['email']) ?></td>
                            <td><?= (int)$s['email_verified'] ? 'Yes' : 'No' ?></td>
                            <td><?= (int)$s['is_active'] ? '<span class="badge badge-approved">Active</span>' : '<span class="badge badge-rejected">Inactive</span>' ?></td>
                            <td><?= formatDate($s['created_at'], 'M d, Y') ?></td>
                            <td>
                                <form method="post" class="d-inline">
                                    <?= csrfField() ?>
                                    <input type="hidden" name="toggle_id" value="<?= (int)$s['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-gold"><?= (int)$s['is_active'] ? 'Deactivate' : 'Activate' ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
