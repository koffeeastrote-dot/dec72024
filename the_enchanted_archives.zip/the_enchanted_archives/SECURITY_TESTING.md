# Security Testing Checklist
## The Enchanted Archives — IT 314

Use this document to manually verify every required security control.

---

### 1. Secure Password Storage

**Test**
1. Register a new student.
2. In phpMyAdmin, inspect the `users.password` column.

**Expected**
- Value begins with `$2y$` (bcrypt).
- Never stores the plain-text password.

---

### 2. Secure Registration

**Test**
- Submit empty fields → validation errors.
- Invalid email → rejected.
- Weak password (e.g. `123`) → rejected.
- Duplicate email → “already registered”.
- Confirm that the role is always `student` (inspect DB).

---

### 3. Secure Login & Generic Errors

**Test**
1. Enter a non-existent email + any password.
2. Enter a valid email + wrong password.

**Expected**
- Both show exactly: **“Invalid email or password.”**
- No indication whether the email exists.

---

### 4. Brute-Force Protection / Account Lockout

**Test**
1. Use a known valid student email.
2. Submit wrong password 5 times.
3. On the 6th attempt observe the message.

**Expected**
- After 5 failures the account is locked for 15 minutes.
- Message indicates temporary lock (without revealing other details).
- Successful login after lockout expires resets the counter.
- Check `users.lockout_until` and `login_logs` / `login_attempts`.

---

### 5. Session Management

**Test**
1. Log in.
2. Note the session cookie (`PHPSESSID`).
3. Log out.
4. Try to reuse the old session cookie or navigate to a protected page.

**Expected**
- Protected pages redirect to login.
- Cookie is cleared / invalidated.
- After login a new session ID is issued (`session_regenerate_id`).

---

### 6. Role-Based Access Control

**Test**
1. Log in as student.
2. Manually visit `/the_enchanted_archives/admin/dashboard.php`.

**Expected**
- Access denied / redirected.
- Admin pages call `requireAdmin()`; student pages call `requireStudent()`.

---

### 7. SQL Injection Prevention

**Test (login at forms)**
- Sa login email field, i-type: `' OR '1'='1`, `admin'--`, `" OR ""="`, `' OR 1=1-- -`
- Sa sign-up at forgot-password email, i-type: `x'; DROP TABLE users;--`
- Sa password field: `' OR '1'='1`

**Test (search at URL parameters)**
- Student/Admin Books search (`q`): `' OR '1'='1`, `%' UNION SELECT 1,2,3,4,5,6,7,8,9,10,11-- -`, `%`, `_`
- URL: `book_details.php?id=1 OR 1=1`, `book_details.php?id=1'`, `admin/borrowings.php?status=' OR 1=1--`
- Time-based: `q=1' AND SLEEP(5)-- -` (hindi dapat maantala ang response)

**Expected**
- Walang unexpected data, walang SQL error sa screen, buo ang mga table, hindi nakakapasok sa login.
- Search na `%` o `_` ay hinahanap bilang plain text (hindi wildcard).
- Lahat ng query ay PDO prepared statements; ang DB error ay hindi ipinapakita (`APP_DEBUG=false`).
- Kapag gumamit ng automated tool (sqlmap), mabi-block ng IP rate limit ang login pagkatapos ng 15 requests. Inaasahan ito.

---

### 8. Cross-Site Scripting (XSS)

**Test**
- Register a user whose name is `<script>alert(1)</script>`.
- Or insert the payload into a book title via admin.

**Expected**
- Script is rendered as text (escaped by `e()` / `htmlspecialchars`).
- No alert executes.

---

### 9. CSRF Protection

**Test**
1. Open a form (e.g. change password).
2. Remove or alter the `csrf_token` field and submit.

**Expected**
- Request is rejected (403 or error message about invalid security token).

---

### 10. Secure File Upload

**Test**
- Try uploading a `.php` file or non-image as book cover.
- Try a very large file (>2 MB).

**Expected**
- Only JPEG/PNG/WebP/GIF accepted (MIME check).
- Filename is randomized.
- `uploads/books/.htaccess` blocks PHP execution.

---

### 11. Password Reset OTP

**Test**
1. Request password reset for a known email.
2. Enter wrong OTP multiple times.
3. Wait >5 minutes and try the old OTP.
4. Use a valid OTP once, then try it again.

**Expected**
- Wrong OTP increments attempt counter; after 5 attempts locked.
- Expired OTP rejected.
- Used OTP cannot be reused.
- Only the hash of the OTP is stored.

---

### 12. Login Activity Monitoring

**Test**
1. Perform successful and failed logins.
2. As admin open **Login Activity**.

**Expected**
- Entries show email, status (`success`/`failed`/`locked`), IP, timestamp, user-agent.

---

### 13. OTP Email Security

**Test**
- View page source / Network tab while on the verification page.
- Check application logs.

**Expected**
- The clear-text OTP never appears in HTML, JavaScript, or logs.
- Only a bcrypt hash is stored in `otp_verifications`.

---

### 14. Unverified Account Login

**Test**
1. Register but do not enter the OTP.
2. Attempt to log in.

**Expected**
- Login is blocked; user is directed to the OTP verification page.

---

**Document any failures and the corresponding code locations before submission.**

---

### 15. Password Strength Meter & Common/Breached Check

**Test**
1. On registration / password change / reset-link form, type a weak password (`password`, `12345678`).
2. Type a strong password (`Library#2026Secure`).

**Expected**
- Weak / common passwords are rejected server-side with a clear message.
- Live strength meter (where present) updates label and bar color.
- `isStrongPassword()` requires length ≥ 8, upper + lower + digit, and not in the common list.

---

### 16. Password Reset via Expiring One-Time Link

**Test**
1. Request reset with method “One-time link”.
2. Open the emailed link within 30 minutes and set a new password.
3. Try the same link again after success.
4. Wait >30 minutes (or manually expire) and try the link.

**Expected**
- Link works once, then is marked used.
- Expired / reused links are rejected.
- Only the bcrypt hash of the token is stored in `password_resets`.

---

### 17. Optional Login Two-Factor Authentication (Email OTP)

**Test**
1. In Profile, enable “Email OTP on login” (confirm with current password).
2. Log out and log in with correct password.
3. Observe redirect to 2FA page and email receipt.
4. Enter correct OTP → full login.
5. Disable 2FA and confirm normal login again.

**Expected**
- Password alone is not enough when 2FA is enabled.
- OTP is rate-limited and single-use; only hash stored.

---

### 18. Rate Limiting (Password Reset / Sensitive Actions)

**Test**
1. Submit the forgot-password form more than 5 times quickly for the same email.
2. Observe block message with remaining time.

**Expected**
- Further requests are blocked for the configured window.
- `rate_limits` table records the attempts.

---

### 19. Database Backup (Admin)

**Test**
1. As admin open **Database Backup**.
2. Click “Download Backup Now”.
3. Open the downloaded `.sql` file.

**Expected**
- Valid SQL containing structure and data of all tables.
- CSRF protected; only admins can access the page.

---

### 20. Admin actions are POST + CSRF

**Test**
1. As admin, buksan sa browser (GET): `/admin/delete_book.php?id=1`, `/admin/approve_borrowing.php?id=1`.
2. Subukan ding mag-POST nang walang `csrf_token`.

**Expected**
- Walang nabubura o na-aapprove. Ang POST na walang token ay 403.

---

### 21. Rate limit cannot be bypassed with fake headers

**Test**
1. Mag-send ng 20 maling login, bawat isa ay may ibang `X-Forwarded-For` (hal. gamit ang browser dev tools o curl `-H`).

**Expected**
- Naka-block pa rin pagkatapos ng 15 (ang totoong IP ang binibilang).

---

### 22. Idle timeout, session hijack, deactivated user

**Test**
1. Mag-login, hayaang idle ng higit 30 minuto (o ibaba muna ang `SESSION_IDLE_TIMEOUT` sa `config/security.php`), mag-refresh.
2. Kopyahin ang session cookie sa ibang browser.
3. Habang naka-login ang estudyante, i-deactivate siya bilang admin, tapos mag-refresh ang estudyante.

**Expected**
- Naka-logout sa lahat ng tatlo.

---

### 23. Email enumeration

**Test**
- Sa login, forgot password (OTP at link) at sign-up, ihambing ang sagot sa totoong email at sa email na wala sa system.

**Expected**
- Pareho ang message, pareho ang screen.

---

### 24. Reset by OTP (takeover bug)

**Test**
1. Sa Browser A: mag-request ng OTP reset para sa account mo, i-verify ang OTP mo.
2. Sa parehong browser, mag-request ng reset para sa account ng iba, tapos subukang pumunta sa `reset_password.php` at magtakda ng password.

**Expected**
- Hindi pwedeng magtakda ng bagong password nang walang OTP ng account na iyon.

---

### 25. Terms / Privacy at Audit Log

**Test**
1. Subukang mag-sign-up nang hindi tinitick ang Terms.
2. Magpalit ng password, mag-delete ng libro, mag-deactivate ng estudyante, tapos buksan ang **Audit Log** (admin).

**Expected**
- Na-block ang sign-up. May entry ang bawat sensitive action.
