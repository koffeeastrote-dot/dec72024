# The Enchanted Archives
## Secure Library Management and Borrowing System

**Course:** IT 314 – Information Assurance and Security 1  
**Academic Year:** First Semester, AY 2026–2027  
**Technology Stack:** PHP 8.x, MySQL/MariaDB, HTML5, CSS3, JavaScript, Bootstrap 5, PHPMailer, XAMPP

---

### 1. Project Description

The Enchanted Archives is a full-featured, security-focused library management and borrowing system with a dark-academia / gothic magical library aesthetic. It supports:

- Magical opening invitation page with interactive wax-seal animation
- Secure student registration with Gmail SMTP OTP email verification
- Role-based access (Administrator / Student)
- Complete book catalog management with cover uploads
- Borrowing workflow (request → approve/reject → return)
- Brute-force protection with account lockout
- Login activity monitoring
- CSRF protection, prepared statements, password hashing (bcrypt)
- Password reset via OTP

---

### 2. System Features

**Authentication & Security**
- Bcrypt password hashing (`password_hash` / `password_verify`)
- CSRF tokens on all state-changing forms
- Session regeneration on login, HttpOnly + SameSite cookies
- Account lockout after 5 failed attempts (15-minute duration)
- Generic login error messages
- OTP email verification (registration & password reset)
- Role-based access control enforced server-side

**Administrator**
- Dashboard with live statistics
- Book CRUD (add, edit, delete, search, filter, cover upload)
- Student management (activate/deactivate)
- Borrowing approval / rejection / return with quantity tracking
- Login activity logs (success / failed / locked)

**Student**
- Browse & search catalog
- Request available books
- View personal borrowing history and statuses
- Profile & password management

---

### 3. Technologies Used

- PHP 8.2+ (compatible with current XAMPP)
- MySQL / MariaDB (InnoDB)
- Bootstrap 5.3
- PHPMailer 6.x (bundled in `/vendor`)
- Google Fonts (Cinzel, Cormorant Garamond)
- Vanilla JavaScript for animations and OTP inputs

---

### 4. Required Software

1. **XAMPP** (or equivalent Apache + MySQL + PHP stack)  
   Download: https://www.apachefriends.org/

2. A modern browser (Chrome, Firefox, Edge, Safari)

3. (Optional but required for OTP emails) A Gmail account with 2-Step Verification and an App Password

---

### 5. Installation Steps

#### Step 1 – Extract the Project

1. Extract `The_Enchanted_Archives.zip`.
2. Copy the folder `the_enchanted_archives` into your XAMPP `htdocs` directory:

```
C:\xampp\htdocs\the_enchanted_archives
```

#### Step 2 – Start Services

1. Open the **XAMPP Control Panel**.
2. Start **Apache**.
3. Start **MySQL**.

#### Step 3 – Create & Import the Database

1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Click **Import**.
3. Choose the file `database.sql` located inside the project folder.
4. Click **Go**.

This creates the database `enchanted_archives_db` with all tables, sample categories, and sample books.

#### Step 4 – Database Connection

The default configuration in `config/database.php` uses:

```
Host: localhost
Database: enchanted_archives_db
User: root
Password: (empty)
```

If your MySQL root password is not empty, edit `config/database.php` accordingly.

#### Step 5 – Gmail SMTP (for OTP emails)

1. Open `config/smtp.php`.
2. Enable **2-Step Verification** on your Google Account.
3. Generate an **App Password** (Google Account → Security → App passwords → Mail).
4. Fill in:

```php
define('SMTP_USERNAME', 'yourname@gmail.com');
define('SMTP_PASSWORD', 'your-16-char-app-password');
define('MAIL_FROM_ADDRESS', 'yourname@gmail.com');
```

**Important:** Never commit real credentials. The file is listed in `.gitignore`.

If SMTP is not configured, registration still works but OTP emails will not be delivered. The application **never** silently bypasses OTP verification.

#### Step 6 – First Run (Administrator Setup)

1. Open the site: **http://localhost/the_enchanted_archives/**
2. Because no administrator exists yet, you will be redirected to the **First Keeper Setup** page.
3. Create the initial admin account (name, email, strong password).
4. You will then be taken to the login page.

#### Step 7 – Test Student Registration

1. Click **Sign Up**.
2. Register with a real Gmail address (if SMTP is configured).
3. Enter the 6-digit OTP received by email.
4. Log in as the student.

---

### 6. Default / Test Accounts

No default admin password is hardcoded. You create the first admin during setup.

For testing without real email:

- Create the admin via setup.
- Manually set `email_verified = 1` in the `users` table for a test student if needed, **or** configure SMTP.

---

### 7. URL

```
http://localhost/the_enchanted_archives/
```

---

### 8. Security Features Checklist (see also SECURITY_TESTING.md)

| Feature                        | Implementation                                      |
|--------------------------------|-----------------------------------------------------|
| Password hashing               | `password_hash(..., PASSWORD_BCRYPT)`               |
| Prepared statements (PDO)      | All queries                                         |
| CSRF protection                | Token on every POST form                            |
| Session security               | HttpOnly, SameSite, regenerate on login, timeout    |
| Brute-force protection         | 5 failures → 15 min lockout                         |
| Role-based access              | `requireAdmin()` / `requireStudent()`               |
| Output escaping                | `htmlspecialchars` via `e()`                        |
| File upload validation         | MIME + size + random filename + .htaccess           |
| OTP security                   | Hashed, 5-min expiry, attempt limit, one-time       |
| Generic error messages         | Login does not reveal account existence             |

---

### 9. Troubleshooting

| Problem                          | Solution                                                                 |
|----------------------------------|--------------------------------------------------------------------------|
| Blank page / 500                 | Check Apache error log; ensure PHP 8.x and PDO MySQL extension enabled  |
| Database connection failed       | Verify MySQL is running and credentials in `config/database.php`        |
| OTP not received                 | Configure `config/smtp.php` with a valid Gmail App Password             |
| CSS/JS not loading               | Confirm the project is at `/the_enchanted_archives/` (folder name)      |
| Upload fails                     | Ensure `uploads/books/` is writable by the web server                   |
| Session issues after logout      | Clear browser cookies for localhost                                     |

---

### 10. Project Structure (key paths)

```
the_enchanted_archives/
├── index.php                 # Magical opening page
├── database.sql
├── README.md
├── SECURITY_TESTING.md
├── config/
│   ├── database.php
│   └── smtp.php
├── includes/                 # Shared functions, auth, CSRF, layout
├── auth/                     # Login, register, OTP, reset, setup
├── admin/                    # Full admin dashboard & modules
├── student/                  # Student dashboard & catalog
├── assets/css|js|images/
├── uploads/books/
└── vendor/                   # PHPMailer (bundled)
```

---

### 11. License & Academic Use

This project was created for academic purposes (IT 314).  
All sample book data is fictional.  
Do not use real personal data in testing.

---

**Enjoy the Archives.** ✧

---

### Report a Problem, Feedback & Security-alert buttons (new)

Run `database_migration_reports.sql` once in phpMyAdmin (fresh installs of `database.sql` already include it).

- **Report a Problem** (student sidebar) – report suspicious activity, unauthorized access, errors or technical issues. Status tracking: Pending, Under Review, Resolved, Rejected.
- **Send Feedback** (student sidebar) – suggestions and comments about the library system.
- **Admin → Reports / Feedback** – view, respond to and update the status of reports. Admins receive a Gmail notification for every new report.
- **Suspicious-login email** (sent when an account is locked after 5 failed attempts, locked for a random 15–30 minutes) has two buttons:
  - **Report** – opens a pre-filled report form (one-time link) that goes to the admins.
  - **Yes, it's me** – one-time link to a secure password reset. A 6-digit code (email OTP or authenticator app) is asked **only if** the account has two-factor turned on; otherwise no OTP is sent.
- Set `APP_BASE_URL` in `config/smtp.php` (e.g. `http://localhost` or `http://localhost:8080`) so the email buttons point to your site.

---

## Hardening update (Nobyembre 2026): ano ang kailangan mong gawin

1. **phpMyAdmin → SQL tab:** i-run ang `database_migration_hardening.sql` (para sa Audit Log at sa Terms consent timestamp).
2. **Email (Gmail):** kopyahin ang `config/smtp.local.php.example` papuntang `config/smtp.local.php`, at ilagay ang email mo at **bagong** Gmail App Password. Ang lumang App Password na dating nasa `config/smtp.php` ay dapat i-**revoke** sa Google Account → Security → App passwords.
3. Tingnan ang `config/security.php` (`APP_DEBUG`, `FORCE_HTTPS`, `TRUSTED_PROXIES`, session limits).
4. Basahin ang `SECURITY_CHECKLIST.md` para sa buong status at listahan ng mga pwede pang i-implement.
