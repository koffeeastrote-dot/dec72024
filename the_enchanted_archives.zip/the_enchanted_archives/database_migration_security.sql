-- ============================================================
-- Migration: apply new security features
-- Run this ONCE in phpMyAdmin (SQL tab) on enchanted_archives_db
-- ============================================================

USE `enchanted_archives_db`;

-- 1. Optional email OTP 2FA flag on users
-- (Safe to re-run: ignore error if column already exists)
SET @col_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = 'enchanted_archives_db'
    AND TABLE_NAME = 'users'
    AND COLUMN_NAME = 'two_factor_enabled'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE `users` ADD COLUMN `two_factor_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Email OTP 2FA on login'' AFTER `lockout_until`',
  'SELECT ''two_factor_enabled already exists'' AS info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 2. Expand OTP purposes for login 2FA
ALTER TABLE `otp_verifications`
  MODIFY COLUMN `purpose` enum('registration','password_reset','login_2fa') NOT NULL DEFAULT 'registration';

-- 3. Rate limiting table
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `action_key` varchar(100) NOT NULL,
  `identifier` varchar(100) NOT NULL COMMENT 'IP or email',
  `attempts` int(11) NOT NULL DEFAULT 1,
  `window_start` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `blocked_until` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_action_id` (`action_key`, `identifier`),
  KEY `idx_blocked` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Authenticator-app (TOTP) 2FA columns on users
SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'enchanted_archives_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'totp_enabled');
SET @sql = IF(@c = 0,
  'ALTER TABLE `users` ADD COLUMN `totp_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Authenticator app 2FA'' AFTER `two_factor_enabled`, ADD COLUMN `totp_secret` varchar(64) DEFAULT NULL AFTER `totp_enabled`, ADD COLUMN `totp_last_step` bigint DEFAULT NULL COMMENT ''Last accepted time-step (replay protection)'' AFTER `totp_secret`',
  'SELECT ''totp columns already exist'' AS info');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'Migration complete. rate_limits table, two_factor_enabled and TOTP columns are ready.' AS status;
