-- The Enchanted Archives Database
-- Secure Library Management and Borrowing System
-- Compatible with MySQL/MariaDB in XAMPP

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `enchanted_archives_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `enchanted_archives_db`;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student') NOT NULL DEFAULT 'student',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `failed_login_attempts` int(11) NOT NULL DEFAULT 0,
  `lockout_until` datetime DEFAULT NULL,
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Email OTP 2FA on login',
  `totp_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Authenticator app 2FA',
  `totp_secret` varchar(64) DEFAULT NULL,
  `totp_last_step` bigint DEFAULT NULL COMMENT 'Last accepted TOTP time-step (replay protection)',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_email_verified` (`email_verified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `categories`
-- --------------------------------------------------------
CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `books`
-- --------------------------------------------------------
CREATE TABLE `books` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(150) NOT NULL,
  `category_id` int(11) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `publication_year` year(4) DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `total_quantity` int(11) NOT NULL DEFAULT 1,
  `available_copies` int(11) NOT NULL DEFAULT 1,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_title` (`title`),
  KEY `idx_author` (`author`),
  CONSTRAINT `fk_books_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `borrowings`
-- --------------------------------------------------------
CREATE TABLE `borrowings` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `book_id` int(11) UNSIGNED NOT NULL,
  `status` enum('pending','approved','rejected','returned','overdue') NOT NULL DEFAULT 'pending',
  `request_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `borrow_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_borrowings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_borrowings_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `login_attempts`
-- --------------------------------------------------------
CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `attempted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_attempted` (`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `login_logs`
-- --------------------------------------------------------
CREATE TABLE `login_logs` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status` enum('success','failed','locked') NOT NULL,
  `logged_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_logged` (`logged_at`),
  CONSTRAINT `fk_login_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `password_resets`
-- --------------------------------------------------------
CREATE TABLE `password_resets` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `otp_verifications`
-- --------------------------------------------------------
CREATE TABLE `otp_verifications` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `purpose` enum('registration','password_reset','login_2fa') NOT NULL DEFAULT 'registration',
  `expires_at` datetime NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Sample Categories
-- --------------------------------------------------------
INSERT INTO `categories` (`name`, `description`) VALUES
('Arcane Arts', 'Books on magical theory, spells, and enchantments'),
('Ancient Histories', 'Chronicles of bygone eras and forgotten kingdoms'),
('Potion Craft', 'Guides to alchemical mixtures and elixirs'),
('Creature Lore', 'Compendiums of magical beasts and beings'),
('Divination', 'Tomes on prophecy, stars, and foresight'),
('Dark Arts Defense', 'Treatises on protection against malevolent magic'),
('Herbology', 'Studies of magical plants and their properties'),
('Runes & Symbols', 'Texts on ancient scripts and their power');

-- --------------------------------------------------------
-- Sample Books (fictional)
-- --------------------------------------------------------
INSERT INTO `books` (`title`, `author`, `category_id`, `description`, `isbn`, `publication_year`, `total_quantity`, `available_copies`) VALUES
('The Whispering Codex', 'Elara Moonwhisper', 1, 'A foundational text on the language of spells and the binding of intent.', '978-0-123456-01-1', 1892, 5, 5),
('Chronicles of the Shadow Realms', 'Thorne Blackwood', 2, 'An exhaustive history of the realms beyond the veil of ordinary sight.', '978-0-123456-02-8', 1901, 3, 3),
('Elixir of Eternal Dusk', 'Seraphine Vale', 3, 'Detailed recipes for potions that alter the flow of time and memory.', '978-0-123456-03-5', 1878, 4, 4),
('Bestiary of the Forgotten Woods', 'Lysander Grey', 4, 'Illustrations and accounts of creatures rarely seen by mortal eyes.', '978-0-123456-04-2', 1915, 6, 6),
('Stars of the Unwritten Future', 'Isolde Nightingale', 5, 'A guide to reading the constellations for glimpses of what may come.', '978-0-123456-05-9', 1889, 2, 2),
('Wards Against the Night', 'Cassian Thorne', 6, 'Practical defenses for the solitary mage against dark forces.', '978-0-123456-06-6', 1923, 5, 5),
('Garden of Whispering Leaves', 'Mira Greenleaf', 7, 'Cultivation and uses of plants that respond to magical intent.', '978-0-123456-07-3', 1907, 4, 4),
('The Rune-Carved Path', 'Aldric Stonehand', 8, 'Interpretation and inscription of runes for protection and power.', '978-0-123456-08-0', 1865, 3, 3),
('Grimoire of Silent Incantations', 'Vesper Quill', 1, 'Spells that require no spoken word, only pure concentration.', '978-0-123456-09-7', 1899, 3, 3),
('Tales from the Obsidian Tower', 'Rowan Ashcroft', 2, 'Legends and true accounts from the most secluded magical stronghold.', '978-0-123456-10-3', 1912, 4, 4);

-- --------------------------------------------------------
-- Rate limiting (generic IP / action based)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `action_key` varchar(100) NOT NULL,
  `identifier` varchar(100) NOT NULL COMMENT 'IP or email',
  `attempts` int(11) NOT NULL DEFAULT 1,
  `window_start` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `blocked_until` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_action_id` (`action_key`, `identifier`),
  KEY `idx_blocked` (`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;


-- --------------------------------------------------------
-- Report a Problem / Feedback / Security alert links
-- (same as database_migration_reports.sql)
-- --------------------------------------------------------
-- 1. Problem reports (students / alert-email links -> admin)
CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `reporter_email` varchar(191) NOT NULL,
  `category` enum('suspicious_activity','unauthorized_access','error','technical_issue') NOT NULL DEFAULT 'technical_issue',
  `subject` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `source` enum('app','email_alert') NOT NULL DEFAULT 'app',
  `ip_address` varchar(45) DEFAULT NULL,
  `status` enum('pending','under_review','resolved','rejected') NOT NULL DEFAULT 'pending',
  `admin_response` text DEFAULT NULL,
  `responded_by` int(11) UNSIGNED DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reports_status` (`status`),
  KEY `idx_reports_user` (`user_id`),
  KEY `idx_reports_created` (`created_at`),
  CONSTRAINT `fk_reports_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_reports_responder` FOREIGN KEY (`responded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Feedback (suggestions / comments about the library system)
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `category` enum('suggestion','comment') NOT NULL DEFAULT 'suggestion',
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_feedback_user` (`user_id`),
  KEY `idx_feedback_created` (`created_at`),
  CONSTRAINT `fk_feedback_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. One-time links used by the "Suspicious Login Activity" email buttons
--    (only a SHA-256 hash of the token is stored)
CREATE TABLE IF NOT EXISTS `security_alert_tokens` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `action` enum('report','its_me') NOT NULL,
  `token_hash` char(64) NOT NULL,
  `context` varchar(500) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_alert_token_hash` (`token_hash`),
  KEY `idx_alert_user` (`user_id`),
  CONSTRAINT `fk_alert_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

