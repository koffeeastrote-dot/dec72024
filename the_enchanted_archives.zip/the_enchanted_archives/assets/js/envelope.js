/**
 * Opening envelope animation
 */
document.addEventListener('DOMContentLoaded', function () {
    const seal = document.getElementById('waxSeal');
    const envelope = document.getElementById('envelope');
    const invitation = document.getElementById('invitation');
    const skipBtn = document.getElementById('skipAnimation');
    const inner = document.getElementById('letterInner');
    const tabs = document.querySelectorAll('.letter-tabs button');
    const panels = document.querySelectorAll('.letter-panel');

    // The letter is pulled out of the envelope just far enough that the whole
    // form sits above the front pocket. Measured in px so it fits any screen.
    function fitLetter() {
        if (!inner || !envelope) return;
        const w = envelope.offsetWidth;
        // inner already includes a bottom "tuck" area (hidden behind the pocket),
        // so the letter just has to be as tall as inner and end at 46cqw.
        const needed = inner.offsetHeight;
        const minLift = w * 0.46;
        const lift = Math.max(minLift, needed - w * 0.46);
        envelope.style.setProperty('--lift', lift + 'px');
    }

    function openEnvelope(instant) {
        if (envelope.classList.contains('open')) return;
        if (seal) seal.classList.add('clicked');
        fitLetter();
        setTimeout(() => {
            envelope.classList.add('open');
            if (invitation) {
                invitation.classList.add('visible');
            }
            const first = document.getElementById('envEmail');
            if (first) setTimeout(() => first.focus({ preventScroll: true }), 1300);
        }, instant === true ? 0 : 400);
    }

    // Login / Sign Up tabs inside the letter
    tabs.forEach(tab => {
        tab.addEventListener('click', function () {
            tabs.forEach(t => { t.classList.toggle('active', t === tab); t.setAttribute('aria-selected', t === tab); });
            panels.forEach(p => p.classList.toggle('active', p.id === tab.dataset.panel));
            fitLetter();
        });
    });
    // When leaving to "Forgot your password?", remember that the envelope is open,
    // so the browser Back button (and the Back link) returns to the OPEN envelope.
    document.querySelectorAll('.invitation a[href*="forgot_password"]').forEach(a => {
        a.addEventListener('click', function () {
            try { history.replaceState(null, '', window.location.pathname + '?open=1'); } catch (e) {}
        });
    });
    // Restored from the back/forward cache or history: make sure it is open
    window.addEventListener('pageshow', function (ev) {
        if (ev.persisted && !envelope.classList.contains('open')) {
            envelope.classList.add('instant');
            openEnvelope(true);
            setTimeout(() => envelope.classList.remove('instant'), 150);
        }
    });
    window.addEventListener('resize', fitLetter);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitLetter);
    window.addEventListener('load', fitLetter);
    fitLetter();

    // Coming back from Forgot Password / a failed login: open right away, no animation
    const params = new URLSearchParams(window.location.search);
    if (params.get('tab') === 'signup') {
        const st = document.getElementById('tabSignup');
        if (st) st.click();
    }
    if (params.get('open') === '1') {
        envelope.classList.add('instant');
        openEnvelope(true);
        setTimeout(() => envelope.classList.remove('instant'), 150);
    }

    if (seal) {
        seal.addEventListener('click', () => openEnvelope());
        seal.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openEnvelope();
            }
        });
    }

    if (skipBtn) {
        skipBtn.addEventListener('click', function (e) {
            e.preventDefault();
            openEnvelope();
        });
    }

    // Reduced motion: show invitation immediately
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        openEnvelope();
    }

    // Create floating particles
    const particlesContainer = document.querySelector('.particles');
    if (particlesContainer && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        for (let i = 0; i < 25; i++) {
            const p = document.createElement('div');
            p.className = 'particle';
            p.style.left = Math.random() * 100 + '%';
            p.style.top = Math.random() * 100 + '%';
            p.style.animationDelay = (Math.random() * 10) + 's';
            p.style.animationDuration = (8 + Math.random() * 8) + 's';
            p.style.width = p.style.height = (2 + Math.random() * 3) + 'px';
            particlesContainer.appendChild(p);
        }
    }
});
