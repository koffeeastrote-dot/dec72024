/**
 * The Enchanted Archives - Main JS
 */
document.addEventListener('DOMContentLoaded', function () {
    // Auto-hide toasts
    const toasts = document.querySelectorAll('.toast');
    toasts.forEach(t => {
        setTimeout(() => {
            const bsToast = bootstrap.Toast.getOrCreateInstance(t);
            bsToast.hide();
        }, 5000);
    });

    // Password visibility toggles
    document.querySelectorAll('[data-toggle-password]').forEach(btn => {
        btn.addEventListener('click', function () {
            const target = document.querySelector(this.dataset.togglePassword);
            if (!target) return;
            const isPass = target.type === 'password';
            target.type = isPass ? 'text' : 'password';
            this.innerHTML = isPass ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
        });
    });

    // Confirm delete
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', function (e) {
            if (!confirm(this.dataset.confirm || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });
});
