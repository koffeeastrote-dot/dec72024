/**
 * Live password strength meter.
 * Usage: <input type="password" data-strength-meter> — a meter is inserted after the field's wrapper.
 * Mirrors the server rules (length, upper/lower/digit, common list). The server remains the authority.
 */
(function () {
    var COMMON = ["password","password1","password123","123456","12345678","123456789","qwerty","abc123","admin","letmein","welcome","monkey","dragon","master","login","passw0rd","changeme","secret","admin123","root","test","guest","111111","000000","qwerty123","iloveyou","sunshine","football","shadow","superman","hunter2","trustno1","enchanted","hogwarts","library1","p@ssw0rd","p@ssword1","welcome1"];
    var LABELS = ["Very Weak","Weak","Fair","Good","Strong","Excellent"];
    var COLORS = ["#c0392b","#e67e22","#f1c40f","#27ae60","#1abc9c","#2ecc71"];

    function score(pw) {
        var s = 0;
        if (pw.length >= 8) s++;
        if (pw.length >= 12) s++;
        if (/[a-z]/.test(pw)) s++;
        if (/[A-Z]/.test(pw)) s++;
        if (/[0-9]/.test(pw)) s++;
        if (/[^A-Za-z0-9]/.test(pw)) s++;
        if (COMMON.indexOf(pw.toLowerCase()) !== -1) s = 0;
        return Math.min(s, 5);
    }

    function attach(input) {
        var anchor = input.closest('.input-group-password') || input;
        var box = document.createElement('div');
        box.className = 'mt-2';
        box.style.display = 'none';
        box.setAttribute('aria-live', 'polite');
        box.innerHTML = '<div style="height:6px;background:#ddd;border-radius:3px;overflow:hidden;">' +
            '<div data-bar style="height:100%;width:0;transition:width .2s,background .2s;"></div></div>' +
            '<small data-label class="text-muted"></small>';
        anchor.parentNode.insertBefore(box, anchor.nextSibling);
        var bar = box.querySelector('[data-bar]');
        var label = box.querySelector('[data-label]');
        input.addEventListener('input', function () {
            var pw = input.value;
            if (!pw) { box.style.display = 'none'; return; }
            box.style.display = 'block';
            var s = score(pw);
            bar.style.width = (s / 5 * 100) + '%';
            bar.style.background = COLORS[s];
            label.textContent = LABELS[s] + (COMMON.indexOf(pw.toLowerCase()) !== -1 ? ' — too common / breached' : '');
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('input[data-strength-meter]').forEach(attach);
    });
})();
