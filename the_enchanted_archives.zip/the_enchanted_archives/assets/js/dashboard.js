/**
 * Dashboard helpers
 */
document.addEventListener('DOMContentLoaded', function () {
    // OTP input auto-advance
    const otpInputs = document.querySelectorAll('.otp-inputs input');
    if (otpInputs.length) {
        otpInputs.forEach((input, idx) => {
            input.addEventListener('input', function () {
                this.value = this.value.replace(/[^0-9]/g, '').slice(0, 1);
                if (this.value && idx < otpInputs.length - 1) {
                    otpInputs[idx + 1].focus();
                }
            });
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Backspace' && !this.value && idx > 0) {
                    otpInputs[idx - 1].focus();
                }
            });
            input.addEventListener('paste', function (e) {
                e.preventDefault();
                const data = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
                data.split('').forEach((ch, i) => {
                    if (otpInputs[i]) otpInputs[i].value = ch;
                });
                if (otpInputs[Math.min(data.length, 5)]) {
                    otpInputs[Math.min(data.length, 5)].focus();
                }
            });
        });
    }
});
