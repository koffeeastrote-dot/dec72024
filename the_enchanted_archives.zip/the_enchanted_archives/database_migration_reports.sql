-- ============================================================
-- Migration: Report a Problem, Send Feedback, Security-alert links
-- Run this ONCE in phpMyAdmin (SQL tab) on enchanted_archives_db
-- (Safe to re-run: uses CREATE TABLE IF NOT EXISTS)
-- ============================================================

USE `enchanted_archives_db`;

-- 1. Problem reports (students / alert-email links -> admin)
CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `reporter_email` varchar(191) NOT NULL,
  `category` enum('suspicious_activity','unauthorized_access','error','technical_issue') NOT NULL DEFAULT 'technical_issue',
  `subject` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `source` enum('app','email_alert') NOT NULL DEFAULT 'app',
  `ip_address` varchar(45) DEFAULT NULL,
  `status` enum('pending','under_review','resolved','rejected') NOT NULL DEFAULT 'pending',
  `admin_response` text DEFAULT NULL,
  `responded_by` int(11) UNSIGNED DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reports_status` (`status`),
  KEY `idx_reports_user` (`user_id`),
  KEY `idx_reports_created` (`created_at`),
  CONSTRAINT `fk_reports_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_reports_responder` FOREIGN KEY (`responded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Feedback (suggestions / comments about the library system)
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `category` enum('suggestion','comment') NOT NULL DEFAULT 'suggestion',
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_feedback_user` (`user_id`),
  KEY `idx_feedback_created` (`created_at`),
  CONSTRAINT `fk_feedback_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. One-time links used by the "Suspicious Login Activity" email buttons
--    (only a SHA-256 hash of the token is stored)
CREATE TABLE IF NOT EXISTS `security_alert_tokens` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `action` enum('report','its_me') NOT NULL,
  `token_hash` char(64) NOT NULL,
  `context` varchar(500) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_alert_token_hash` (`token_hash`),
  KEY `idx_alert_user` (`user_id`),
  CONSTRAINT `fk_alert_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'Migration complete. reports, feedback and security_alert_tokens tables are ready.' AS status;
