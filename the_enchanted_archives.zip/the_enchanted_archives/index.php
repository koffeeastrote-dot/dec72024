<?php
/**
 * The Enchanted Archives - Magical Opening Page
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
startSecureSession();

// If already logged in, go to appropriate dashboard
if (isLoggedIn()) {
    if (currentUserRole() === 'admin') {
        redirect('/the_enchanted_archives/admin/dashboard.php');
    }
    redirect('/the_enchanted_archives/student/dashboard.php');
}

// If no admin exists, go to setup
if (!adminExists()) {
    redirect('/the_enchanted_archives/auth/setup_admin.php');
}

// Values kept after a failed login / sign-up (handlers redirect back here)
$oldLoginEmail = $_SESSION['old_login_email'] ?? '';
$oldSignup = $_SESSION['old_signup'] ?? ['full_name' => '', 'email' => ''];
unset($_SESSION['old_login_email'], $_SESSION['old_signup']);

$pageTitle = 'The Enchanted Archives — An Invitation Awaits';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$extraJs = ['/the_enchanted_archives/assets/js/envelope.js'];
$bodyClass = 'opening-page';
require_once __DIR__ . '/includes/header.php';
?>

<div class="particles" aria-hidden="true"></div>

<div class="envelope-container">
    <div class="envelope" id="envelope">
        <div class="envelope-back"></div>

        <!-- top flap: closed it covers the envelope, opened it folds back -->
        <div class="envelope-flap" aria-hidden="true">
            <div class="flap-shape"></div>
            <div class="flap-text">
                <div class="crest-large">✧</div>
                <div class="library-name">THE ENCHANTED ARCHIVES</div>
                <div class="library-tagline">Library of Arcane Knowledge</div>
            </div>
        </div>

        <!-- the letter lives INSIDE the envelope and slides out when opened.
             It now holds the Login / Sign Up forms. -->
        <div class="invitation" id="invitation" role="dialog" aria-labelledby="invite-title">
            <div class="letter-inner" id="letterInner">
                <div class="letter-head">
                    <div class="crest-letter" aria-hidden="true">✧</div>
                    <h2 id="invite-title">Enter the Archives</h2>
                </div>

                <div class="letter-body">
                <div class="auth-tabs letter-tabs" role="tablist">
                    <button type="button" class="active" id="tabLogin" role="tab" aria-selected="true" data-panel="panelLogin">Login</button>
                    <button type="button" id="tabSignup" role="tab" aria-selected="false" data-panel="panelSignup">Sign Up</button>
                </div>

                <!-- LOGIN -->
                <div class="letter-panel active" id="panelLogin" role="tabpanel" aria-labelledby="tabLogin">
                    <form method="post" action="/the_enchanted_archives/auth/login_process.php" autocomplete="on">
                        <?= csrfField() ?>
                        <div class="mb-2">
                            <label class="form-label" for="envEmail">Email Address</label>
                            <input type="email" name="email" id="envEmail" class="form-control" required value="<?= e($oldLoginEmail) ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label" for="envLoginPass">Password</label>
                            <div class="input-group-password">
                                <input type="password" name="password" id="envLoginPass" class="form-control" required>
                                <button type="button" class="password-toggle" data-toggle-password="#envLoginPass" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
                            </div>
                        </div>
                        <div class="mb-2 form-check">
                            <input type="checkbox" class="form-check-input" name="remember" id="envRemember" value="1">
                            <label class="form-check-label" for="envRemember">Remember me</label>
                        </div>
                        <button type="submit" class="btn btn-gold w-100 mb-2">Enter</button>
                        <div class="text-center">
                            <a href="/the_enchanted_archives/auth/forgot_password.php">Forgot your password?</a>
                        </div>
                    </form>
                </div>

                <!-- SIGN UP -->
                <div class="letter-panel" id="panelSignup" role="tabpanel" aria-labelledby="tabSignup">
                    <form method="post" action="/the_enchanted_archives/auth/register_process.php" autocomplete="off">
                        <?= csrfField() ?>
                        <div class="mb-2">
                            <label class="form-label" for="envFullName">Full Name</label>
                            <input type="text" name="full_name" id="envFullName" class="form-control" required maxlength="150" value="<?= e($oldSignup['full_name']) ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label" for="envRegEmail">Email Address</label>
                            <input type="email" name="email" id="envRegEmail" class="form-control" required maxlength="191" value="<?= e($oldSignup['email']) ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label" for="envRegPass">Password</label>
                            <div class="input-group-password">
                                <input type="password" name="password" id="envRegPass" class="form-control" required minlength="8">
                                <button type="button" class="password-toggle" data-toggle-password="#envRegPass" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
                            </div>
                            <small class="letter-note">Min. 8 characters · uppercase · lowercase · number · not a common password.</small>
                            <div id="regStrengthMeter" class="mt-1" style="display:none;">
                                <div style="height:5px;background:#ddd;border-radius:3px;overflow:hidden;">
                                    <div id="regStrengthBar" style="height:100%;width:0%;transition:width .2s,background .2s;"></div>
                                </div>
                                <small id="regStrengthLabel" class="letter-note"></small>
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label" for="envRegConfirm">Confirm Password</label>
                            <div class="input-group-password">
                                <input type="password" name="confirm_password" id="envRegConfirm" class="form-control" required minlength="8">
                                <button type="button" class="password-toggle" data-toggle-password="#envRegConfirm" aria-label="Show or hide password"><i class="bi bi-eye"></i></button>
                            </div>
                        </div>
                        <div class="mb-2 form-check">
                            <input type="checkbox" class="form-check-input" name="remember" id="envRegRemember" value="1">
                            <label class="form-check-label" for="envRegRemember">Remember me</label>
                        </div>
                        <div class="mb-2 form-check">
                            <input type="checkbox" class="form-check-input" name="accept_terms" id="envRegTerms" value="1" required>
                            <label class="form-check-label" for="envRegTerms">I agree to the <a href="/the_enchanted_archives/terms.php" target="_blank" rel="noopener">Terms of Use</a> and the <a href="/the_enchanted_archives/privacy.php" target="_blank" rel="noopener">Privacy Notice</a>.</label>
                        </div>
                        <button type="submit" class="btn btn-gold w-100 mb-1">Create Account</button>
                        <p class="letter-note text-center mb-0">You will receive a verification code by email.</p>
                    </form>
                </div>
                </div><!-- /letter-body -->
            </div>
        </div>

        <!-- front pocket of the envelope -->
        <div class="envelope-front" aria-hidden="true">
            <span class="pocket-left"></span>
            <span class="pocket-right"></span>
            <span class="pocket-bottom"></span>
        </div>

        <div class="wax-seal" id="waxSeal" role="button" tabindex="0" aria-label="Click the seal to open the invitation">
            <span class="seal-text">ENTER</span>
        </div>
    </div>
    <p class="seal-hint">Click the seal to open</p>
</div>

<a href="#" class="skip-link" id="skipAnimation">Skip animation →</a>

<script nonce="<?= e(cspNonce()) ?>">
(function(){
    const input = document.getElementById('envRegPass');
    const meter = document.getElementById('regStrengthMeter');
    const bar = document.getElementById('regStrengthBar');
    const label = document.getElementById('regStrengthLabel');
    if (!input || !meter) return;
    const common = ["password","password1","password123","123456","12345678","123456789","qwerty","abc123","admin","letmein","welcome","monkey","dragon","master","login","passw0rd","changeme","secret","admin123","root","test","guest","111111","000000","qwerty123","iloveyou","sunshine","football","shadow","superman","hunter2","trustno1","enchanted","hogwarts","library1","p@ssw0rd","p@ssword1","welcome1"];
    const labels = ["Very Weak","Weak","Fair","Good","Strong","Excellent"];
    const colors = ["#c0392b","#e67e22","#f1c40f","#27ae60","#1abc9c","#2ecc71"];
    input.addEventListener("input", function(){
        const pw = this.value;
        if (!pw) { meter.style.display = "none"; return; }
        meter.style.display = "block";
        let s = 0;
        if (pw.length >= 8) s++;
        if (pw.length >= 12) s++;
        if (/[a-z]/.test(pw)) s++;
        if (/[A-Z]/.test(pw)) s++;
        if (/[0-9]/.test(pw)) s++;
        if (/[^A-Za-z0-9]/.test(pw)) s++;
        if (common.includes(pw.toLowerCase())) s = 0;
        bar.style.width = (Math.min(s,5) / 5 * 100) + "%";
        bar.style.background = colors[Math.min(s,5)] || colors[0];
        let t = labels[Math.min(s,5)] || labels[0];
        if (common.includes(pw.toLowerCase())) t += " — too common";
        label.textContent = t;
    });
})();
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
