<?php
if (session_status() === PHP_SESSION_NONE) {
    require_once __DIR__ . '/auth.php';
    startSecureSession();
}
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'The Enchanted Archives') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= e(asset('/the_enchanted_archives/assets/css/style.css')) ?>">
    <?php if (!empty($extraCss)): ?>
        <?php foreach ((array)$extraCss as $css): ?>
            <link rel="stylesheet" href="<?= e(asset($css)) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body class="<?= e($bodyClass ?? '') ?>">
<?php if ($flash): ?>
<div class="toast-container position-fixed top-0 end-0 p-3" style="z-index:9999;">
    <div class="toast show align-items-center text-bg-<?= $flash['type'] === 'error' ? 'danger' : ($flash['type'] === 'success' ? 'success' : 'warning') ?> border-0" role="alert">
        <div class="d-flex">
            <div class="toast-body"><?= e($flash['message']) ?></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>
<?php endif; ?>
