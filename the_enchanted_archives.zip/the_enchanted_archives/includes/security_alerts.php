<?php
/**
 * The Enchanted Archives - Security alert links
 *
 * One-time tokens used by the buttons in the "Suspicious Login Activity" email:
 *   - 'its_me'  -> "Yes, it's me"  (leads to a secure password reset)
 *   - 'report'  -> "Report"        (opens the Report a Problem form)
 * Only a SHA-256 hash of each token is stored in the database.
 */

declare(strict_types=1);

require_once __DIR__ . '/functions.php';

/**
 * Base URL for links placed inside emails. Taken from config (APP_BASE_URL) and
 * NOT from the request, so an attacker can not poison the links via the Host header.
 */
function appBaseUrl(): string {
    $base = defined('APP_BASE_URL') ? rtrim((string)APP_BASE_URL, '/') : '';
    return $base !== '' ? $base : 'http://localhost';
}

/**
 * Create a one-time alert token. Older unused tokens of the same action are revoked.
 * Returns the clear token (goes into the email link only).
 */
function createAlertToken(int $userId, string $action, string $context = '', int $hours = 24): string {
    if (!in_array($action, ['report', 'its_me'], true)) {
        throw new InvalidArgumentException('Invalid alert action');
    }
    $pdo = getDB();

    $pdo->prepare('UPDATE security_alert_tokens SET used = 1 WHERE user_id = ? AND action = ? AND used = 0')
        ->execute([$userId, $action]);

    $token = bin2hex(random_bytes(32)); // 64 hex chars
    $hours = max(1, $hours);
    $pdo->prepare(
        'INSERT INTO security_alert_tokens (user_id, action, token_hash, context, expires_at)
         VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ' . $hours . ' HOUR))'
    )->execute([$userId, $action, hash('sha256', $token), substr($context, 0, 500)]);

    return $token;
}

/**
 * Look up a valid (unused, not expired) alert token for the given action.
 * Returns the token row plus the user's details, or null.
 * (u.* on purpose: works even if the optional 2FA/TOTP columns are not migrated yet;
 *  callers must read those with empty()/?? )
 */
function findAlertToken(string $token, string $action): ?array {
    if (!preg_match('/^[a-f0-9]{64}$/i', $token)) {
        return null;
    }
    $stmt = getDB()->prepare(
        'SELECT t.id AS token_id, t.user_id, t.action, t.context, u.*
         FROM security_alert_tokens t
         JOIN users u ON u.id = t.user_id
         WHERE t.token_hash = ? AND t.action = ? AND t.used = 0 AND t.expires_at > NOW()
         LIMIT 1'
    );
    $stmt->execute([hash('sha256', $token), $action]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Mark an alert token as used (single use).
 */
function consumeAlertToken(int $tokenId): void {
    getDB()->prepare('UPDATE security_alert_tokens SET used = 1 WHERE id = ?')->execute([$tokenId]);
}
