<?php
/**
 * The Enchanted Archives - CSRF Protection
 */

declare(strict_types=1);

/**
 * Generate or retrieve CSRF token.
 * Always call startSecureSession() before using this on pages.
 */
function generateCsrfToken(): string {
    if (session_status() === PHP_SESSION_NONE) {
        if (function_exists('startSecureSession')) {
            startSecureSession();
        } else {
            session_start();
        }
    }

    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/**
 * Output a hidden CSRF input field
 */
function csrfField(): string {
    $token = generateCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
}

/**
 * Verify CSRF token from POST
 */
function verifyCsrfToken(?string $token = null): bool {
    if (session_status() === PHP_SESSION_NONE) {
        if (function_exists('startSecureSession')) {
            startSecureSession();
        } else {
            session_start();
        }
    }

    $token = $token ?? ($_POST['csrf_token'] ?? '');

    if ($token === '' || empty($_SESSION['csrf_token'])) {
        return false;
    }

    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Require valid CSRF or die with a friendly message
 */
function requireCsrf(): void {
    if (!verifyCsrfToken()) {
        http_response_code(403);
        // Friendly page instead of plain die — user can go back and retry
        $msg = 'Invalid or expired security token. Please go back, refresh the page, and try again.';
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Security Token</title>';
        echo '<style>body{font-family:system-ui,sans-serif;background:#1a120b;color:#e8d5b7;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}';
        echo '.card{background:#2a1f15;border:1px solid #c9a227;border-radius:8px;padding:28px;max-width:420px;text-align:center;}';
        echo 'a{color:#c9a227;}</style></head><body><div class="card">';
        echo '<h2 style="color:#c9a227;margin-top:0;">Security Check Failed</h2>';
        echo '<p>' . htmlspecialchars($msg) . '</p>';
        $n = function_exists('cspNonce') ? cspNonce() : '';
        echo '<p><a href="#" id="back">← Go back</a></p>';
        echo '<script nonce="' . htmlspecialchars($n, ENT_QUOTES) . '">document.getElementById("back").addEventListener("click",function(e){e.preventDefault();history.back();});</script>';
        echo '</div></body></html>';
        exit;
    }
}

/**
 * For state-changing actions (delete, approve, ...): accept POST only, with a valid CSRF token.
 * A plain link (GET) can no longer trigger the action, so a malicious page/image/link can not
 * make a logged-in admin delete or approve something.
 */
function requirePostWithCsrf(string $backUrl): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        header('Location: ' . $backUrl);
        exit;
    }
    requireCsrf();
}
