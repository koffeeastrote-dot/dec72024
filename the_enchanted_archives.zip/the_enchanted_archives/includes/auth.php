<?php
/**
 * The Enchanted Archives - Authentication & Authorization
 */

declare(strict_types=1);

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/csrf.php';

/**
 * Clear only the login data of the session (keeps guest data such as CSRF token).
 */
function clearLoginSession(): void {
    unset(
        $_SESSION['user_id'],
        $_SESSION['full_name'],
        $_SESSION['email'],
        $_SESSION['role'],
        $_SESSION['login_time'],
        $_SESSION['ua_hash']
    );
}

/**
 * Start secure session (safe for guests and logged-in users)
 */
function startSecureSession(): void {
    // HTTPS redirect (only when FORCE_HTTPS is on in config/security.php)
    if (defined('FORCE_HTTPS') && FORCE_HTTPS && PHP_SAPI !== 'cli'
        && (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off')) {
        $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
        header('Location: https://' . $host . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
        exit;
    }

    sendSecurityHeaders();

    if (session_status() !== PHP_SESSION_ACTIVE) {
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

        ini_set('session.use_strict_mode', '1');   // refuse session IDs the server did not create
        ini_set('session.use_only_cookies', '1');  // never accept the session ID from the URL
        ini_set('session.cookie_httponly', '1');

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    // Time-outs and hijack checks run on EVERY request (also the first call of the request).
    if (!empty($_SESSION['user_id'])) {
        $idle     = defined('SESSION_IDLE_TIMEOUT') ? (int)SESSION_IDLE_TIMEOUT : 1800;
        $absolute = defined('SESSION_ABSOLUTE_TIMEOUT') ? (int)SESSION_ABSOLUTE_TIMEOUT : 28800;
        $now = time();
        $expired = (isset($_SESSION['last_activity']) && ($now - (int)$_SESSION['last_activity']) > $idle)
                || (isset($_SESSION['login_time']) && ($now - (int)$_SESSION['login_time']) > $absolute);
        // A stolen session cookie used from another browser does not match the stored fingerprint
        $uaMismatch = isset($_SESSION['ua_hash'])
                && !hash_equals((string)$_SESSION['ua_hash'], hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? ''));

        if ($expired || $uaMismatch) {
            clearLoginSession();
            session_regenerate_id(true);
            setFlash('warning', $uaMismatch ? 'Your session was ended for security reasons. Please log in again.' : 'You were logged out because of inactivity. Please log in again.');
        } else {
            // Re-check the account in the database (once per request): a deactivated
            // user or a changed role is kicked out immediately, not at the end of the session.
            static $verified = false;
            if (!$verified) {
                $verified = true;
                try {
                    $st = getDB()->prepare('SELECT is_active, role FROM users WHERE id = ? LIMIT 1');
                    $st->execute([(int)$_SESSION['user_id']]);
                    $row = $st->fetch();
                    if (!$row || !(int)$row['is_active'] || $row['role'] !== ($_SESSION['role'] ?? '')) {
                        clearLoginSession();
                        session_regenerate_id(true);
                        setFlash('warning', 'Your session is no longer valid. Please log in again.');
                    }
                } catch (Throwable $e) {
                    error_log('Session re-check failed: ' . $e->getMessage());
                }
            }
        }
    }

    $_SESSION['last_activity'] = time();
}

/**
 * Check if user is logged in
 */
function isLoggedIn(): bool {
    startSecureSession();
    return !empty($_SESSION['user_id']) && !empty($_SESSION['role']);
}

/**
 * Get current user ID
 */
function currentUserId(): ?int {
    return isLoggedIn() ? (int)$_SESSION['user_id'] : null;
}

/**
 * Get current user role
 */
function currentUserRole(): ?string {
    return isLoggedIn() ? (string)$_SESSION['role'] : null;
}

/**
 * Get current user full name
 */
function currentUserName(): ?string {
    return isLoggedIn() ? (string)($_SESSION['full_name'] ?? '') : null;
}

/**
 * Get current user email
 */
function currentUserEmail(): ?string {
    return isLoggedIn() ? (string)($_SESSION['email'] ?? '') : null;
}

/**
 * Require login
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        setFlash('error', 'Please log in to continue.');
        header('Location: /the_enchanted_archives/index.php?open=1');
        exit;
    }
}

/**
 * Require a specific role
 */
function requireRole(string $role): void {
    requireLogin();
    if (currentUserRole() !== $role) {
        setFlash('error', 'You do not have permission to access that page.');
        header('Location: /the_enchanted_archives/index.php');
        exit;
    }
}

/**
 * Require admin
 */
function requireAdmin(): void {
    requireRole('admin');
}

/**
 * Require student
 */
function requireStudent(): void {
    requireRole('student');
}

/**
 * Check if any admin exists (for first-run setup)
 */
function adminExists(): bool {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT COUNT(*) AS cnt FROM users WHERE role = 'admin'");
    return (int)$stmt->fetch()['cnt'] > 0;
}

/**
 * Login user after successful authentication
 */
function loginUser(array $user): void {
    startSecureSession();

    // Regenerate session ID to prevent fixation (keeps existing session data)
    session_regenerate_id(true);

    $_SESSION['user_id']       = (int)$user['id'];
    $_SESSION['full_name']     = $user['full_name'];
    $_SESSION['email']         = $user['email'];
    $_SESSION['role']          = $user['role'];
    $_SESSION['last_activity'] = time();
    $_SESSION['login_time']    = time();
    $_SESSION['ua_hash']       = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
}

/**
 * Logout user (does not recurse into startSecureSession timeout logic)
 */
function logoutUser(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}

/**
 * Record login attempt / log
 */
function recordLoginAttempt(string $email, bool $success, ?int $userId = null, string $status = 'failed'): void {
    $pdo = getDB();
    $ip = getClientIP();
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);

    // login_attempts table
    $stmt = $pdo->prepare('INSERT INTO login_attempts (email, ip_address, success) VALUES (?, ?, ?)');
    $stmt->execute([$email, $ip, $success ? 1 : 0]);

    // login_logs table
    $stmt = $pdo->prepare('INSERT INTO login_logs (user_id, email, ip_address, user_agent, status) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$userId, $email, $ip, $ua, $status]);
}

/**
 * Lockout policy: after MAX_FAILED_ATTEMPTS wrong passwords the account is locked
 * for a random time between LOCKOUT_MIN_MINUTES and LOCKOUT_MAX_MINUTES.
 * (Random so an attacker can not simply wait a fixed time and resume.)
 */
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MIN_MINUTES = 15;
const LOCKOUT_MAX_MINUTES = 30;

/**
 * Progressive delay: the more wrong passwords were tried for this email in the last
 * 15 minutes, the slower the next answer (1s, 2s, 3s, max 4s). Counted from login_attempts,
 * which stores real AND non-existing emails, so the delay is identical for both
 * (an attacker can not tell the difference by timing).
 */
function progressiveLoginDelay(string $email): void {
    try {
        $st = getDB()->prepare('SELECT COUNT(*) FROM login_attempts WHERE email = ? AND success = 0 AND attempted_at > (NOW() - INTERVAL 15 MINUTE)');
        $st->execute([$email]);
        $n = (int)$st->fetchColumn();
        if ($n > 0) {
            sleep(min($n, 4));
        }
    } catch (Throwable $e) {
        // never block login because of this
    }
}

/**
 * Handle failed login (increment attempts, lock + notify owner if needed)
 */
function handleFailedLogin(string $email): void {
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT id, full_name, email, failed_login_attempts FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        recordLoginAttempt($email, false, null, 'failed');
        progressiveLoginDelay($email); // same delay as a real account (no timing leak)
        return;
    }

    $attempts = (int)$user['failed_login_attempts'] + 1;
    $lockoutUntil = null;
    $lockMinutes = 0;
    $justLocked = false;

    if ($attempts >= MAX_FAILED_ATTEMPTS) {
        $lockMinutes = random_int(LOCKOUT_MIN_MINUTES, LOCKOUT_MAX_MINUTES);
        $lockoutUntil = date('Y-m-d H:i:s', time() + $lockMinutes * 60);
        $attempts = 0; // reset counter after lock
        $justLocked = true;
    }

    $stmt = $pdo->prepare('UPDATE users SET failed_login_attempts = ?, lockout_until = ? WHERE id = ?');
    $stmt->execute([$attempts, $lockoutUntil, $user['id']]);

    recordLoginAttempt($email, false, (int)$user['id'], $justLocked ? 'locked' : 'failed');

    if (!$justLocked) {
        progressiveLoginDelay($email);
    }

    // Warn the account owner by email (never let a mail failure break the login flow)
    if ($justLocked) {
        try {
            require_once __DIR__ . '/mailer.php'; // also loads security_alerts.php
            $ip = getClientIP();
            $context = 'Failed attempts: ' . MAX_FAILED_ATTEMPTS . '; IP address: ' . $ip
                     . '; Detected: ' . date('F j, Y, g:i A') . ' (Asia/Manila); Locked for ' . $lockMinutes . ' minutes.';
            $base = appBaseUrl() . '/the_enchanted_archives/auth/security_action.php';
            $itsMeUrl  = $base . '?a=itsme&t='  . createAlertToken((int)$user['id'], 'its_me', $context);
            $reportUrl = $base . '?a=report&t=' . createAlertToken((int)$user['id'], 'report', $context);

            sendSuspiciousLoginEmail(
                (string)$user['email'],
                (string)$user['full_name'],
                MAX_FAILED_ATTEMPTS,
                $lockMinutes,
                $ip,
                $itsMeUrl,
                $reportUrl
            );
        } catch (Throwable $e) {
            error_log('Suspicious-login email failed: ' . $e->getMessage());
        }
    }
}

/**
 * Minutes left on an account lockout (0 if not locked)
 */
function lockoutMinutesRemaining(array $user): int {
    if (empty($user['lockout_until'])) {
        return 0;
    }
    $left = strtotime($user['lockout_until']) - time();
    return $left > 0 ? (int)ceil($left / 60) : 0;
}

/**
 * Clear failed login attempts on success
 */
function clearFailedLogins(int $userId): void {
    $pdo = getDB();
    $stmt = $pdo->prepare('UPDATE users SET failed_login_attempts = 0, lockout_until = NULL WHERE id = ?');
    $stmt->execute([$userId]);
}

/**
 * Alias used by login_process / verify_login_otp
 */
function resetFailedAttempts(int $userId): void {
    clearFailedLogins($userId);
}

/**
 * Check if account is currently locked
 */
function isAccountLocked(array $user): bool {
    if (empty($user['lockout_until'])) {
        return false;
    }
    return strtotime($user['lockout_until']) > time();
}
