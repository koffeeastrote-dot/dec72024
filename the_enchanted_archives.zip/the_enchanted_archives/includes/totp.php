<?php
/**
 * TOTP (RFC 6238) authenticator-app 2FA — no external libraries.
 * Compatible with Google Authenticator, Authy, Microsoft Authenticator, 1Password, etc.
 */

const TOTP_PERIOD = 30;
const TOTP_DIGITS = 6;

function base32Encode(string $bin): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($bin) as $c) {
        $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 5) as $chunk) {
        $out .= $alphabet[bindec(str_pad($chunk, 5, '0', STR_PAD_RIGHT))];
    }
    return $out;
}

function base32Decode(string $b32): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32));
    $bits = '';
    foreach (str_split($b32) as $c) {
        $bits .= str_pad(decbin(strpos($alphabet, $c)), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $out .= chr(bindec($byte));
        }
    }
    return $out;
}

/** New random 160-bit secret, base32 encoded (32 chars). */
function totpGenerateSecret(): string {
    return base32Encode(random_bytes(20));
}

function totpCode(string $secret, int $timeStep): string {
    $key = base32Decode($secret);
    $counter = pack('N*', 0) . pack('N*', $timeStep);
    $hash = hash_hmac('sha1', $counter, $key, true);
    $offset = ord($hash[19]) & 0x0F;
    $value = ((ord($hash[$offset]) & 0x7F) << 24)
           | ((ord($hash[$offset + 1]) & 0xFF) << 16)
           | ((ord($hash[$offset + 2]) & 0xFF) << 8)
           |  (ord($hash[$offset + 3]) & 0xFF);
    return str_pad((string)($value % (10 ** TOTP_DIGITS)), TOTP_DIGITS, '0', STR_PAD_LEFT);
}

/**
 * Verify a code, allowing ±1 step of clock drift.
 * Returns the matched time-step (int) on success, or null on failure.
 * $lastStep rejects replays: a step <= $lastStep is never accepted again.
 */
function totpVerify(string $secret, string $code, ?int $lastStep = null, int $window = 1): ?int {
    $code = preg_replace('/\D/', '', $code);
    if (strlen($code) !== TOTP_DIGITS) {
        return null;
    }
    $now = (int)floor(time() / TOTP_PERIOD);
    for ($i = -$window; $i <= $window; $i++) {
        $step = $now + $i;
        if ($lastStep !== null && $step <= $lastStep) {
            continue;
        }
        if (hash_equals(totpCode($secret, $step), $code)) {
            return $step;
        }
    }
    return null;
}

function totpProvisioningUri(string $secret, string $email, string $issuer = 'The Enchanted Archives'): string {
    return 'otpauth://totp/' . rawurlencode($issuer . ':' . $email)
        . '?secret=' . $secret
        . '&issuer=' . rawurlencode($issuer)
        . '&algorithm=SHA1&digits=' . TOTP_DIGITS . '&period=' . TOTP_PERIOD;
}
