<?php
/**
 * The Enchanted Archives - Core Helper Functions
 */

declare(strict_types=1);

// Keep PHP timezone consistent (important for token expiry)
date_default_timezone_set('Asia/Manila');

require_once __DIR__ . '/../config/database.php';

/**
 * Securely escape output for HTML
 */
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}


/**
 * Asset URL with a cache-busting ?v=<file modified time>, so the browser
 * never reuses an old cached CSS/JS file after you edit it.
 */
function asset(string $url): string {
    $prefix = '/the_enchanted_archives/';
    if (strpos($url, $prefix) === 0) {
        $file = __DIR__ . '/../' . substr($url, strlen($prefix));
        if (is_file($file)) {
            return $url . '?v=' . filemtime($file);
        }
    }
    return $url;
}

/**
 * Redirect helper
 */
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

/**
 * Get client IP address
 */
function getClientIP(): string {
    // SECURITY: REMOTE_ADDR is the only value the client can not fake.
    // X-Forwarded-For / Client-IP are plain headers anyone can set, so they are
    // trusted ONLY when the request really comes from a proxy listed in
    // TRUSTED_PROXIES (config/security.php). Otherwise a fake header would let an
    // attacker bypass the IP rate limit and forge the IP shown in the login logs.
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    $ip = filter_var($remote, FILTER_VALIDATE_IP) ? $remote : '0.0.0.0';

    if (defined('TRUSTED_PROXIES') && in_array($ip, array_filter(array_map('trim', explode(',', (string)TRUSTED_PROXIES))), true)
        && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $forwarded = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($forwarded, FILTER_VALIDATE_IP)) {
            return $forwarded;
        }
    }
    return $ip;
}

/**
 * CSP nonce for this request (lets our own inline <script> run, blocks injected ones).
 */
function cspNonce(): string {
    static $nonce = null;
    if ($nonce === null) {
        $nonce = base64_encode(random_bytes(16));
    }
    return $nonce;
}

/**
 * Send security headers (CSP, Referrer-Policy, HSTS on HTTPS, etc.). Called once per request.
 */
function sendSecurityHeaders(): void {
    static $sent = false;
    if ($sent || headers_sent()) {
        return;
    }
    $sent = true;
    $n = cspNonce();
    header("Content-Security-Policy: default-src 'self'; "
        . "script-src 'self' 'nonce-{$n}' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
        . "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
        . "font-src 'self' https://fonts.gstatic.com https://cdn.jsdelivr.net; "
        . "img-src 'self' data:; connect-src 'self'; object-src 'none'; "
        . "base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/**
 * Escape LIKE wildcards so a search for "%" or "_" is treated as plain text.
 */
function escapeLike(string $value): string {
    return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value);
}

/**
 * Audit log for sensitive actions (password change, deactivate, delete, ...).
 * Never breaks the page if the table is missing.
 */
function auditLog(string $action, string $detail = '', ?int $userId = null): void {
    try {
        if ($userId === null && session_status() === PHP_SESSION_ACTIVE && !empty($_SESSION['user_id'])) {
            $userId = (int)$_SESSION['user_id'];
        }
        getDB()->prepare('INSERT INTO audit_logs (user_id, action, detail, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)')
            ->execute([$userId, substr($action, 0, 60), substr($detail, 0, 255), getClientIP(), substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)]);
    } catch (Throwable $e) {
        error_log('auditLog failed: ' . $e->getMessage());
    }
}

/**
 * Generate a cryptographically secure random token
 */
function generateToken(int $length = 32): string {
    return bin2hex(random_bytes($length));
}

/**
 * Generate a 6-digit OTP
 */
function generateOTP(): string {
    return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
}

/**
 * Hash a value using password_hash (for OTP / tokens)
 */
function hashValue(string $value): string {
    return password_hash($value, PASSWORD_BCRYPT);
}

/**
 * Verify a hashed value
 */
function verifyHash(string $value, string $hash): bool {
    return password_verify($value, $hash);
}

/**
 * Flash message system
 */
function setFlash(string $type, string $message): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Validate email
 */
function isValidEmail(string $email): bool {
    return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Common / frequently breached passwords (subset for offline check).
 * In production you can expand this list or query HaveIBeenPwned range API.
 */
function getCommonPasswords(): array {
    return [
        'password', 'password1', 'password123', '123456', '12345678', '123456789',
        'qwerty', 'abc123', 'admin', 'letmein', 'welcome', 'monkey', 'dragon',
        'master', 'login', 'princess', 'solo', 'qwerty123', 'iloveyou', 'sunshine',
        'football', 'baseball', 'shadow', 'superman', 'michael', 'jennifer',
        'hunter2', 'trustno1', 'passw0rd', 'changeme', 'secret', 'default',
        'admin123', 'root', 'toor', 'pass', 'test', 'guest', 'user', '1234',
        '12345', '1234567', '111111', '000000', '654321', 'qwertyuiop',
        'asdfgh', 'zxcvbn', '1q2w3e4r', '1qaz2wsx', 'qazwsx', 'password!',
        'P@ssw0rd', 'P@ssword1', 'Welcome1', 'Admin123!', 'Summer2024',
        'Winter2024', 'Spring2025', 'Enchanted', 'Hogwarts', 'Library1'
    ];
}

/**
 * Password strength check:
 * - min 8 characters
 * - at least one uppercase, one lowercase, one digit
 * - not in common/breached list (case-insensitive)
 */
function isStrongPassword(string $password): bool {
    if (strlen($password) < 8 || strlen($password) > 128) {
        return false;
    }
    // Passphrases (15+ characters, e.g. "purple coffee runs on tuesdays") are allowed
    // without the upper/lower/number rule: length is what makes them strong.
    if (strlen($password) < 15
        && (!preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password))) {
        return false;
    }
    $lower = strtolower($password);
    foreach (getCommonPasswords() as $common) {
        if ($lower === strtolower($common)) {
            return false;
        }
    }
    // Online breach check (fail-open if the API is unreachable)
    if (isPasswordPwned($password)) {
        return false;
    }
    return true;
}

/**
 * HaveIBeenPwned "Pwned Passwords" range API (k-anonymity).
 * Only the first 5 hex chars of the SHA-1 hash leave the server; the password never does.
 * Fails open (returns false) on network errors so registration still works offline.
 */
function isPasswordPwned(string $password, int $threshold = 1): bool {
    $sha1 = strtoupper(sha1($password));
    $prefix = substr($sha1, 0, 5);
    $suffix = substr($sha1, 5);
    $body = false;
    try {
        $url = 'https://api.pwnedpasswords.com/range/' . $prefix;
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 3,
                CURLOPT_CONNECTTIMEOUT => 2,
                CURLOPT_HTTPHEADER => ['Add-Padding: true', 'User-Agent: EnchantedArchives-PasswordCheck'],
            ]);
            $body = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($code !== 200) {
                $body = false;
            }
        } else {
            $ctx = stream_context_create(['http' => ['timeout' => 3, 'header' => "Add-Padding: true\r\nUser-Agent: EnchantedArchives-PasswordCheck\r\n"]]);
            $body = @file_get_contents($url, false, $ctx);
        }
    } catch (Throwable $e) {
        return false;
    }
    if (!is_string($body) || $body === '') {
        return false;
    }
    foreach (preg_split('/\r\n|\n/', $body) as $line) {
        $parts = explode(':', trim($line));
        if (count($parts) === 2 && strcasecmp($parts[0], $suffix) === 0) {
            return (int)$parts[1] >= $threshold;
        }
    }
    return false;
}

/**
 * Human-readable password strength feedback
 */
function passwordStrengthFeedback(string $password): array {
    $score = 0;
    $feedback = [];

    if (strlen($password) >= 8) $score++; else $feedback[] = 'At least 8 characters';
    if (strlen($password) >= 12) $score++;
    if (preg_match('/[a-z]/', $password)) $score++; else $feedback[] = 'Add a lowercase letter';
    if (preg_match('/[A-Z]/', $password)) $score++; else $feedback[] = 'Add an uppercase letter';
    if (preg_match('/[0-9]/', $password)) $score++; else $feedback[] = 'Add a number';
    if (preg_match('/[^A-Za-z0-9]/', $password)) $score++; else $feedback[] = 'Add a special character (recommended)';

    $lower = strtolower($password);
    foreach (getCommonPasswords() as $common) {
        if ($lower === strtolower($common)) {
            $score = 0;
            $feedback[] = 'This password is too common / previously breached';
            break;
        }
    }

    $labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Excellent'];
    $label = $labels[min($score, 5)] ?? 'Very Weak';

    return [
        'score' => $score,
        'label' => $label,
        'feedback' => $feedback,
        'is_strong' => isStrongPassword($password)
    ];
}

/**
 * Generic rate limiter (IP or email based).
 * Returns true if the action is allowed, false if rate-limited.
 * If the rate_limits table does not exist yet, allows the action (fail-open).
 */
function checkRateLimit(string $actionKey, string $identifier, int $maxAttempts = 5, int $windowSeconds = 300, int $blockSeconds = 900): bool {
    try {
        $pdo = getDB();
        $now = time();

        $stmt = $pdo->prepare('SELECT * FROM rate_limits WHERE action_key = ? AND identifier = ? LIMIT 1');
        $stmt->execute([$actionKey, $identifier]);
        $row = $stmt->fetch();

        if ($row) {
            if (!empty($row['blocked_until']) && strtotime($row['blocked_until']) > $now) {
                return false;
            }
            $windowStart = strtotime($row['window_start']);
            if (($now - $windowStart) > $windowSeconds) {
                // Reset window
                $stmt = $pdo->prepare('UPDATE rate_limits SET attempts = 1, window_start = NOW(), blocked_until = NULL WHERE id = ?');
                $stmt->execute([$row['id']]);
                return true;
            }
            $attempts = (int)$row['attempts'] + 1;
            if ($attempts > $maxAttempts) {
                $blockedUntil = date('Y-m-d H:i:s', $now + $blockSeconds);
                $stmt = $pdo->prepare('UPDATE rate_limits SET attempts = ?, blocked_until = ? WHERE id = ?');
                $stmt->execute([$attempts, $blockedUntil, $row['id']]);
                return false;
            }
            $stmt = $pdo->prepare('UPDATE rate_limits SET attempts = ? WHERE id = ?');
            $stmt->execute([$attempts, $row['id']]);
            return true;
        }

        $stmt = $pdo->prepare('INSERT INTO rate_limits (action_key, identifier, attempts, window_start) VALUES (?, ?, 1, NOW())');
        $stmt->execute([$actionKey, $identifier]);
        return true;
    } catch (Throwable $e) {
        // Table missing or other DB issue — do not block the user
        return true;
    }
}

/**
 * Remaining seconds until rate-limit block expires (0 if not blocked)
 */
function rateLimitRemaining(string $actionKey, string $identifier): int {
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT blocked_until FROM rate_limits WHERE action_key = ? AND identifier = ? LIMIT 1');
        $stmt->execute([$actionKey, $identifier]);
        $row = $stmt->fetch();
        if ($row && !empty($row['blocked_until'])) {
            $remaining = strtotime($row['blocked_until']) - time();
            return max(0, $remaining);
        }
    } catch (Throwable $e) {
        // ignore
    }
    return 0;
}

/**
 * Format date for display
 */
function formatDate(?string $datetime, string $format = 'M d, Y H:i'): string {
    if (empty($datetime)) {
        return '—';
    }
    try {
        $dt = new DateTime($datetime);
        return $dt->format($format);
    } catch (Exception $e) {
        return '—';
    }
}

/**
 * Check if a book is available
 */
function isBookAvailable(int $bookId): bool {
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT available_copies FROM books WHERE id = ?');
    $stmt->execute([$bookId]);
    $row = $stmt->fetch();
    return $row && (int)$row['available_copies'] > 0;
}

/**
 * Get category name by ID
 */
function getCategoryName(?int $id): string {
    if (!$id) return 'Uncategorized';
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT name FROM categories WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    return $row ? $row['name'] : 'Uncategorized';
}

/**
 * Count helper
 */
function countRows(string $table, string $where = '1=1', array $params = []): int {
    // $table and $where are developer-written constants (never user input).
    // The table name is whitelisted as an extra guard against future mistakes.
    if (!in_array($table, ['books', 'users', 'borrowings', 'categories', 'reports', 'feedback'], true)) {
        throw new InvalidArgumentException('Invalid table');
    }
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM {$table} WHERE {$where}");
    $stmt->execute($params);
    return (int) $stmt->fetch()['cnt'];
}
