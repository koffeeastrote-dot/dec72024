<?php
/**
 * The Enchanted Archives - Email / OTP Mailer
 * Uses PHPMailer with Gmail SMTP
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/smtp.php';
require_once __DIR__ . '/security_alerts.php';
require_once __DIR__ . '/../vendor/src/Exception.php';
require_once __DIR__ . '/../vendor/src/PHPMailer.php';
require_once __DIR__ . '/../vendor/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Send OTP email
 */
function sendOTPEmail(string $toEmail, string $toName, string $otp, string $purpose = 'registration'): array {
    if (!isSmtpConfigured()) {
        return [
            'success' => false,
            'message' => 'Email delivery is not configured. Please set up Gmail SMTP in config/smtp.php to enable verification.'
        ];
    }
    
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_ENCRYPTION === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';
        
        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        
        $mail->isHTML(true);
        
        if ($purpose === 'password_reset') {
            $mail->Subject = 'Password Reset Code — The Enchanted Archives';
            $heading = 'Password Reset Request';
            $bodyText = 'You requested to reset your password. Use the code below to proceed.';
        } elseif ($purpose === 'login_2fa') {
            $mail->Subject = 'Login Verification Code — The Enchanted Archives';
            $heading = 'Two-Factor Authentication';
            $bodyText = 'Someone is trying to sign in to your account. Use the code below to complete login. If this was not you, change your password immediately.';
        } else {
            $mail->Subject = 'Verify Your Entry — The Enchanted Archives';
            $heading = 'Email Verification';
            $bodyText = 'Welcome, seeker. To complete your registration and gain entry to the archives, please verify your email with the code below.';
        }
        
        $mail->Body = getOTPEmailHTML($toName, $otp, $heading, $bodyText);
        $mail->AltBody = "{$heading}\n\nHello {$toName},\n\n{$bodyText}\n\nYour verification code is: {$otp}\n\nThis code expires in 5 minutes.\n\nIf you did not request this, please ignore this message.\n\n— The Enchanted Archives";
        
        $mail->send();
        
        return ['success' => true, 'message' => 'OTP sent successfully.'];
        
    } catch (Exception $e) {
        error_log('PHPMailer error: ' . $mail->ErrorInfo);
        return [
            'success' => false,
            'message' => 'Failed to send verification email. Please check SMTP configuration or try again later.'
        ];
    }
}

/**
 * Build a ready-to-use PHPMailer (Gmail SMTP) with the sender already set.
 */
function newMailer(): PHPMailer {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USERNAME;
    $mail->Password   = SMTP_PASSWORD;
    $mail->SMTPSecure = SMTP_ENCRYPTION === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;
    $mail->Timeout    = 10; // do not hang the page if Gmail is slow
    $mail->CharSet    = 'UTF-8';
    $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
    $mail->isHTML(true);
    return $mail;
}

/**
 * Security alert: sent when an account gets locked after repeated failed logins.
 * $itsMeUrl / $reportUrl are the one-time links behind the two buttons.
 */
function sendSuspiciousLoginEmail(string $toEmail, string $toName, int $failedAttempts, int $lockMinutes, string $ip, string $itsMeUrl = '', string $reportUrl = ''): array {
    if (!isSmtpConfigured()) {
        return ['success' => false, 'message' => 'Email delivery is not configured.'];
    }

    $mail = null;
    try {
        $mail = newMailer();
        $mail->addAddress($toEmail, $toName);
        $mail->Subject = 'Suspicious Login Activity Detected! — The Enchanted Archives';

        $h = fn(string $v): string => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
        $name     = $h($toName !== '' ? $toName : 'User');
        $account  = $h($toEmail);
        $ipSafe   = $h($ip);
        $detectedPlain = date('F j, Y, g:i A') . ' (Asia/Manila)';
        $detected = $h($detectedPlain);
        $attempts = (int)$failedAttempts;
        $minutes  = (int)$lockMinutes;
        $itsMeHref = $h($itsMeUrl);
        $reportHref = $h($reportUrl);

        $buttons = '';
        if ($itsMeUrl !== '' && $reportUrl !== '') {
            $buttons = <<<HTML
            <table cellpadding="0" cellspacing="0" style="margin:0 auto 8px;">
              <tr>
                <td style="padding:0 8px 8px;"><a href="{$itsMeHref}" style="display:inline-block;background:#2d6a4f;color:#ffffff;text-decoration:none;padding:14px 26px;border-radius:6px;font-weight:bold;font-size:15px;font-family:Georgia,serif;">Yes, it's me</a></td>
                <td style="padding:0 8px 8px;"><a href="{$reportHref}" style="display:inline-block;background:#781F24;color:#ffffff;text-decoration:none;padding:14px 26px;border-radius:6px;font-weight:bold;font-size:15px;font-family:Georgia,serif;">Report</a></td>
              </tr>
            </table>
            <p style="margin:0 0 24px;font-size:12px;color:#492719;text-align:center;">
              <strong>Yes, it's me</strong> &mdash; secure your account by choosing a new password.<br>
              <strong>Report</strong> &mdash; tell the library administrators about this activity.
            </p>
HTML;
        }

        $mail->Body = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Suspicious Login Activity Detected!</title></head>
<body style="margin:0;padding:0;background:#21130F;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#21130F;padding:40px 20px;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#EAD7B0;border:3px solid #B78B4B;border-radius:8px;overflow:hidden;">
        <tr>
          <td style="background:#781F24;padding:24px;text-align:center;">
            <div style="font-size:24px;color:#EAD7B0;letter-spacing:2px;font-weight:bold;">&#9888; Suspicious Login Activity Detected!</div>
          </td>
        </tr>
        <tr>
          <td style="padding:32px 40px;color:#21130F;font-size:15px;line-height:1.6;">
            <p style="margin:0 0 16px;font-size:18px;"><strong>Hello, {$name}!</strong></p>
            <p style="margin:0 0 20px;">We detected multiple unsuccessful login attempts on your account.</p>

            <p style="margin:0 0 8px;color:#492719;"><strong>Security details:</strong></p>
            <ul style="margin:0 0 24px;padding-left:20px;">
              <li><strong>Account:</strong> {$account}</li>
              <li><strong>Failed attempts:</strong> {$attempts}</li>
              <li><strong>Detection:</strong> {$detected}</li>
              <li><strong>Status:</strong> Temporarily Locked</li>
              <li><strong>Lockout duration:</strong> {$minutes} minutes</li>
              <li><strong>IP address:</strong> {$ipSafe}</li>
            </ul>

            <p style="margin:0 0 8px;font-size:17px;color:#781F24;"><strong>Was this you?</strong></p>
            <p style="margin:0 0 20px;">If this wasn't you, we recommend changing your password and reviewing your account security.</p>

            {$buttons}

            <p style="margin:0 0 24px;">Your account has been temporarily protected against further login attempts.</p>

            <p style="margin:0;">Stay safe,<br><strong>The Enchanted Archives Security Team</strong></p>
          </td>
        </tr>
        <tr>
          <td style="background:#492719;padding:16px;text-align:center;font-size:11px;color:#EAD7B0;">
            © The Enchanted Archives — For authorized seekers only
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;

        $links = '';
        if ($itsMeUrl !== '' && $reportUrl !== '') {
            $links = "Yes, it's me (secure your account): {$itsMeUrl}\n"
                   . "Report (tell the administrators): {$reportUrl}\n\n";
        }
        $mail->AltBody = "Suspicious Login Activity Detected!\n\nHello, {$toName}!\n\n"
            . "We detected multiple unsuccessful login attempts on your account.\n\n"
            . "Security details:\n"
            . "* Account: {$toEmail}\n"
            . "* Failed attempts: {$attempts}\n"
            . "* Detection: {$detectedPlain}\n"
            . "* Status: Temporarily Locked\n"
            . "* Lockout duration: {$minutes} minutes\n"
            . "* IP address: {$ip}\n\n"
            . "Was this you?\n"
            . "If this wasn't you, we recommend changing your password and reviewing your account security.\n\n"
            . $links
            . "Your account has been temporarily protected against further login attempts.\n\n"
            . "Stay safe,\nThe Enchanted Archives Security Team";

        $mail->send();
        return ['success' => true, 'message' => 'Alert sent.'];
    } catch (Exception $e) {
        error_log('Security alert mail error: ' . ($mail ? $mail->ErrorInfo : $e->getMessage()));
        return ['success' => false, 'message' => 'Failed to send security alert.'];
    }
}

/**
 * Notify administrators that a new report was submitted.
 * $admins: list of ['email' => ..., 'full_name' => ...]
 * $report: id, reporter, email, category, subject, description, source
 */
function sendNewReportNotificationEmail(array $admins, array $report): array {
    if (!isSmtpConfigured() || empty($admins)) {
        return ['success' => false, 'message' => 'Email delivery is not configured.'];
    }

    $mail = null;
    try {
        $mail = newMailer();
        foreach ($admins as $a) {
            $mail->addBCC((string)$a['email'], (string)$a['full_name']);
        }
        $mail->addAddress(MAIL_FROM_ADDRESS, MAIL_FROM_NAME); // visible "To" so BCC recipients stay private
        $mail->Subject = 'New Report Submitted (#' . (int)$report['id'] . ') — The Enchanted Archives';

        $h = fn(string $v): string => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
        $id       = (int)$report['id'];
        $reporter = $h((string)$report['reporter']);
        $email    = $h((string)$report['email']);
        $category = $h((string)$report['category']);
        $subject  = $h((string)$report['subject']);
        $desc     = nl2br($h((string)$report['description']));
        $via      = ($report['source'] ?? 'app') === 'email_alert' ? 'Security alert email' : 'Report a Problem form';
        $link     = appBaseUrl() . '/the_enchanted_archives/admin/report_view.php?id=' . $id;
        $linkSafe = $h($link);

        $mail->Body = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>New Report Submitted</title></head>
<body style="margin:0;padding:0;background:#21130F;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#21130F;padding:40px 20px;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#EAD7B0;border:3px solid #B78B4B;border-radius:8px;overflow:hidden;">
        <tr>
          <td style="background:#492719;padding:22px;text-align:center;">
            <div style="font-size:22px;color:#D5B77B;letter-spacing:2px;font-weight:bold;">&#10023; New Report Submitted &#10023;</div>
          </td>
        </tr>
        <tr>
          <td style="padding:30px 40px;color:#21130F;font-size:15px;line-height:1.6;">
            <p style="margin:0 0 16px;">A new report is waiting for review.</p>
            <ul style="margin:0 0 20px;padding-left:20px;">
              <li><strong>Report #:</strong> {$id}</li>
              <li><strong>From:</strong> {$reporter} ({$email})</li>
              <li><strong>Type:</strong> {$category}</li>
              <li><strong>Subject:</strong> {$subject}</li>
              <li><strong>Submitted via:</strong> {$via}</li>
              <li><strong>Status:</strong> Pending</li>
            </ul>
            <div style="background:#F6EBD7;border:1px solid #B78B4B;border-radius:6px;padding:14px 16px;margin:0 0 24px;">{$desc}</div>
            <p style="text-align:center;margin:0;">
              <a href="{$linkSafe}" style="display:inline-block;background:#492719;color:#D5B77B;text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:bold;">Open report</a>
            </p>
          </td>
        </tr>
        <tr>
          <td style="background:#492719;padding:14px;text-align:center;font-size:11px;color:#EAD7B0;">
            © The Enchanted Archives — Administrator notification
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;

        $mail->AltBody = "New report submitted (#{$id})\n\n"
            . "From: {$report['reporter']} ({$report['email']})\n"
            . "Type: {$report['category']}\n"
            . "Subject: {$report['subject']}\n"
            . "Submitted via: {$via}\n\n"
            . $report['description'] . "\n\n"
            . "Open the report: {$link}";

        $mail->send();
        return ['success' => true, 'message' => 'Notification sent.'];
    } catch (Exception $e) {
        error_log('Report notification mail error: ' . ($mail ? $mail->ErrorInfo : $e->getMessage()));
        return ['success' => false, 'message' => 'Failed to send notification.'];
    }
}

/**
 * Beautiful HTML email template
 */
function getOTPEmailHTML(string $name, string $otp, string $heading, string $bodyText): string {
    $safeName = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
    $safeOtp  = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');
    
    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{$heading}</title>
</head>
<body style="margin:0;padding:0;background:#21130F;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#21130F;padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background:#EAD7B0;border:3px solid #B78B4B;border-radius:8px;overflow:hidden;">
          <tr>
            <td style="background:#492719;padding:24px;text-align:center;">
              <div style="font-size:28px;color:#D5B77B;letter-spacing:3px;font-weight:bold;">✧ THE ENCHANTED ARCHIVES ✧</div>
              <div style="font-size:12px;color:#EAD7B0;margin-top:6px;letter-spacing:2px;">SECURE LIBRARY OF ARCANE KNOWLEDGE</div>
            </td>
          </tr>
          <tr>
            <td style="padding:36px 40px;color:#21130F;">
              <h1 style="margin:0 0 16px;font-size:22px;color:#492719;border-bottom:1px solid #B78B4B;padding-bottom:12px;">{$heading}</h1>
              <p style="margin:0 0 20px;font-size:16px;line-height:1.6;">Hello, {$safeName},</p>
              <p style="margin:0 0 28px;font-size:15px;line-height:1.6;">{$bodyText}</p>
              
              <div style="text-align:center;margin:32px 0;">
                <div style="display:inline-block;background:#21130F;color:#D5B77B;font-size:36px;letter-spacing:12px;padding:18px 28px;border:2px solid #B78B4B;border-radius:6px;font-weight:bold;">
                  {$safeOtp}
                </div>
              </div>
              
              <p style="margin:24px 0 8px;font-size:14px;color:#492719;text-align:center;">
                <strong>This code expires in 5 minutes.</strong>
              </p>
              <p style="margin:0;font-size:13px;color:#781F24;text-align:center;">
                Do not share this code with anyone. The Keepers of the Archives will never ask for it.
              </p>
            </td>
          </tr>
          <tr>
            <td style="background:#492719;padding:16px;text-align:center;font-size:11px;color:#EAD7B0;">
              © The Enchanted Archives — For authorized seekers only
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;
}

/**
 * Create and store a new OTP for a user/email
 */
function createAndStoreOTP(string $email, string $purpose = 'registration', ?int $userId = null): array {
    $pdo = getDB();
    
    // Invalidate previous unused OTPs for this email + purpose
    $stmt = $pdo->prepare("UPDATE otp_verifications SET used = 1 WHERE email = ? AND purpose = ? AND used = 0");
    $stmt->execute([$email, $purpose]);
    
    $otp = generateOTP();
    $hash = hashValue($otp);
    $expires = date('Y-m-d H:i:s', time() + 300); // 5 minutes
    
    $stmt = $pdo->prepare("INSERT INTO otp_verifications (user_id, email, otp_hash, purpose, expires_at) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $email, $hash, $purpose, $expires]);
    
    return [
        'otp' => $otp, // Only returned to the calling function for immediate sending; never stored in session/logs
        'expires_at' => $expires
    ];
}

/**
 * Verify OTP
 */
function verifyOTP(string $email, string $otp, string $purpose = 'registration'): array {
    $pdo = getDB();
    
    $stmt = $pdo->prepare("SELECT * FROM otp_verifications WHERE email = ? AND purpose = ? AND used = 0 ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$email, $purpose]);
    $record = $stmt->fetch();
    
    if (!$record) {
        return ['success' => false, 'message' => 'No valid verification code found. Please request a new one.'];
    }
    
    if (strtotime($record['expires_at']) < time()) {
        return ['success' => false, 'message' => 'This verification code has expired. Please request a new one.'];
    }
    
    if ((int)$record['attempts'] >= 5) {
        return ['success' => false, 'message' => 'Too many incorrect attempts. Please request a new code.'];
    }
    
    if (!verifyHash($otp, $record['otp_hash'])) {
        $stmt = $pdo->prepare("UPDATE otp_verifications SET attempts = attempts + 1 WHERE id = ?");
        $stmt->execute([$record['id']]);
        return ['success' => false, 'message' => 'Invalid verification code. Please try again.'];
    }
    
    // Mark as used
    $stmt = $pdo->prepare("UPDATE otp_verifications SET used = 1 WHERE id = ?");
    $stmt->execute([$record['id']]);
    
    return ['success' => true, 'message' => 'Verified successfully.', 'user_id' => $record['user_id']];
}

/**
 * Create a password-reset token (stored hashed) and return the clear token for the email link.
 * Token valid for 30 minutes, single-use.
 */
function createPasswordResetToken(string $email): array {
    $pdo = getDB();

    // Invalidate previous unused tokens for this email
    $stmt = $pdo->prepare('UPDATE password_resets SET used = 1 WHERE email = ? AND used = 0');
    $stmt->execute([$email]);

    // 64-char hex token; store SHA-256 hash for direct lookup (not bcrypt)
  $token = generateToken(32);
$hash = hash('sha256', $token);

// Let MySQL calculate the expiry so PHP and MySQL timezones stay in sync
$stmt = $pdo->prepare(
    'INSERT INTO password_resets (email, token_hash, expires_at)
     VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))'
);
$stmt->execute([$email, $hash]);

// Fetch the actual expires_at MySQL stored
$expires = $pdo->query('SELECT expires_at FROM password_resets WHERE id = LAST_INSERT_ID()')->fetchColumn();

    return [
        'token' => $token,
        'expires_at' => $expires
    ];
}

/**
 * Verify a password-reset token. Returns email on success.
 */
function verifyPasswordResetToken(string $token): array {
    $token = trim($token);
    // Tokens are 64-char hex (bin2hex of 32 bytes)
    if (!preg_match('/^[a-f0-9]{64}$/i', $token)) {
        return ['success' => false, 'message' => 'Invalid or expired reset link. Please request a new one.'];
    }

    $pdo = getDB();
    $hash = hash('sha256', $token);

    $stmt = $pdo->prepare(
        'SELECT * FROM password_resets
         WHERE token_hash = ? AND used = 0 AND expires_at > NOW()
         LIMIT 1'
    );
    $stmt->execute([$hash]);
    $row = $stmt->fetch();

    if ($row) {
        return [
            'success' => true,
            'email' => $row['email'],
            'id' => (int)$row['id']
        ];
    }

    return ['success' => false, 'message' => 'Invalid or expired reset link. Please request a new one.'];
}

/**
 * Mark a reset token as used
 */
function consumePasswordResetToken(int $id): void {
    $pdo = getDB();
    $stmt = $pdo->prepare('UPDATE password_resets SET used = 1 WHERE id = ?');
    $stmt->execute([$id]);
}

/**
 * Send password-reset link email
 */
function sendPasswordResetLinkEmail(string $toEmail, string $toName, string $token): array {
    if (!isSmtpConfigured()) {
        return [
            'success' => false,
            'message' => 'Email delivery is not configured. Please set up Gmail SMTP in config/smtp.php.'
        ];
    }

    // Built from config (APP_BASE_URL), NOT from the Host header: a forged Host header
    // could otherwise put the attacker's website inside the victim's reset email.
    $base = appBaseUrl();
    $link = $base . '/the_enchanted_archives/auth/reset_password_link.php?token=' . urlencode($token);

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_ENCRYPTION === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(MAIL_FROM_ADDRESS, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = 'Reset Your Enchanted Archives Password';

        $safeName = htmlspecialchars($toName, ENT_QUOTES, 'UTF-8');
        $safeLink = htmlspecialchars($link, ENT_QUOTES, 'UTF-8');

        $mail->Body = <<<HTML
<!DOCTYPE html>
<html><body style="font-family: Georgia, serif; background:#1a120b; color:#e8d5b7; padding:24px;">
  <div style="max-width:520px;margin:0 auto;background:#2a1f15;border:1px solid #c9a227;border-radius:8px;padding:28px;">
    <h1 style="color:#c9a227;font-family:Cinzel,serif;">Password Reset</h1>
    <p>Dear {$safeName},</p>
    <p>We received a request to reset the password for your Enchanted Archives account.</p>
    <p style="text-align:center;margin:28px 0;">
      <a href="{$safeLink}" style="background:#c9a227;color:#1a120b;padding:12px 24px;text-decoration:none;border-radius:4px;font-weight:bold;">
        Reset Password
      </a>
    </p>
    <p style="font-size:0.9rem;color:#a89070;">This link expires in <strong>30 minutes</strong> and can be used only once.</p>
    <p style="font-size:0.85rem;color:#8a7a60;">If you did not request this, you can safely ignore this email. Your password will remain unchanged.</p>
    <hr style="border-color:#3d2e1f;margin:20px 0;">
    <p style="font-size:0.8rem;color:#6b5344;">The Enchanted Archives · Secure Library System</p>
  </div>
</body></html>
HTML;

        $mail->AltBody = "Password reset for Enchanted Archives\n\nOpen this link within 30 minutes (one-time use):\n{$link}\n\nIf you did not request this, ignore this email.";

        $mail->send();
        return ['success' => true, 'message' => 'Reset link sent.'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Failed to send email. Please try again later.'];
    }
}
