<?php
/**
 * Shared two-factor settings (email OTP + authenticator app) for student and admin profiles.
 *   handleTwoFactorPost(PDO, array &$user, string &$error, string &$success)
 *   renderTwoFactorCard(array $user)
 */
require_once __DIR__ . '/totp.php';

function handleTwoFactorPost(PDO $pdo, array &$user, string &$error, string &$success): void {
    $uid = (int)$user['id'];

    // --- Email OTP toggle ---
    if (isset($_POST['toggle_2fa'])) {
        $enable = !empty($_POST['two_factor_enabled']) ? 1 : 0;
        $current = $_POST['current_password_2fa'] ?? '';
        if (!password_verify($current, $user['password'])) {
            $error = 'Current password is required to change two-factor settings.';
        } else {
            try {
                $pdo->prepare('UPDATE users SET two_factor_enabled = ? WHERE id = ?')->execute([$enable, $uid]);
                $user['two_factor_enabled'] = $enable;
                $success = $enable ? 'Two-factor authentication (email OTP) enabled. You will be asked for a code on next login.' : 'Email two-factor authentication disabled.';
            } catch (Throwable $e) {
                $error = 'Two-factor column is missing. Please run database_migration_security.sql in phpMyAdmin first.';
            }
        }
    }

    // --- Authenticator app: start setup ---
    if (isset($_POST['totp_begin'])) {
        if (!password_verify($_POST['current_password_totp'] ?? '', $user['password'])) {
            $error = 'Current password is required to set up an authenticator app.';
        } else {
            $_SESSION['pending_totp_secret'] = totpGenerateSecret();
        }
    }

    // --- Authenticator app: cancel setup ---
    if (isset($_POST['totp_cancel'])) {
        unset($_SESSION['pending_totp_secret']);
    }

    // --- Authenticator app: confirm first code, then enable ---
    if (isset($_POST['totp_confirm'])) {
        $secret = $_SESSION['pending_totp_secret'] ?? '';
        if ($secret === '') {
            $error = 'Setup expired. Please start again.';
        } else {
            if (!checkRateLimit('totp_setup', (string)$uid, 5, 300, 600)) {
                $error = 'Too many attempts. Please wait a few minutes.';
            } else {
                $step = totpVerify($secret, $_POST['totp_code'] ?? '');
                if ($step === null) {
                    $error = 'That code is not valid. Check your authenticator app and try again.';
                } else {
                    try {
                        $pdo->prepare('UPDATE users SET totp_secret = ?, totp_enabled = 1, totp_last_step = ? WHERE id = ?')
                            ->execute([$secret, $step, $uid]);
                        $user['totp_secret'] = $secret;
                        $user['totp_enabled'] = 1;
                        unset($_SESSION['pending_totp_secret']);
                        $success = 'Authenticator app enabled. You will be asked for its 6-digit code on login.';
                    } catch (Throwable $e) {
                        $error = 'TOTP columns are missing. Please run database_migration_security.sql in phpMyAdmin first.';
                    }
                }
            }
        }
    }

    // --- Authenticator app: disable ---
    if (isset($_POST['totp_disable'])) {
        if (!password_verify($_POST['current_password_totp_off'] ?? '', $user['password'])) {
            $error = 'Current password is required to disable the authenticator app.';
        } else {
            try {
                $pdo->prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, totp_last_step = NULL WHERE id = ?')->execute([$uid]);
                $user['totp_secret'] = null;
                $user['totp_enabled'] = 0;
                $success = 'Authenticator app disabled.';
            } catch (Throwable $e) {
                $error = 'Could not update two-factor settings.';
            }
        }
    }
}

function renderTwoFactorCard(array $user): void {
    $pendingSecret = $_SESSION['pending_totp_secret'] ?? '';
    $totpOn = !empty($user['totp_enabled']);
    ?>
    <div class="parchment-card p-4">
        <h5 class="cinzel mb-3" style="color:var(--mahogany);">Two-Factor Authentication</h5>

        <h6 class="mb-1">Email code</h6>
        <p class="small text-muted">When enabled, you will receive a one-time email code after entering your password.</p>
        <form method="post">
            <?= csrfField() ?>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="two_factor_enabled" id="twoFactor" value="1" <?= !empty($user['two_factor_enabled']) ? 'checked' : '' ?>>
                <label class="form-check-label" for="twoFactor">Enable email OTP on login</label>
            </div>
            <div class="mb-3">
                <label class="form-label">Confirm with current password</label>
                <input type="password" name="current_password_2fa" class="form-control" required autocomplete="current-password">
            </div>
            <button type="submit" name="toggle_2fa" value="1" class="btn btn-gold">Save 2FA Setting</button>
        </form>

        <hr class="my-4">

        <h6 class="mb-1">Authenticator app (TOTP) <?= $totpOn ? '<span class="badge bg-success ms-1">On</span>' : '' ?></h6>
        <p class="small text-muted">Use Google Authenticator, Authy, Microsoft Authenticator or 1Password. If enabled, it replaces the email code at login.</p>

        <?php if ($totpOn): ?>
            <form method="post">
                <?= csrfField() ?>
                <div class="mb-3">
                    <label class="form-label">Confirm with current password to disable</label>
                    <input type="password" name="current_password_totp_off" class="form-control" required autocomplete="current-password">
                </div>
                <button type="submit" name="totp_disable" value="1" class="btn btn-outline-danger">Disable authenticator app</button>
            </form>
        <?php elseif ($pendingSecret !== ''): ?>
            <p class="small mb-2">1. Scan this QR code in your authenticator app (or type the key manually).</p>
            <div id="totpQr" class="mb-2" style="background:#fff;display:inline-block;padding:8px;"></div>
            <p class="small mb-3">Manual key: <code style="user-select:all;"><?= e(trim(chunk_split($pendingSecret, 4, ' '))) ?></code></p>
            <p class="small mb-2">2. Enter the 6-digit code shown in the app.</p>
            <form method="post" class="d-flex gap-2 flex-wrap">
                <?= csrfField() ?>
                <input type="text" name="totp_code" class="form-control" style="max-width:10rem;" inputmode="numeric" pattern="[0-9 ]*" maxlength="7" autocomplete="one-time-code" required placeholder="123456">
                <button type="submit" name="totp_confirm" value="1" class="btn btn-gold">Verify &amp; Enable</button>
                <button type="submit" name="totp_cancel" value="1" class="btn btn-outline-secondary" formnovalidate>Cancel</button>
            </form>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
            <script nonce="<?= e(cspNonce()) ?>">
            (function(){
                if (typeof QRCode === 'undefined') return; // manual key still works
                new QRCode(document.getElementById('totpQr'), {
                    text: <?= json_encode(totpProvisioningUri($pendingSecret, (string)$user['email'])) ?>,
                    width: 176, height: 176, correctLevel: QRCode.CorrectLevel.M
                });
            })();
            </script>
        <?php else: ?>
            <form method="post">
                <?= csrfField() ?>
                <div class="mb-3">
                    <label class="form-label">Confirm with current password</label>
                    <input type="password" name="current_password_totp" class="form-control" required autocomplete="current-password">
                </div>
                <button type="submit" name="totp_begin" value="1" class="btn btn-gold">Set up authenticator app</button>
            </form>
        <?php endif; ?>
    </div>
    <?php
}
