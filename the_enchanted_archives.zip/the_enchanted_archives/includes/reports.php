<?php
/**
 * The Enchanted Archives - Reports & Feedback helpers
 */

declare(strict_types=1);

require_once __DIR__ . '/functions.php';

const REPORT_CATEGORIES = [
    'suspicious_activity' => 'Suspicious Activity',
    'unauthorized_access' => 'Unauthorized Access',
    'error'               => 'Error / Bug',
    'technical_issue'     => 'Technical Issue',
];

const REPORT_STATUSES = [
    'pending'      => 'Pending',
    'under_review' => 'Under Review',
    'resolved'     => 'Resolved',
    'rejected'     => 'Rejected',
];

const FEEDBACK_CATEGORIES = [
    'suggestion' => 'Suggestion',
    'comment'    => 'Comment',
];

/**
 * Validate report input. Returns an error message, or '' when valid.
 */
function validateReportInput(string $category, string $subject, string $description): string {
    if (!isset(REPORT_CATEGORIES[$category])) {
        return 'Please choose a valid report type.';
    }
    $sl = mb_strlen($subject);
    if ($sl < 3 || $sl > 150) {
        return 'Subject must be between 3 and 150 characters.';
    }
    $dl = mb_strlen($description);
    if ($dl < 10 || $dl > 2000) {
        return 'Description must be between 10 and 2000 characters.';
    }
    return '';
}

/**
 * Store a new report and email the admins. Returns the report id.
 */
function createReport(?int $userId, string $email, string $category, string $subject, string $description, string $source = 'app'): int {
    $pdo = getDB();
    $pdo->prepare(
        'INSERT INTO reports (user_id, reporter_email, category, subject, description, source, ip_address)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    )->execute([$userId, $email, $category, $subject, $description, $source === 'email_alert' ? 'email_alert' : 'app', getClientIP()]);
    $id = (int)$pdo->lastInsertId();

    // Gmail notification to the admins (never breaks the submission if mail fails)
    try {
        require_once __DIR__ . '/mailer.php';
        $admins = $pdo->query("SELECT email, full_name FROM users WHERE role = 'admin' AND is_active = 1")->fetchAll();
        $nameStmt = $pdo->prepare('SELECT full_name FROM users WHERE id = ?');
        $reporterName = $email;
        if ($userId) {
            $nameStmt->execute([$userId]);
            $reporterName = (string)($nameStmt->fetchColumn() ?: $email);
        }
        if ($admins) {
            sendNewReportNotificationEmail($admins, [
                'id'          => $id,
                'reporter'    => $reporterName,
                'email'       => $email,
                'category'    => REPORT_CATEGORIES[$category] ?? $category,
                'subject'     => $subject,
                'description' => $description,
                'source'      => $source,
            ]);
        }
    } catch (Throwable $e) {
        error_log('Report notification failed: ' . $e->getMessage());
    }

    return $id;
}
