<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('/the_enchanted_archives/assets/js/main.js')) ?>"></script>
<?php if (!empty($extraJs)): ?>
    <?php foreach ((array)$extraJs as $js): ?>
        <script src="<?= e(asset($js)) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
