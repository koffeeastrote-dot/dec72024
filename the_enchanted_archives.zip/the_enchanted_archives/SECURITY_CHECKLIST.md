# Security Checklist — The Enchanted Archives (na-update)

Legend: ✅ Meron na at maayos · 🟡 Meron pero may natitirang limitasyon · ❌ Wala pa

> Na-update ito pagkatapos ng hardening round (Nobyembre 2026). Ang mga may **(BAGO)** ay binago o idinagdag sa round na ito.
> Para gumana ang audit log at ang Terms consent timestamp, i-run muna ang `database_migration_hardening.sql` sa phpMyAdmin.

## 1. Authentication at Password Security
| Measure | Status | Detalye sa code |
|---|---|---|
| Password hashing + salting | ✅ | `password_hash(BCRYPT)`, awtomatiko ang unique salt bawat user. |
| Strong password policy | ✅ | Min 8, uppercase/lowercase/number, may blocklist, may HaveIBeenPwned check. |
| Passphrase / mas mahabang password | ✅ **(BAGO)** | Ang 15+ characters na passphrase (hal. `purple coffee runs on tuesdays`) ay tinatanggap kahit walang uppercase/number. May max na 128 para hindi ma-abuso ang bcrypt. |
| MFA: TOTP (authenticator app) | ✅ | Meron, may proteksyon laban sa reuse ng code. |
| MFA: Email OTP | ✅ | Meron. |
| MFA: SMS OTP | ❌ | Wala (mas mahina rin ito kaya okay lang). |
| Passkeys / WebAuthn | ❌ | Wala. |

Tandaan: optional pa rin ang MFA, kahit sa admin. Walang recovery codes kung mawala ang phone.

## 2. Proteksyon sa Brute-Force at Credential Attacks
| Measure | Status | Detalye |
|---|---|---|
| Rate limiting | ✅ **(BAGO)** | 15 login bawat 5 minuto bawat IP. **Naayos ang butas**: hindi na pinagkakatiwalaan ang `X-Forwarded-For` / `Client-IP` (pwedeng pekein). `REMOTE_ADDR` na lang ang gamit, maliban kung nasa `TRUSTED_PROXIES` ang proxy. Sinubukan: 25 na login na may iba't ibang pekeng header, na-block pa rin sa ika-16. |
| Account lockout | ✅ | 5 maling subok, lock ng 15–30 minuto, may email alert sa may-ari. |
| CAPTCHA / bot protection | ❌ | Wala. |
| Credential stuffing protection | 🟡 | Tinitingnan ang breached password sa sign-up, reset at palit ng password. Hindi pa sa mismong login. |
| Progressive delays | ✅ **(BAGO)** | Bawat maling password, mas mabagal ang susunod na sagot (1s, 2s, 3s, max 4s). Pareho ang delay para sa totoo at hindi totoong email, kaya hindi ito nagagamit para manghula kung may account. |

## 3. Secure Transmission at Session
| Measure | Status | Detalye |
|---|---|---|
| Force HTTPS / TLS | 🟡 **(BAGO)** | Handa na ang code: `FORCE_HTTPS` sa `config/security.php` at ang redirect lines sa `.htaccess`. **Naka-off** dahil walang SSL sa `http://localhost`. I-on kapag may SSL certificate na ang hosting. |
| HSTS | 🟡 **(BAGO)** | Ipinapadala na kapag HTTPS ang koneksyon. |
| Secure cookie | 🟡 | Awtomatikong naka-on kapag HTTPS ang nakita ng server. |
| HttpOnly cookie | ✅ | Meron. |
| SameSite cookie | ✅ | Lax. |
| Regenerate session ID pagkatapos mag-login | ✅ | Meron. |
| Idle timeout | ✅ **(BAGO)** | Naayos. Ang dating check ay hindi tumatakbo sa unang request, kaya hindi gumagana. Ngayon, sa bawat request. 30 minuto idle at 8 oras na absolute limit. Sinubukan: session na 2 oras idle ay na-logout na. |
| Logout na buong binubura ang session | ✅ | Meron. |
| Proteksyon sa session fixation | ✅ | Regenerate ID + `session.use_strict_mode` + cookies-only **(BAGO)**. |
| Proteksyon sa session hijacking | 🟡 **(BAGO)** | May fingerprint ng browser (ibang browser = logout), at sa bawat request ay nire-revalidate sa database (ang na-deactivate o nabago ang role ay agad na-logout). Wala pa ring HTTPS sa localhost. |

## 4. Sign-up
| Measure | Status | Detalye |
|---|---|---|
| Email verification | ✅ | 6-digit OTP, 5-minutong expiry, limitado ang subok. |
| Iwas email enumeration | ✅ **(BAGO)** | Pareho na ang sagot sa sign-up (existing man o hindi ang email), sa login (totoo/hindi totoo, naka-lock, hindi pa verified, na-deactivate), at sa forgot password (OTP at link). Pareho rin ang oras ng sagot. |
| Input validation / sanitization | ✅ | Prepared statements at escaping. Tingnan ang Seksyon 7 para sa SQL injection. |
| Terms + Privacy consent | ✅ **(BAGO)** | May checkbox sa sign-up (required, sinusuri rin sa server), may `terms.php` at `privacy.php`, at nase-save ang oras ng pag-accept. |

Tandaan: ang "Remember me" checkbox ay wala pa ring ginagawa. Alisin ito o i-implement nang tama bago i-demo.

## 5. Dashboard / Pagkatapos Mag-login
| Measure | Status | Detalye |
|---|---|---|
| Authorization / access control | ✅ | May role guard ang bawat page. Walang IDOR na nakita. |
| CSRF protection | ✅ **(BAGO)** | Ang delete ng libro, approve, reject at return ay POST na may CSRF token na. Ang `GET` ay walang epekto. |
| CSP at security headers | ✅ **(BAGO)** | CSP (may nonce para sa inline scripts), Referrer-Policy, Permissions-Policy, nosniff, X-Frame-Options, HSTS (sa HTTPS). |
| Activity / audit logs | ✅ **(BAGO)** | May log na ng pagpalit ng password, reset, pag-deactivate ng estudyante, add/edit/delete ng libro, approve/reject/return, at backup download. May admin page: **Audit Log**. |
| Re-authentication sa sensitive actions | ✅ | Hinihingi ang kasalukuyang password sa pagpalit ng password at sa pag-set ng 2FA. **(BAGO)** Hindi na mababago ang email ng admin sa profile page (dati, nababago ito nang walang password). |

## 6. Iba pang Best Practices
| Measure | Status | Detalye |
|---|---|---|
| Huwag mag-email ng password | ✅ | OTP at link lang. |
| Secure reset flow | ✅ **(BAGO)** | **Dalawang bug ang naayos.** (1) Sa OTP reset, pwedeng mag-verify ang attacker ng OTP ng sarili niyang account, tapos mag-request ng reset para sa biktima at mapalitan ang password ng biktima. Kinumpirma ko ito sa original na code, at hindi na nangyayari ngayon. (2) Ang reset link ay hindi na galing sa `HTTP_HOST` (pwedeng pekein), kundi sa `APP_BASE_URL`. May limit din sa OTP guesses. |
| Monitor ng kakaibang login | 🟡 | Email alert kapag na-lock. Walang detection ng bagong device o "impossible travel". |
| Regular security testing | ✅ | `SECURITY_TESTING.md`, na may dagdag na SQL injection steps. |
| Secrets sa config | ✅ **(BAGO)** | Wala nang Gmail App Password sa `config/smtp.php`. Nasa `config/smtp.local.php` na ito (ginawa mo mula sa `.example`). |
| Hindi mabubuksan ang sensitive files | ✅ **(BAGO)** | Naka-block sa web ang `.sql`, `.md`, `config/`, `includes/`, `vendor/`. Inalis ang `test_db.php`. |
| Error messages | ✅ **(BAGO)** | Hindi na ipinapakita ang DB host/user/error sa screen. Naka-log na lang (`APP_DEBUG=false`). |

## 7. SQL Injection (para sa teacher mo)

**Resulta ng audit:** lahat ng ~100 SQL query sa project ay gumagamit ng PDO prepared statements, at naka-`ATTR_EMULATE_PREPARES = false` (totoong server-side prepare). Walang user input na idinurugtong sa SQL. Ang mga dynamic na bahagi (status filters, ORDER BY) ay galing sa whitelist o sa code mismo.

**Sinubukan ko** (180 requests na may payloads gaya ng `' OR '1'='1`, `' OR 1=1-- -`, `UNION SELECT`, `'; DROP TABLE users;--`, `1 OR 1=1`, `SLEEP(3)`) sa: login email at password, sign-up, forgot password, search ng libro at estudyante, category filter, status filters, at `id` parameters ng book details, edit book, borrow at report. **Resulta: walang SQL error na lumabas, walang bypass ng login, walang naantalang response, at buo ang `users` table.**

**Mga dagdag na pagsasara (defense in depth):**
- Ang `%` at `_` sa search ay hindi na wildcard (`escapeLike()`), kaya hindi na mahahatak ang lahat ng record gamit ang `%`.
- Ang `countRows()` ay may whitelist na ng table names.
- Hindi na lumalabas ang SQL/DB error sa screen, kaya walang impormasyon para sa error-based injection.
- Ang backup ay gumagamit ng table names mula sa `SHOW TABLES` (hindi galing sa user), naka-backtick.

**Ano ang aasahan mo sa teacher:**
- Kapag gumamit siya ng tool tulad ng sqlmap sa login, **ma-block siya ng rate limit** pagkatapos ng 15 requests (message na "Too many login attempts"). Normal ito, hindi bug. Ipaliwanag mo na ito ay proteksyon.
- Ang pag-test ng `' OR '1'='1` sa login ay magpapakita ng "Invalid email or password". Tama ito.
- Kung hihilingin niyang patunayan, ipakita ang `includes/auth.php` at `auth/login_process.php` (prepared statement: `WHERE email = ?`).

## 8. Mga pwede pang i-implement (ayon sa priority)

**Mataas ang halaga**
1. **Totoong HTTPS.** Kumuha ng SSL (hal. Let's Encrypt sa hosting), tapos `FORCE_HTTPS = true` at tanggalin ang `#` sa rewrite lines ng `.htaccess`.
2. **Hiwalay na MySQL user** na hindi `root` at may password, na may `SELECT, INSERT, UPDATE, DELETE` lang sa `enchanted_archives_db`. Kapag na-SQL inject man, hindi niya mabubura o mababago ang istruktura ng database.
   ```sql
   CREATE USER 'archives_app'@'localhost' IDENTIFIED BY 'PALITAN-NG-MALAKAS-NA-PASSWORD';
   GRANT SELECT, INSERT, UPDATE, DELETE ON enchanted_archives_db.* TO 'archives_app'@'localhost';
   FLUSH PRIVILEGES;
   ```
   Tapos palitan ang `DB_USER` at `DB_PASS` sa `config/database.php`. Ang backup feature ay nangangailangan ng `SELECT` at `SHOW VIEW`, na sakop nito.
3. **Mandatory MFA para sa admin** at **recovery codes** (10 one-time codes na hinihingi kapag nawala ang phone).
4. **CAPTCHA** (Cloudflare Turnstile o reCAPTCHA) sa login, sign-up at forgot password.
5. **"Remember me":** alisin ang checkbox o i-implement nang tama (random token na naka-hash sa database, hindi ang user ID sa cookie).

**Katamtaman**
6. Breach check (HaveIBeenPwned) din sa mismong login, kapag tama ang password.
7. Email alert para sa **bagong device** o bagong IP na nag-login.
8. I-**encrypt ang TOTP secret** sa database (ngayon ay hindi naka-encrypt, ayon sa code), gamit ang key na nasa labas ng database.
9. **Logout via POST**, at i-invalidate ang lahat ng ibang session kapag nagpalit ng password (hal. `password_changed_at` na kinukumpara sa session).
10. **Passkeys / WebAuthn** para sa passwordless login.
11. Backup: i-encrypt ang dump, itago sa labas ng web folder, at i-schedule.
12. Linisin ang lumang records (login logs, rate_limits, expired OTP at reset tokens) gamit ang scheduled job.

**Pulido**
13. I-self-host ang Bootstrap/fonts o gumamit ng Subresource Integrity, para mas mahigpit ang CSP. Alisin ang `'unsafe-inline'` sa styles.
14. Sa `php.ini` (production): `display_errors=Off`, `session.cookie_secure=1`, `expose_php=Off`.
15. Mag-scan gamit ang OWASP ZAP sa sarili mong site, at i-update ang PHPMailer sa `vendor/` paminsan-minsan.
16. Page para sa user na burahin ang sarili niyang account (karapatan sa ilalim ng Data Privacy Act).

## Buod
- ✅ Nandiyan na at maayos: password hashing, policy at passphrase, TOTP at email OTP, lockout, progressive delay, rate limit na hindi mabypass, session security (idle, hijack, fixation), email verification, proteksyon sa SQLi at XSS, access control, CSRF sa lahat ng admin action, CSP at headers, audit log, iwas email enumeration, Terms/Privacy, at ang reset flow.
- 🟡 Natitirang limitasyon: HTTPS (handa ang code, kailangan ng SSL), monitor ng kakaibang login, breach check sa login.
- ❌ Wala pa: CAPTCHA, passkeys, recovery codes, mandatory MFA sa admin, hiwalay na DB user.
