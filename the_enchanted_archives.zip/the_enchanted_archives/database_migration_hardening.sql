-- ============================================================
-- Migration: hardening (audit log + Terms/Privacy consent)
-- Run ONCE in phpMyAdmin (SQL tab) on enchanted_archives_db.
-- Safe to re-run.
-- ============================================================
USE `enchanted_archives_db`;

-- 1. Audit log of sensitive actions (password change, delete, deactivate, ...)
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `action` varchar(60) NOT NULL,
  `detail` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. When the user accepted the Terms of Use / Privacy Notice
SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'enchanted_archives_db' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'terms_accepted_at');
SET @sql = IF(@c = 0,
  'ALTER TABLE `users` ADD COLUMN `terms_accepted_at` datetime DEFAULT NULL',
  'SELECT ''terms_accepted_at already exists'' AS info');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SELECT 'Hardening migration complete.' AS status;
