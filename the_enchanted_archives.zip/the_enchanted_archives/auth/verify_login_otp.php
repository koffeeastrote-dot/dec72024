<?php
/**
 * Login 2FA — Email OTP verification
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/totp.php';
startSecureSession();

if (isLoggedIn()) {
    if (currentUserRole() === 'admin') {
        redirect('/the_enchanted_archives/admin/dashboard.php');
    }
    redirect('/the_enchanted_archives/student/dashboard.php');
}

$userId = $_SESSION['pending_2fa_user_id'] ?? null;
$email  = $_SESSION['pending_2fa_email'] ?? '';

if (!$userId || $email === '') {
    setFlash('error', 'No pending two-factor verification.');
    redirect('/the_enchanted_archives/index.php?open=1');
}

$error = '';
$message = '';
$purpose = 'login_2fa';
$method = $_SESSION['pending_2fa_method'] ?? 'email'; // email | totp

// Resend
if ($method === 'email' && isset($_POST['resend'])) {
    requireCsrf();
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT created_at FROM otp_verifications WHERE email = ? AND purpose = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$email, $purpose]);
    $last = $stmt->fetch();

    if ($last && (time() - strtotime($last['created_at'])) < 60) {
        $error = 'Please wait at least 60 seconds before requesting a new code.';
    } else {
        $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE id = ? AND email = ?');
        $stmt->execute([$userId, $email]);
        $user = $stmt->fetch();
        if ($user) {
            $otpData = createAndStoreOTP($email, $purpose, (int)$user['id']);
            $send = sendOTPEmail($email, $user['full_name'], $otpData['otp'], $purpose);
            $message = $send['success'] ? 'A new verification code has been sent.' : $send['message'];
        }
    }
}

// Verify
if (isset($_POST['verify'])) {
    requireCsrf();
    $digits = '';
    for ($i = 0; $i < 6; $i++) {
        $digits .= preg_replace('/\D/', '', $_POST['otp'][$i] ?? '');
    }

    if (strlen($digits) !== 6) {
        $error = 'Please enter the complete 6-digit code.';
    } else {
        if ($method === 'totp') {
            // Authenticator app code: rate-limited per user, replay-protected
            $result = ['success' => false, 'message' => 'Invalid or expired code.'];
            if (!checkRateLimit('totp_login', (string)$userId, 5, 300, 900)) {
                $result['message'] = 'Too many attempts. Please try again in ' . max(1, (int)ceil(rateLimitRemaining('totp_login', (string)$userId) / 60)) . ' minute(s).';
            } else {
                $stmt = getDB()->prepare('SELECT totp_secret, totp_last_step FROM users WHERE id = ? AND email = ? LIMIT 1');
                $stmt->execute([$userId, $email]);
                $row = $stmt->fetch();
                if ($row && !empty($row['totp_secret'])) {
                    $last = $row['totp_last_step'] !== null ? (int)$row['totp_last_step'] : null;
                    $step = totpVerify($row['totp_secret'], $digits, $last);
                    if ($step !== null) {
                        getDB()->prepare('UPDATE users SET totp_last_step = ? WHERE id = ?')->execute([$step, $userId]);
                        $result['success'] = true;
                    } else {
                        recordLoginAttempt($email, false, (int)$userId, 'failed');
                    }
                }
            }
        } else {
            $result = verifyOTP($email, $digits, $purpose);
        }
        if ($result['success']) {
            $pdo = getDB();
            $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? AND email = ? LIMIT 1');
            $stmt->execute([$userId, $email]);
            $user = $stmt->fetch();

            if ($user) {
                unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_email'], $_SESSION['pending_2fa_method']);
                resetFailedAttempts((int)$user['id']);
                recordLoginAttempt($email, true, (int)$user['id'], 'success');
                loginUser($user);

                if ($user['role'] === 'admin') {
                    redirect('/the_enchanted_archives/admin/dashboard.php');
                }
                redirect('/the_enchanted_archives/student/dashboard.php');
            }
            $error = 'Unable to complete login. Please try again.';
        } else {
            $error = $result['message'];
        }
    }
}

$pageTitle = 'Two-Factor Verification';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Two-Factor Verification</h1>
    </div>
    <div class="auth-body">
        <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
        <?php if ($message): ?><div class="alert alert-info py-2"><?= e($message) ?></div><?php endif; ?>

        <?php if ($method === 'totp'): ?>
            <p style="color:#5a4030;text-align:center;">Enter the 6-digit code from your<br><strong>authenticator app</strong></p>
        <?php else: ?>
            <p style="color:#5a4030;text-align:center;">Enter the 6-digit code sent to<br><strong><?= e($email) ?></strong></p>
        <?php endif; ?>

        <form method="post" action="">
            <?= csrfField() ?>
            <div class="otp-inputs">
                <?php for ($i = 0; $i < 6; $i++): ?>
                    <input type="text" name="otp[]" maxlength="1" inputmode="numeric" <?= $i === 0 ? 'autofocus' : '' ?>>
                <?php endfor; ?>
            </div>
            <button type="submit" name="verify" value="1" class="btn btn-gold w-100 mt-3">Verify &amp; Enter</button>
        </form>

        <?php if ($method === 'email'): ?>
        <form method="post" action="" class="mt-3">
            <?= csrfField() ?>
            <button type="submit" name="resend" value="1" class="btn btn-outline-secondary w-100 btn-sm">Resend Code</button>
        </form>
        <?php endif; ?>

        <div class="text-center mt-3">
            <a href="/the_enchanted_archives/auth/logout.php">Cancel login</a>
        </div>
    </div>
</div>

<script nonce="<?= e(cspNonce()) ?>">
document.querySelectorAll('.otp-inputs input').forEach((input, idx, arr) => {
    input.addEventListener('input', () => {
        if (input.value.length === 1 && idx < arr.length - 1) arr[idx + 1].focus();
    });
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !input.value && idx > 0) arr[idx - 1].focus();
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
