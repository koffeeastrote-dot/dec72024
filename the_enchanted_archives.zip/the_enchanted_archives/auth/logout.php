<?php
/**
 * Logout
 */
require_once __DIR__ . '/../includes/auth.php';
startSecureSession();
logoutUser();
setFlash('success', 'You have left the Archives. Until next time.');
redirect('/the_enchanted_archives/index.php');
