<?php
/**
 * Buttons of the "Suspicious Login Activity" email
 *
 *   ?a=itsme&t=TOKEN  "Yes, it's me" -> one-time secure password reset.
 *                     An OTP / authenticator code is asked ONLY if the account has
 *                     two-factor turned on; otherwise no OTP is sent.
 *   ?a=report&t=TOKEN "Report"        -> Report a Problem form (goes to the admins).
 *
 * Opening the link (GET) never changes anything, so e-mail scanners that pre-open
 * links can not use up the token. Actions happen on POST only.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/totp.php';
require_once __DIR__ . '/../includes/reports.php';
startSecureSession();

$actionKey = (string)($_GET['a'] ?? $_POST['a'] ?? '');
$dbAction  = $actionKey === 'itsme' ? 'its_me' : ($actionKey === 'report' ? 'report' : '');
$token     = preg_replace('/[^a-f0-9]/i', '', (string)($_GET['t'] ?? $_POST['t'] ?? ''));

$error   = '';
$info    = '';
$step    = 'invalid'; // invalid | confirm | otp | report_form | report_done
$row     = null;
$formCategory = 'suspicious_activity';
$formSubject  = 'Suspicious login activity on my account';
$formDesc     = '';

// Throttle by IP so the token can not be brute-forced
if (!checkRateLimit('alert_link', getClientIP(), 30, 300, 900)) {
    $error = 'Too many requests. Please try again in a few minutes.';
} elseif ($dbAction !== '') {
    $row = findAlertToken($token, $dbAction);
    if ($row && !(int)$row['is_active']) {
        $row = null;
    }
}

if ($row) {
    $uid   = (int)$row['user_id'];
    $email = (string)$row['email'];

    // ------------------------------------------------------------------
    // "Yes, it's me"
    // ------------------------------------------------------------------
    if ($dbAction === 'its_me') {
        $step = 'confirm';
        $pending = $_SESSION['alert_otp'] ?? null;
        if ($pending && (int)($pending['token_id'] ?? 0) === (int)$row['token_id']) {
            $step = 'otp';
        }
        $method = $pending['method'] ?? 'email';

        $finalize = function () use ($row, $email): never {
            consumeAlertToken((int)$row['token_id']);
            unset($_SESSION['alert_otp']);
            $reset = createPasswordResetToken($email); // 30-minute, single-use link
            redirect('/the_enchanted_archives/auth/reset_password_link.php?token=' . urlencode($reset['token']));
        };

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();

            // Step 1: user confirmed "yes, it's me"
            if (isset($_POST['confirm_itsme'])) {
                if (!empty($row['totp_enabled']) && !empty($row['totp_secret'])) {
                    $_SESSION['alert_otp'] = ['token_id' => (int)$row['token_id'], 'method' => 'totp', 'sent_at' => 0];
                    $step = 'otp';
                    $method = 'totp';
                } elseif (!empty($row['two_factor_enabled'])) {
                    $otp  = createAndStoreOTP($email, 'password_reset', $uid);
                    $send = sendOTPEmail($email, (string)$row['full_name'], $otp['otp'], 'password_reset');
                    $_SESSION['alert_otp'] = ['token_id' => (int)$row['token_id'], 'method' => 'email', 'sent_at' => time()];
                    $step = 'otp';
                    $method = 'email';
                    $info = $send['success'] ? 'A verification code has been sent to your email.' : $send['message'];
                } else {
                    // Two-factor is OFF: no OTP is sent, go straight to the reset form
                    $finalize();
                }
            }

            // Resend email OTP
            if (isset($_POST['resend']) && $step === 'otp' && $method === 'email') {
                if (time() - (int)($_SESSION['alert_otp']['sent_at'] ?? 0) < 60) {
                    $error = 'Please wait at least 60 seconds before requesting a new code.';
                } else {
                    $otp  = createAndStoreOTP($email, 'password_reset', $uid);
                    $send = sendOTPEmail($email, (string)$row['full_name'], $otp['otp'], 'password_reset');
                    $_SESSION['alert_otp']['sent_at'] = time();
                    $info = $send['success'] ? 'A new verification code has been sent.' : $send['message'];
                }
            }

            // Step 2: verify OTP / authenticator code
            if (isset($_POST['verify']) && $step === 'otp') {
                $digits = '';
                for ($i = 0; $i < 6; $i++) {
                    $digits .= preg_replace('/\D/', '', $_POST['otp'][$i] ?? '');
                }
                if (strlen($digits) !== 6) {
                    $error = 'Please enter the complete 6-digit code.';
                } elseif ($method === 'totp') {
                    if (!checkRateLimit('alert_totp', (string)$uid, 5, 300, 900)) {
                        $error = 'Too many attempts. Please try again in a few minutes.';
                    } else {
                        $s = getDB()->prepare('SELECT totp_secret, totp_last_step FROM users WHERE id = ? LIMIT 1');
                        $s->execute([$uid]);
                        $u = $s->fetch();
                        $last = ($u && $u['totp_last_step'] !== null) ? (int)$u['totp_last_step'] : null;
                        $stepUsed = ($u && !empty($u['totp_secret'])) ? totpVerify($u['totp_secret'], $digits, $last) : null;
                        if ($stepUsed === null) {
                            $error = 'Invalid or expired code.';
                        } else {
                            getDB()->prepare('UPDATE users SET totp_last_step = ? WHERE id = ?')->execute([$stepUsed, $uid]);
                            $finalize();
                        }
                    }
                } else {
                    $res = verifyOTP($email, $digits, 'password_reset');
                    if ($res['success']) {
                        $finalize();
                    }
                    $error = $res['message'];
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // "Report"
    // ------------------------------------------------------------------
    if ($dbAction === 'report') {
        $step = 'report_form';
        $formDesc = "I received a security alert about multiple failed login attempts on my account and I did not recognize this activity.\n\n"
                  . 'Alert details: ' . (string)$row['context'];

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_report'])) {
            requireCsrf();
            $formCategory = (string)($_POST['category'] ?? '');
            $formSubject  = trim((string)($_POST['subject'] ?? ''));
            $formDesc     = trim((string)($_POST['description'] ?? ''));
            $error = validateReportInput($formCategory, $formSubject, $formDesc);
            if ($error === '') {
                consumeAlertToken((int)$row['token_id']);
                createReport($uid, $email, $formCategory, $formSubject, $formDesc, 'email_alert');
                $step = 'report_done';
            }
        }
    }
}

$pageTitle = 'Account Security — The Enchanted Archives';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1><?= $dbAction === 'report' ? 'Report Suspicious Activity' : 'Secure Your Account' ?></h1>
    </div>
    <div class="auth-body">
        <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
        <?php if ($info): ?><div class="alert alert-info py-2"><?= e($info) ?></div><?php endif; ?>

        <?php if ($step === 'invalid'): ?>
            <?php if (!$error): ?>
                <div class="alert alert-danger py-2">This link is invalid, has expired, or was already used.</div>
            <?php endif; ?>
            <div class="text-center mt-3">
                <a href="/the_enchanted_archives/auth/forgot_password.php">Reset my password</a> &middot;
                <a href="/the_enchanted_archives/index.php?open=1">Back to login</a>
            </div>

        <?php elseif ($step === 'confirm'): ?>
            <p style="color:#5a4030;">
                You are confirming that the failed login attempts on
                <strong><?= e($row['email']) ?></strong> were made by you.
                To keep the account safe, you will now choose a new password.
                <?php if (!empty($row['totp_enabled']) || !empty($row['two_factor_enabled'])): ?>
                    Because two-factor authentication is on, a verification code is required first.
                <?php endif; ?>
            </p>
            <form method="post">
                <?= csrfField() ?>
                <input type="hidden" name="a" value="itsme">
                <input type="hidden" name="t" value="<?= e($token) ?>">
                <button type="submit" name="confirm_itsme" value="1" class="btn btn-gold w-100">Yes, it's me — continue</button>
            </form>
            <p class="small mt-3 mb-0" style="color:#5a4030;">
                Was this not you? Close this page and use the <strong>Report</strong> button in the email instead.
            </p>

        <?php elseif ($step === 'otp'): ?>
            <?php if (($method ?? 'email') === 'totp'): ?>
                <p style="color:#5a4030;text-align:center;">Enter the 6-digit code from your<br><strong>authenticator app</strong></p>
            <?php else: ?>
                <p style="color:#5a4030;text-align:center;">Enter the 6-digit code sent to<br><strong><?= e($email) ?></strong></p>
            <?php endif; ?>
            <form method="post">
                <?= csrfField() ?>
                <input type="hidden" name="a" value="itsme">
                <input type="hidden" name="t" value="<?= e($token) ?>">
                <div class="otp-inputs">
                    <?php for ($i = 0; $i < 6; $i++): ?>
                        <input type="text" name="otp[]" maxlength="1" inputmode="numeric" <?= $i === 0 ? 'autofocus' : '' ?>>
                    <?php endfor; ?>
                </div>
                <button type="submit" name="verify" value="1" class="btn btn-gold w-100 mt-3">Verify &amp; Continue</button>
            </form>
            <?php if (($method ?? 'email') === 'email'): ?>
            <form method="post" class="mt-3">
                <?= csrfField() ?>
                <input type="hidden" name="a" value="itsme">
                <input type="hidden" name="t" value="<?= e($token) ?>">
                <button type="submit" name="resend" value="1" class="btn btn-outline-secondary w-100 btn-sm">Resend Code</button>
            </form>
            <?php endif; ?>
            <script nonce="<?= e(cspNonce()) ?>">
            document.querySelectorAll('.otp-inputs input').forEach((input, idx, arr) => {
                input.addEventListener('input', () => { if (input.value.length === 1 && idx < arr.length - 1) arr[idx + 1].focus(); });
                input.addEventListener('keydown', (e) => { if (e.key === 'Backspace' && !input.value && idx > 0) arr[idx - 1].focus(); });
            });
            </script>

        <?php elseif ($step === 'report_form'): ?>
            <p style="color:#5a4030;">
                Tell the library administrators what happened. Your report is sent to them right away.
            </p>
            <form method="post">
                <?= csrfField() ?>
                <input type="hidden" name="a" value="report">
                <input type="hidden" name="t" value="<?= e($token) ?>">
                <div class="mb-3">
                    <label class="form-label">Type of report</label>
                    <select name="category" class="form-select" required>
                        <?php foreach (REPORT_CATEGORIES as $k => $label): ?>
                            <option value="<?= e($k) ?>" <?= $formCategory === $k ? 'selected' : '' ?>><?= e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Subject</label>
                    <input type="text" name="subject" class="form-control" maxlength="150" required value="<?= e($formSubject) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Details</label>
                    <textarea name="description" class="form-control" rows="6" maxlength="2000" required><?= e($formDesc) ?></textarea>
                </div>
                <button type="submit" name="submit_report" value="1" class="btn btn-gold w-100">Send Report</button>
            </form>

        <?php elseif ($step === 'report_done'): ?>
            <div class="alert alert-success py-2">Your report was sent to the administrators. Thank you.</div>
            <p style="color:#5a4030;">
                Your account stays protected during the lockout. If you did not make these attempts,
                we recommend changing your password.
            </p>
            <a href="/the_enchanted_archives/auth/forgot_password.php" class="btn btn-gold w-100 mb-2">Change my password</a>
            <a href="/the_enchanted_archives/index.php?open=1" class="btn btn-outline-secondary w-100">Back to login</a>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
