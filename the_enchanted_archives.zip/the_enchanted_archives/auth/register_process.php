<?php
/**
 * Student registration handler (POST only). UI lives in the envelope on index.php
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
startSecureSession();

if (isLoggedIn()) {
    redirect('/the_enchanted_archives/student/dashboard.php');
}

if (!adminExists()) {
    redirect('/the_enchanted_archives/auth/setup_admin.php');
}

// No standalone page any more: GET goes back to the envelope
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/the_enchanted_archives/index.php?open=1&tab=signup');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();

    $ip = getClientIP();
    if (!checkRateLimit('register', $ip, 8, 600, 1800)) {
        $remaining = rateLimitRemaining('register', $ip);
        setFlash('error', 'Too many registration attempts. Please try again in ' . ceil($remaining / 60) . ' minute(s).');
        redirect('/the_enchanted_archives/index.php?open=1&tab=signup');
    }
    
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if ($name === '' || $email === '' || $password === '') {
        $error = 'All fields are required.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please provide a valid email address.';
    } elseif (!isStrongPassword($password)) {
        $error = 'Password must be at least 8 characters, include uppercase, lowercase, a number, and must not be a common/breached password.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (empty($_POST['accept_terms'])) {
        $error = 'You must accept the Terms of Use and the Privacy Notice to create an account.';
    } else {
        try {
            $pdo = getDB();
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                // Do NOT reveal that the email already has an account (enumeration).
                // Show exactly the same screen as a new sign-up; no OTP is created for it.
                $_SESSION['pending_verify_email'] = $email;
                $_SESSION['pending_verify_name'] = $name;
                setFlash('success', 'If this email can be registered, a verification code has been sent to it.');
                redirect('/the_enchanted_archives/auth/verify_otp.php');
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                try {
                    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, is_active, email_verified, terms_accepted_at) VALUES (?, ?, ?, 'student', 1, 0, NOW())");
                    $stmt->execute([$name, $email, $hash]);
                } catch (PDOException $e) {
                    // terms_accepted_at column not migrated yet -> insert without it
                    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, is_active, email_verified) VALUES (?, ?, ?, 'student', 1, 0)");
                    $stmt->execute([$name, $email, $hash]);
                }
                $userId = (int)$pdo->lastInsertId();
                
                // Create OTP
                $otpData = createAndStoreOTP($email, 'registration', $userId);
                $send = sendOTPEmail($email, $name, $otpData['otp'], 'registration');
                
                $_SESSION['pending_verify_email'] = $email;
                $_SESSION['pending_verify_name'] = $name;
                // Remember me: carry the choice over to the login page after OTP verification
                $_SESSION['pending_remember'] = !empty($_POST['remember']) ? 1 : 0;
                
                if ($send['success']) {
                    setFlash('success', 'If this email can be registered, a verification code has been sent to it.');
                } else {
                    // Same wording on purpose: a different message would reveal whether this was a new account.
                    error_log('Registration OTP email failed: ' . ($send['message'] ?? ''));
                    setFlash('success', 'If this email can be registered, a verification code has been sent to it.');
                }
                auditLog('student_registered', 'User ID ' . $userId, $userId);
                redirect('/the_enchanted_archives/auth/verify_otp.php');
            }
        } catch (PDOException $e) {
            $error = 'Registration failed. Please try again.';
            error_log($e->getMessage());
        }
    }
}

// Failed: go back to the envelope (already open) and show the error
$_SESSION['old_signup'] = ['full_name' => $name, 'email' => $email];
setFlash('error', $error);
redirect('/the_enchanted_archives/index.php?open=1&tab=signup');
