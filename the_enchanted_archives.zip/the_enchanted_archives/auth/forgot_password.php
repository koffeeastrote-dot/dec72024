<?php
/**
 * Forgot Password - Request expiring one-time link (primary) or OTP
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
startSecureSession();

$message = '';
$error = '';
$method = $_POST['method'] ?? 'link'; // link | otp

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $email = trim($_POST['email'] ?? '');
    $method = ($_POST['method'] ?? 'link') === 'otp' ? 'otp' : 'link';
    $ip = getClientIP();

    // Rate limit: max 5 reset requests per email/IP per 15 minutes
    if (!checkRateLimit('password_reset', $email !== '' ? $email : $ip, 5, 900, 1800)) {
        $remaining = rateLimitRemaining('password_reset', $email !== '' ? $email : $ip);
        $error = 'Too many reset requests. Please try again in ' . ceil($remaining / 60) . ' minute(s).';
    } else {
        // Always show generic message to avoid account enumeration
        $message = $method === 'otp'
            ? 'If an account exists with that email, a password reset code has been sent.'
            : 'If an account exists with that email, a password reset link has been sent. Check your inbox (and spam folder).';

        if (isValidEmail($email)) {
            // Any earlier "verified" state belongs to a previous request: drop it.
            unset($_SESSION['reset_verified']);
            if ($method === 'otp') {
                // Set for existing AND non-existing emails so the page looks identical (no enumeration)
                $_SESSION['reset_email'] = $email;
            }
            $pdo = getDB();
            $stmt = $pdo->prepare('SELECT id, full_name, email_verified FROM users WHERE email = ? AND is_active = 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                if ($method === 'otp') {
                    $otpData = createAndStoreOTP($email, 'password_reset', (int)$user['id']);
                    sendOTPEmail($email, $user['full_name'], $otpData['otp'], 'password_reset');
                } else {
                    $tokenData = createPasswordResetToken($email);
                    sendPasswordResetLinkEmail($email, $user['full_name'], $tokenData['token']);
                }
            }
        }
    }
}

$pageTitle = 'Recover Access — Forgot Password';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Recover Access</h1>
    </div>
    <div class="auth-body">
        <?php if ($message): ?>
            <div class="alert alert-info py-2"><?= e($message) ?></div>
            <?php if ($method === 'otp' && !empty($_SESSION['reset_email'])): ?>
                <div class="text-center mb-3">
                    <a href="/the_enchanted_archives/auth/reset_password.php" class="btn btn-gold">Enter OTP Code</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= e($error) ?></div>
        <?php endif; ?>

        <p style="color:#5a4030;font-size:0.95rem;">Enter the email associated with your account. We will send a secure, expiring one-time link (recommended) or a 6-digit code.</p>

        <form method="post" action="">
            <?= csrfField() ?>
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" required autofocus value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Reset method</label>
                <select name="method" class="form-select">
                    <option value="link" <?= $method === 'link' ? 'selected' : '' ?>>One-time link (email) — expires in 30 min</option>
                    <option value="otp" <?= $method === 'otp' ? 'selected' : '' ?>>6-digit OTP code</option>
                </select>
            </div>
            <button type="submit" class="btn btn-gold w-100">Send Reset Instructions</button>
        </form>
        <div class="text-center mt-3">
            <a href="/the_enchanted_archives/index.php?open=1">← Back to Login</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
