<?php
/**
 * Password Reset via expiring one-time link
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
startSecureSession();

$token = trim((string)($_GET['token'] ?? $_POST['token'] ?? ''));
// Strip accidental whitespace/newlines from email clients
$token = preg_replace('/\s+/', '', $token);
$error = '';
$step = 'form'; // form | success
$email = '';
$tokenId = null;

if ($token === '') {
    $error = 'Missing or invalid reset link.';
} else {
    $result = verifyPasswordResetToken($token);
    if (!$result['success']) {
        $error = $result['message'];
    } else {
        $email = $result['email'];
        $tokenId = $result['id'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '' && $email !== '') {
    requireCsrf();
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!isStrongPassword($password)) {
        $error = 'Password must be at least 8 characters, include uppercase, lowercase, a number, and must not be a common/breached password.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $pdo = getDB();
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('UPDATE users SET password = ?, failed_login_attempts = 0, lockout_until = NULL WHERE email = ?');
        $stmt->execute([$hash, $email]);
        consumePasswordResetToken((int)$tokenId);
        auditLog('password_reset', 'Password reset via ' . ('link'));
        $step = 'success';
        setFlash('success', 'Password updated successfully. You may now log in.');
    }
}

$pageTitle = 'Reset Password — One-Time Link';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Reset Password</h1>
    </div>
    <div class="auth-body">
        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= e($error) ?></div>
            <div class="text-center mt-3">
                <a href="/the_enchanted_archives/auth/forgot_password.php">Request a new reset link</a>
            </div>
        <?php elseif ($step === 'success'): ?>
            <div class="alert alert-success py-2">Your password has been updated.</div>
            <a href="/the_enchanted_archives/index.php?open=1" class="btn btn-gold w-100">Return to Login</a>
        <?php else: ?>
            <p style="color:#5a4030;">Choose a new strong password for <strong><?= e($email) ?></strong>.</p>
            <form method="post" action="" id="resetLinkForm">
                <?= csrfField() ?>
                <input type="hidden" name="token" value="<?= e($token) ?>">
                <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <div class="input-group-password">
                        <input type="password" name="password" id="newPass" class="form-control" required minlength="8" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-toggle-password="#newPass"><i class="bi bi-eye"></i></button>
                    </div>
                    <div id="strengthMeter" class="mt-2" style="display:none;">
                        <div class="progress" style="height:6px;">
                            <div id="strengthBar" class="progress-bar" role="progressbar" style="width:0%"></div>
                        </div>
                        <small id="strengthLabel" class="text-muted"></small>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Confirm Password</label>
                    <div class="input-group-password">
                        <input type="password" name="confirm_password" id="confirmPass" class="form-control" required minlength="8" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-toggle-password="#confirmPass"><i class="bi bi-eye"></i></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-gold w-100">Update Password</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<script nonce="<?= e(cspNonce()) ?>">
(function(){
    const input = document.getElementById('newPass');
    if (!input) return;
    const meter = document.getElementById('strengthMeter');
    const bar = document.getElementById('strengthBar');
    const label = document.getElementById('strengthLabel');
    const common = <?= json_encode(array_map('strtolower', getCommonPasswords())) ?>;

    function score(pw) {
        let s = 0;
        if (pw.length >= 8) s++;
        if (pw.length >= 12) s++;
        if (/[a-z]/.test(pw)) s++;
        if (/[A-Z]/.test(pw)) s++;
        if (/[0-9]/.test(pw)) s++;
        if (/[^A-Za-z0-9]/.test(pw)) s++;
        if (common.includes(pw.toLowerCase())) s = 0;
        return s;
    }
    const labels = ['Very Weak','Weak','Fair','Good','Strong','Excellent'];
    const colors = ['#c0392b','#e67e22','#f1c40f','#27ae60','#1abc9c','#2ecc71'];

    input.addEventListener('input', function(){
        const pw = this.value;
        if (!pw) { meter.style.display = 'none'; return; }
        meter.style.display = 'block';
        const s = score(pw);
        bar.style.width = (s / 5 * 100) + '%';
        bar.style.backgroundColor = colors[s] || colors[0];
        label.textContent = labels[s] || labels[0];
        if (common.includes(pw.toLowerCase())) label.textContent += ' — too common / breached';
    });
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
