<?php
/**
 * OTP Verification Page
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
startSecureSession();

$email = $_SESSION['pending_verify_email'] ?? '';
$name = $_SESSION['pending_verify_name'] ?? 'Seeker';

if ($email === '') {
    setFlash('error', 'No pending verification found.');
    redirect('/the_enchanted_archives/index.php?open=1');
}

$error = '';
$message = '';
$purpose = 'registration';

// Resend OTP
if (isset($_POST['resend'])) {
    requireCsrf();
    
    // Rate limit: check last OTP created_at
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT created_at FROM otp_verifications WHERE email = ? AND purpose = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$email, $purpose]);
    $last = $stmt->fetch();
    
    if ($last && (time() - strtotime($last['created_at'])) < 60) {
        $error = 'Please wait at least 60 seconds before requesting a new code.';
    } else {
        $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user) {
            $otpData = createAndStoreOTP($email, $purpose, (int)$user['id']);
            $send = sendOTPEmail($email, $user['full_name'], $otpData['otp'], $purpose);
            if ($send['success']) {
                $message = 'A new verification code has been sent.';
            } else {
                $error = $send['message'];
            }
        }
    }
}

// Verify
if (isset($_POST['verify'])) {
    requireCsrf();
    
    $digits = '';
    for ($i = 0; $i < 6; $i++) {
        $digits .= preg_replace('/\D/', '', $_POST['otp'][$i] ?? '');
    }
    
    if (strlen($digits) !== 6) {
        $error = 'Please enter the complete 6-digit code.';
    } else {
        $result = verifyOTP($email, $digits, $purpose);
        if ($result['success']) {
            $pdo = getDB();
            $stmt = $pdo->prepare('UPDATE users SET email_verified = 1 WHERE email = ?');
            $stmt->execute([$email]);
            
            unset($_SESSION['pending_verify_email'], $_SESSION['pending_verify_name']);
            setFlash('success', 'Email verified successfully. You may now enter the Archives.');
            redirect('/the_enchanted_archives/index.php?open=1');
        } else {
            $error = $result['message'];
        }
    }
}

$pageTitle = 'Verify Your Entry — OTP';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$extraJs = ['/the_enchanted_archives/assets/js/dashboard.js'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Verify Your Entry</h1>
    </div>
    <div class="auth-body text-center">
        <p style="color:#5a4030;">A 6-digit code was sent to<br><strong><?= e($email) ?></strong></p>
        <p class="countdown" id="countdown">Code expires in 5:00</p>
        
        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= e($error) ?></div>
        <?php endif; ?>
        <?php if ($message): ?>
            <div class="alert alert-success py-2"><?= e($message) ?></div>
        <?php endif; ?>
        
        <form method="post" action="">
            <?= csrfField() ?>
            <div class="otp-inputs">
                <?php for ($i = 0; $i < 6; $i++): ?>
                    <input type="text" name="otp[]" maxlength="1" inputmode="numeric" pattern="[0-9]" autocomplete="one-time-code" <?= $i === 0 ? 'autofocus' : '' ?>>
                <?php endfor; ?>
            </div>
            <button type="submit" name="verify" value="1" class="btn btn-gold w-100 mb-3">Verify & Enter</button>
        </form>
        
        <form method="post" action="" class="d-inline">
            <?= csrfField() ?>
            <button type="submit" name="resend" value="1" class="btn btn-outline-gold btn-sm">Resend Code</button>
        </form>
        
        <p class="mt-3 mb-0" style="font-size:0.85rem;color:#6b5344;">
            <?php if (!isSmtpConfigured()): ?>
                <strong>Note:</strong> SMTP is not configured. Configure <code>config/smtp.php</code> with a Gmail App Password to receive emails.
            <?php else: ?>
                Check your inbox (and spam folder).
            <?php endif; ?>
        </p>
    </div>
</div>

<script nonce="<?= e(cspNonce()) ?>">
(function(){
    let remaining = 300;
    const el = document.getElementById('countdown');
    const timer = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            clearInterval(timer);
            el.textContent = 'Code expired. Please request a new one.';
            return;
        }
        const m = Math.floor(remaining / 60);
        const s = remaining % 60;
        el.textContent = 'Code expires in ' + m + ':' + String(s).padStart(2, '0');
    }, 1000);
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
