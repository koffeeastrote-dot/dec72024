<?php
/**
 * Compatibility stub. The sign-up UI now lives in the envelope on index.php.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require __DIR__ . '/register_process.php';
    exit;
}
header('Location: /the_enchanted_archives/index.php?open=1&tab=signup');
exit;
