<?php
/**
 * Login handler (POST only). The login/sign-up UI lives in the envelope on index.php
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
startSecureSession();

if (isLoggedIn()) {
    if (currentUserRole() === 'admin') {
        redirect('/the_enchanted_archives/admin/dashboard.php');
    }
    redirect('/the_enchanted_archives/student/dashboard.php');
}

if (!adminExists()) {
    redirect('/the_enchanted_archives/auth/setup_admin.php');
}

// No standalone page any more: GET goes back to the envelope
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/the_enchanted_archives/index.php?open=1');
}

$error = '';

if (true) {
    requireCsrf();
    
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // IP-based rate limit (stops one IP spraying many accounts, complements per-account lockout).
    // 15 attempts per 5 minutes per IP, then blocked for 15 minutes.
    $ip = getClientIP();
    $ipAllowed = checkRateLimit('login', $ip, 15, 300, 900);

    if (!$ipAllowed) {
        $minutes = max(1, (int)ceil(rateLimitRemaining('login', $ip) / 60));
        recordLoginAttempt($email, false, null, 'locked');
        $error = 'Too many login attempts from your network. Please try again in ' . $minutes . ' minute(s).';
    } elseif ($email === '' || $password === '') {
        $error = 'Invalid email or password.';
    } else {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            // Spend the same time as a real password check (no timing difference)
            password_verify($password, '$2y$10$usesomesillystringforsaltuQ9mC0ZbJ0QyQKk0Jk9s1Z7Qd0o1e2');
            handleFailedLogin($email);
            $error = 'Invalid email or password. If you tried several times, the account may be temporarily locked; check your email for a security alert.';
        } elseif (isAccountLocked($user)) {
            recordLoginAttempt($email, false, (int)$user['id'], 'locked');
            // Same wording as a wrong password: do not confirm that the account exists.
            // (The real owner is told by the security alert email.)
            $error = 'Invalid email or password. If you tried several times, the account may be temporarily locked; check your email for a security alert.';
        } elseif (!(int)$user['is_active']) {
            $error = 'Invalid email or password. If you tried several times, the account may be temporarily locked; check your email for a security alert.';
        } elseif (!password_verify($password, $user['password'])) {
            handleFailedLogin($email);
            $error = 'Invalid email or password. If you tried several times, the account may be temporarily locked; check your email for a security alert.';
        } elseif (!(int)$user['email_verified'] && $user['role'] === 'student') {
            // Only someone who knows the correct password is told the email is unverified.
            $_SESSION['pending_verify_email'] = $email;
            setFlash('warning', 'Please verify your email before entering the Archives.');
            redirect('/the_enchanted_archives/auth/verify_otp.php');
        } else {
            // Password correct — check optional 2FA
            $twoFactorEnabled = !empty($user['two_factor_enabled']);

            // Authenticator app (TOTP) takes precedence over email OTP
            if (!empty($user['totp_enabled']) && !empty($user['totp_secret'])) {
                $_SESSION['pending_2fa_user_id'] = (int)$user['id'];
                $_SESSION['pending_2fa_email'] = $email;
                $_SESSION['pending_2fa_method'] = 'totp';
                setFlash('info', 'Enter the 6-digit code from your authenticator app to complete login.');
                redirect('/the_enchanted_archives/auth/verify_login_otp.php');
            }

            if ($twoFactorEnabled) {
                $_SESSION['pending_2fa_method'] = 'email';
                // Do NOT fully log in yet. Send OTP and require second factor.
                $otpData = createAndStoreOTP($email, 'login_2fa', (int)$user['id']);
                $send = sendOTPEmail($email, $user['full_name'], $otpData['otp'], 'login_2fa');

                $_SESSION['pending_2fa_user_id'] = (int)$user['id'];
                $_SESSION['pending_2fa_email'] = $email;

                if (!$send['success']) {
                    // Still proceed to verify page; user can request resend
                    setFlash('warning', 'We could not send the verification code automatically. You can request a new one on the next page.');
                } else {
                    setFlash('info', 'A verification code has been sent to your email. Enter it to complete login.');
                }
                redirect('/the_enchanted_archives/auth/verify_login_otp.php');
            }

            // Success (no 2FA)
            resetFailedAttempts((int)$user['id']);
            recordLoginAttempt($email, true, (int)$user['id'], 'success');
            loginUser($user);
            
            if ($user['role'] === 'admin') {
                redirect('/the_enchanted_archives/admin/dashboard.php');
            }
            redirect('/the_enchanted_archives/student/dashboard.php');
        }
    }
}

// Failed: go back to the envelope (already open) and show the error
$_SESSION['old_login_email'] = $email;
setFlash('error', $error);
redirect('/the_enchanted_archives/index.php?open=1&tab=login');
