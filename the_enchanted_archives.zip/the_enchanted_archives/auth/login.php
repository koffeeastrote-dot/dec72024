<?php
/**
 * Compatibility stub. The login UI now lives in the envelope on index.php.
 * Old links / bookmarks / browser history that point here land on the envelope
 * instead of a 404.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require __DIR__ . '/login_process.php';
    exit;
}
header('Location: /the_enchanted_archives/index.php?open=1&tab=login');
exit;
