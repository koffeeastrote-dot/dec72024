<?php
/**
 * Reset Password with OTP
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/mailer.php';
startSecureSession();

$email = $_SESSION['reset_email'] ?? '';
if ($email === '') {
    redirect('/the_enchanted_archives/auth/forgot_password.php');
}

$error = '';
$step = 'otp'; // otp or password

if (isset($_POST['verify_otp'])) {
    requireCsrf();
    $digits = '';
    for ($i = 0; $i < 6; $i++) {
        $digits .= preg_replace('/\D/', '', $_POST['otp'][$i] ?? '');
    }
    if (strlen($digits) !== 6) {
        $error = 'Please enter the complete 6-digit code.';
    } else {
        // Hard cap on guesses per email (on top of the 5 tries per code)
        if (!checkRateLimit('reset_otp_verify', $email, 10, 900, 1800)) {
            $result = ['success' => false, 'message' => 'Too many attempts. Please wait a while and request a new reset code.'];
        } else {
            $result = verifyOTP($email, $digits, 'password_reset');
        }
        if ($result['success']) {
            // Remember WHICH email was verified. (Old code stored just "true", so a verified
            // session for your own account could be reused to reset someone else's password.)
            $_SESSION['reset_verified'] = $email;
            $step = 'password';
        } else {
            $error = $result['message'];
        }
    }
}

if (isset($_POST['set_password']) && hash_equals((string)($_SESSION['reset_verified'] ?? ''), $email)) {
    requireCsrf();
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if (!isStrongPassword($password)) {
        $error = 'Password must be at least 8 characters, include uppercase, lowercase, a number, and must not be a common/breached password.';
        $step = 'password';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
        $step = 'password';
    } else {
        $pdo = getDB();
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('UPDATE users SET password = ?, failed_login_attempts = 0, lockout_until = NULL WHERE email = ?');
        $stmt->execute([$hash, $email]);
        
        unset($_SESSION['reset_email'], $_SESSION['reset_verified']);
        auditLog('password_reset', 'Password reset via ' . ('otp'));
        setFlash('success', 'Password updated successfully. You may now log in.');
        redirect('/the_enchanted_archives/index.php?open=1');
    }
}

if (hash_equals((string)($_SESSION['reset_verified'] ?? ''), $email)) {
    $step = 'password';
}

$pageTitle = 'Reset Password';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$extraJs = ['/the_enchanted_archives/assets/js/dashboard.js'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>Reset Password</h1>
    </div>
    <div class="auth-body">
        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= e($error) ?></div>
        <?php endif; ?>
        
        <?php if ($step === 'otp'): ?>
            <p style="color:#5a4030;text-align:center;">Enter the 6-digit code sent to<br><strong><?= e($email) ?></strong></p>
            <form method="post" action="">
                <?= csrfField() ?>
                <div class="otp-inputs">
                    <?php for ($i = 0; $i < 6; $i++): ?>
                        <input type="text" name="otp[]" maxlength="1" inputmode="numeric" <?= $i === 0 ? 'autofocus' : '' ?>>
                    <?php endfor; ?>
                </div>
                <button type="submit" name="verify_otp" value="1" class="btn btn-gold w-100">Verify Code</button>
            </form>
        <?php else: ?>
            <p style="color:#5a4030;">Choose a new password for your account.</p>
            <form method="post" action="">
                <?= csrfField() ?>
                <div class="mb-3">
                    <label class="form-label">New Password</label>
                    <div class="input-group-password">
                        <input type="password" name="password" id="newPass" class="form-control" required minlength="8">
                        <button type="button" class="password-toggle" data-toggle-password="#newPass"><i class="bi bi-eye"></i></button>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="form-control" required minlength="8">
                </div>
                <button type="submit" name="set_password" value="1" class="btn btn-gold w-100">Update Password</button>
            </form>
        <?php endif; ?>
        
        <div class="text-center mt-3">
            <a href="/the_enchanted_archives/index.php?open=1">← Back to Login</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
