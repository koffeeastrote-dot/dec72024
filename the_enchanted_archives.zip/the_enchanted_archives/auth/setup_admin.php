<?php
/**
 * First-run Administrator Setup
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
startSecureSession();

if (adminExists()) {
    setFlash('info', 'The Archives already have a Keeper.');
    redirect('/the_enchanted_archives/index.php?open=1');
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    
    if ($name === '' || $email === '' || $password === '') {
        $error = 'All fields are required.';
    } elseif (!isValidEmail($email)) {
        $error = 'Please provide a valid email address.';
    } elseif (!isStrongPassword($password)) {
        $error = 'Password must be at least 8 characters, include uppercase, lowercase, a number, and must not be a common/breached password.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        try {
            $pdo = getDB();
            // Double-check no admin exists
            if (adminExists()) {
                $error = 'An administrator already exists.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, is_active, email_verified) VALUES (?, ?, ?, 'admin', 1, 1)");
                $stmt->execute([$name, $email, $hash]);
                $success = true;
                setFlash('success', 'The first Keeper has been appointed. You may now enter the Archives.');
                redirect('/the_enchanted_archives/index.php?open=1');
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = 'This email is already registered.';
            } else {
                $error = 'An error occurred. Please try again.';
                error_log($e->getMessage());
            }
        }
    }
}

$pageTitle = 'Initial Setup — The Enchanted Archives';
$extraCss = ['/the_enchanted_archives/assets/css/auth.css'];
$bodyClass = 'auth-page';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="auth-card">
    <div class="auth-header">
        <div class="crest">✧</div>
        <h1>First Keeper Setup</h1>
        <p style="color:#EAD7B0;font-size:0.9rem;margin:0.5rem 0 0;">No administrator exists yet. Create the first Keeper of the Archives.</p>
    </div>
    <div class="auth-body">
        <?php if ($error): ?>
            <div class="alert alert-danger py-2"><?= e($error) ?></div>
        <?php endif; ?>
        
        <form method="post" action="" autocomplete="off">
            <?= csrfField() ?>
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control" required value="<?= e($_POST['full_name'] ?? '') ?>" maxlength="150">
            </div>
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>" maxlength="191">
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group-password">
                    <input type="password" name="password" id="setupPass" class="form-control" required minlength="8" data-strength-meter>
                    <button type="button" class="password-toggle" data-toggle-password="#setupPass"><i class="bi bi-eye"></i></button>
                </div>
                <small class="text-muted">Min. 8 characters · uppercase · lowercase · number · not a common password.</small>
            </div>
            <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" required minlength="8">
            </div>
            <button type="submit" class="btn btn-gold w-100">Appoint First Keeper</button>
        </form>
    </div>
</div>

<script src="<?= e(asset('/the_enchanted_archives/assets/js/password-meter.js')) ?>"></script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
